 //const imgURL = "https://s3.us-east-2.amazonaws.com/uataryaplay/UploadsDir/";
 const imgURL = "https://s3.us-east-2.amazonaws.com/aryaplayweb/UploadsDir/";
// const imgURL = "http://122.165.146.121:8153/AryaPlayUATBK/valueoflifeapi/uploads/uploads/";
// const imgURL = "http://13.58.192.84/valueoflifeapi/uploads/uploads/";
// const imgURL = "http://52.90.92.198/aryaplay/valueoflifeapi/uploads/";

var express = require('express');
// var timeout = express.timeout
var bodyParser = require('body-parser');
var multer  =   require('multer');
const ejs = require('ejs');
const paypal = require('paypal-rest-sdk');
const AWS = require('aws-sdk');
const fileUpload = require('express-fileupload');
const SNSLibrary = require('./lib/snsLibrary.js');
const BUCKET_NAME = 'aryaplayweb/UploadsDir';
const IAM_USER_KEY = 'AKIAJ5FSLAL3ME23EPZQ';
const IAM_USER_SECRET = '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';
// function uploadToS3(file) {
 let s3bucket = new AWS.S3({
   accessKeyId: IAM_USER_KEY,
   secretAccessKey: IAM_USER_SECRET,
   Bucket: BUCKET_NAME,
 });
// sandbox Mode 
// paypal.configure({
//   'mode': 'sandbox', //sandbox or live
//   'client_id': 'AVYdOydVs8ND8XT0xEmJEjS3k8zB0OA_UW3vsUPkivycI0Wc5cRAASsqzD01CxVpl7XfR3iOn2EKANyu',
//   'client_secret': 'EPBkkRYZKFc__WRIK95oGf4DzPcTVB9BBv2gjD4HG-dDvYiZsdvm7K9x40hCmXCDQGopGGc7bMl_pEXD'
// });
paypal.configure({
  'mode': 'live', //sandbox or live
  'client_id': 'AVwuJwLX4Ffp14Iw-xkt17wzeWLog2C4T4gVh4oOUFYNOJ2RxSbD4WwgyVyiU61-ltyQeplnXQ78dTtc',
  'client_secret': 'EKajY5o3x_lU0Tfk3H6MLxYnZd67CpQG4gJ-93VzLR8-LRyiz3cA6ffQHDXOKG1h3PeJ-DqdDn8_tEpF'
});
var fs  =   require('fs');
var mysql  = require('mysql');
var async=require('async');
var app = express();
app.set('view engine', 'ejs');

// var timeout = require('connect-timeout');
var crypto=require('crypto'),
    algorithm = 'aes-256-ctr',
    password = 'd6F3Efeq';
app.use(function (req, res, next) {
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS, PUT, PATCH, DELETE');
    res.setHeader('Access-Control-Allow-Headers', 'X-Requested-With,Content-Type');
    res.setHeader('Access-Control-Allow-Credentials', true);
    next();
});
// app.use(timeout(10000));
var server = require('http').Server(app);
var io = require('socket.io')(server);
var SocketAPIHandler=require('./SocketAPI/socketconn.js');
var socketconn = new SocketAPIHandler(io);
app.use(bodyParser({limit: '50mb'}));
app.use(fileUpload());
var urlencodedParser = bodyParser.urlencoded({ extended: false });
var storage =   multer.diskStorage({
 destination: function (req, file, callback) {
   callback(null, './uploads/uploads');
 },
 filename: function (req, file, callback) {
   callback(null, file.originalname);
 }
});
//node mailer starts
// var nodemailer = require('nodemailer');

// // var randomstring = require("randomstring");
// var smtpTransport = require("nodemailer-smtp-transport");

// var smtpTransport=nodemailer.createTransport(smtpTransport({
//     service: 'SES',
//     auth: {
//         user: 'AKIAIQCBDYCITB47VKJQ',
//         pass: 'AkQ+dxzjHIj63IfgD/SVZw8mx6xdsUzWbnnMkKEAMJ5N'
//     }
//   }))
var nodemailer = require('nodemailer');
// var sesTransport = require('nodemailer-ses-transport');
var ses = require('nodemailer-ses-transport');




var transporter = nodemailer.createTransport(ses({
    accessKeyId: 'AKIAJYANRRZT4BL3KKJQ',
    secretAccessKey: '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'
}));
// var smtpTransport = require('nodemailer-ses-transport');

// var smtpTransport = smtpTransport.createTransport(sesTransport({
//     accessKeyId: "AKIAJLXYGWPFK4I3XWXA",
//     secretAccessKey: "AoKFZsu7i2GEigzgHoGVnG18n91vpO4RAKfQsh37mrbL",
//     rateLimit: 5 // do not send more than 5 messages in a second
// }));
// var smtpTransport = nodemailer.createTransport(smtpTransport({
//     host : "smtp.gmail.com",
//     secureConnection : false,
//     port: 465,
//     auth : {
      
//         // user : "paladinsolution12@gmail.com",
//         // pass : "Paladin123"

//         // user : "jefinzinbox@gmail.com",
//         // pass : "thisismygmailpassword"

//           user : "vaibhav.ben10@gmail.com",
//           pass : "Fv12345678"
//     },
//     tls:{
//         rejectUnauthorized:false
//     }
// }))


// var text = 'your my friend';
function getusername_password1(username,password,email)
{
    var mailOptions={
        from : "aryaplayreset@gmail.com",
        to : email,
        subject : "Login Credentials",
        text : "Your Login Credentials",
        html : "<h4>username:"+username+"<br>password:"+password+"</h4>"
      
    }
    // console.log(username+' '+password+' '+email);

  transporter.sendMail(mailOptions,
  function(err,info){
     if(err){

       // res.send('error');
         } else {
       // res.send('sent');
         }
         console.log(info);
         console.log(err);

  });

}

function sendEmailKYC(email,data,callback){
  var mailOptions={
        from :"ksamueldavid02@gmail.com" ,
        to : email,
        subject : "Callidusmena KYC Request",
        text :  "requested  KYC Plan ",
        html : "<h2>"+email[0] +" requested "+data.plan+" Plan for "+data.company_name+" <br> Type of request : "+data.plan+"<br>Price : "+data.price+"</h2>"
      
    }
    // console.log(username+' '+password+' '+email);

  transporter.sendMail(mailOptions,
  function(err,info){
     if(err){
console.log(err);
callback('err',null);
       // res.send('error');
         } else {
callback(null,'sent');
       // res.send('sent');
         }
         console.log(info);
         console.log(err);

  });
}

function encrypt(text){
  var cipher = crypto.createCipher(algorithm,password)
  var crypted = cipher.update(text,'utf8','hex')
  crypted += cipher.final('hex');
  return crypted;
}
 
function decrypt(text){
  var decipher = crypto.createDecipher(algorithm,password)
  var dec = decipher.update(text,'hex','utf8')
  dec += decipher.final('utf8');
  return dec;
}


app.get('/forgotPassword/:email',function(req,res){
  console.log(req.params.email);
  var duplicate_sql="select * from players where email_id='"+req.params.email+"'";
  console.log(duplicate_sql);
  connection.query(duplicate_sql,function(err,rows,fields){
   if(err)
   {
    console.log("Error", err.message);
  }
  else if(rows.length>0){
    
    var query="select name, password from players where email_id='"+req.params.email+"'";
    connection.query(duplicate_sql,function(err,rows,fields){
      if(err)
      {
        console.log("ERROR>>",err.message);
      }
      else
      {


        getusername_password1(rows[0].name,rows[0].password,req.params.email);
        res.send("Email Sent Successfully");
      }
    })
  }
  else
  {
    res.send("Invalid Email-ID");
  }

})
})



app.get('/get_emailverification/:email',function(req,res){
var duplicate_sql="select * from system_user where email_id='"+req.params.email+"'";
      connection.query(duplicate_sql,function(err,rows,fields){
     if(err)
     {
      console.log(err.message);
     }
     else if(rows.length>0){
      var query="select user_name,password from system_user where email_id='"+req.params.email+"'";
      connection.query(duplicate_sql,function(err,rows,fields){
              if(err)
     {
      console.log(err.message);
     }
 
                else
                {
                  getusername_password(rows[0].user_name,rows[0].password,req.params.email,"");
                  res.send("Email Sent Successfully");
                }
      })
     }
     else
     {
      res.send("Invalid Email-ID");
     }
         
})
})

function base64_encode(file) {
    // read binary data
    var bitmap = fs.readFileSync(file);
    // convert binary data to base64 encoded string
    return new Buffer(bitmap).toString('base64');
}




// email with pdf


// send file

var PDFDocument = require ('pdfkit');
// var blobStream  = require ('blob-stream');
// var stream = doc.pipe(blobStream());
// var fs = require('fs');

app.get("/document",function(req,res){

var random = Math.random();
var doc = new PDFDocument();
  doc.pipe(fs.createWriteStream('output'+random+'.pdf'));

  // doc.fontSize(15).text('Wally Gator !', 50, 50);
// Set the paragraph width and align direction
doc.font('Times-Roman').text('Name : Samuel David ', {
    width: 410,
    align: 'left'
}).moveDown(0.5);

doc.font('Times-Roman').text('Profession : Business', {
    width: 410,
    align: 'left'
}).moveDown(0.5);

doc.font('Times-Roman').text('Game : Perception', {
    width: 410,
    align: 'left'
}).moveDown(0.5);



doc.image('/opt/lampp/htdocs/aryaplay/admin/images/Capture.PNG', 50, 200, {width: 200});
// doc.image('/opt/lampp/htdocs/aryaplay/admin/images/selfioutcome.png', 50, 100, {width: 200});

// doc.image('/opt/lampp/htdocs/aryaplay/admin/images/capture.png', 320, 280, {scale: 0.25}).text('Scale', 320, 265);

   doc.image('/opt/lampp/htdocs/aryaplay/admin/images/selfioutcome.PNG', 320, 200, {scale: 0.25});

doc.end();

var attachments = [{ filename: 'output'+random+'.pdf', path: __dirname + '/output'+random+'.pdf', contentType: 'application/pdf' }];

sendemail('sdf','asdf','k.samueldavid02@gmail.com','',attachments)

res.send('email send');

})




function sendemail(username,password,email,message,attachments){

// var attachments = [{ filename: 'images13.jpg', path: __dirname + '/uploads/images13.jpg', contentType: 'application/txt' }];/
  transporter.sendMail({
          from: 'yashwinin58@gmail.com',
          to: "yashwinin58@gmail.com  ",
          subject: "req.query.subject",
          attachments: attachments,
          text: "req.query.text",
  },
  function(err,info){
     if(err){

       // res.send('error');
         } else {
       // res.send('sent');
         }
         console.log(info);
         console.log(err);

  });
}




// end email


function getusername_password(username,password,email,message)
{
console.log("Sending Email",username,password,email,message);
  console.log(message);
  if(message == "")
  {
    
    message="<h4>username:"+username+"<br>password:"+password+"</h4>";
  }
  else
  {
   
    message=message;
   
  }
     transporter.sendMail({
          from: 'yashwinin58@gmail.com',
          to: "yashwinin58@gmail.com  ",
          subject: "req.query.subject",
          // attachments: attachments,
          text: "req.query.text",
  },
  function(err,info){
     if(err){

       // res.send('error');
         } else {
       // res.send('sent');
         }
         console.log(info);
         console.log(err);

  });

    // console.log(username+' '+password+' '+email);
// transporter.sendMail({
//     from: 'sender@example.com',
//     to: 'kashyapmanish626@gmail.com',
//     subject: 'Message',
//     text: 'I hope this message gets sent!',
//     ses: { // optional extra arguments for SendRawEmail
//         Tags: [{
//             Name: 'tag name',
//             Value: 'tag value'
//         }]
//     }
// }, (err, info) => {
//     // console.log(info.envelope);
//     console.log(info);
// });
   //  transporter.sendMail(mailOptions, function(error, res){
   //      if(error){
            
   //          console.log("Error__", error);
   //          // console.log("error");
   //      }else
   //      {
   //          console.log(res.toString());
   //          console.log("Message sent: " + res.message);

   // //        
   //      }
   //  })

}


app.post('/sendkyc',urlencodedParser,function(req,res){
sendEmailKYC([req.body.email,'ksamueldavid02@gmail.com'],req.body.data,function(err,succes){
  res.send({msg:"success",status:0});
});
})
app.post('/get_emailverify/',urlencodedParser,function(req,res){
var sql="select * from players where email_id='"+req.body.email+"'";
      connection.query(sql,function(err,rows,fields){
     if(err)
     {
      console.log(err.message);
     }
                else if(rows.length>0)
                {
                  getusername_password(rows[0].user_name,rows[0].password,req.body.email,req.body.message);
                  res.send("Email Sent Successfully");
                }
                else
                {
                  res.send("Email Not Exist");
                }
      })
    
})






app.get('/change_password/:oldpassword',function(req,res){
var duplicate_sql="select * from system_user where password='"+req.params.oldpassword+"'";
      connection.query(duplicate_sql,function(err,rows,fields){
     if(err)
     {
      console.log(err.message);
     }
     else if(rows.length>0){
      var query="select user_name,password from system_user where email_id='"+req.params.email+"'";
      connection.query(duplicate_sql,function(err,rows,fields){
              if(err)
     {
      console.log(err.message);
     }
 
                else
                {
                  getusername_password(rows[0].user_name,rows[0].password,req.params.email);
                  res.send("Email Sent Successfully");
                }
      })
     }
     else
     {
      res.send("Invalid Email-ID");
     }
         
})
})






//node mailer ends

var upload = multer({ storage : storage }).any();
var connection = mysql.createConnection({
  host: 'localhost',
  port:'3306',
  user: 'root',
  password:'arya02',
  database:'aryaplay',
  multipleStatements: true
})

connection.connect(function(err) {

  if (err){
    console.log(err.message);
  }
  else{
  console.log('You are now connected...');
}
})

// upload api
app.post('/uploadfile',function(req,res){
 var file=req.files.upload;
 console.log(file);
   s3bucket.createBucket(function () {
   var params = {
    Bucket: BUCKET_NAME,
    Key: file.name,
    Body: file.data,
   };
   s3bucket.upload(params, function (err, data) {
    if (err) {
     console.log('error in callback');
     console.log(err);
     // return err;
    }
    console.log('success',data);
    // console.log(data);
    res.send(data);
   });
 });})
app.get('/top_PlayersList/',function(req,res){
      var query="SELECT singleplayerfeedback.playerid,singleplayerfeedback.score, players.name from singleplayerfeedback LEFT JOIN players ON singleplayerfeedback.playerid=players.player_id  GROUP BY score DESC LIMIT 10";
      connection.query(query,function(err,rows,fields){
      if(err){
      console.log(err.message);
    }
    else{
    res.send(JSON.stringify(rows));  
    }
  })
})

// SELECT gender, COUNT(*)FROM players group BY gender
app.get('/gender_recentList/',function(req,res){
      var query=" SELECT gender, COUNT(*) as COUNT FROM players group BY gender";
      connection.query(query,function(err,rows,fields){
      if(err){
      console.log(err.message);
    }
    else{
    res.send(JSON.stringify(rows));  
    }
  })
})

app.get('/top_GenderList/',function(req,res){
      var query="select players.gender, players.age AS age, singleplayerfeedback.score from singleplayerfeedback left join players on players.player_id = singleplayerfeedback.playerid group by singleplayerfeedback.score";
      connection.query(query,function(err,rows,fields){
      if(err){
      console.log(err.message);
    }
    else{
    res.send(JSON.stringify(rows));  
    }
  })
})


app.get('/agewise_gender/',function(req,res){
      var query="select Gender,sum(CASE WHEN AGE BETWEEN 10 AND 20 THEN 1 ELSE 0 ENd) AS '[10-20]', sum(CASE WHEN AGE BETWEEN 21 AND 30 THEN 1 ELSE 0 END )AS '[21-30]' ,sum(CASE WHEN AGE BETWEEN 31 AND 40 THEN 1 ELSE 0 END )AS '[31-40]',sum(CASE WHEN AGE BETWEEN 41 AND 50 THEN 1 ELSE 0 END )AS '[41-50]',sum(CASE WHEN AGE BETWEEN 51 AND 60 THEN 1 ELSE 0 END )AS '[51-60]',sum(CASE WHEN AGE BETWEEN 61 AND 70 THEN 1 ELSE 0 END )AS '[61-70]',sum(CASE WHEN AGE BETWEEN 71 AND 80 THEN 1 ELSE 0 END )AS '[71-80]' FROM players GROUP BY GENDER, '[10-20]','[21-30]','[31-40]','[41-50]','[51-60]','[61-70]','[71-80]'";
      connection.query(query,function(err,rows,fields){
      if(err){
      console.log(err.message);
    }
    else{
    res.send(JSON.stringify(rows));  
    }
  })
})

app.get('/manage_playerslist/:grp_id',function(req,res){
      var query="SELECT * from players where players.Status='A' and players.online_status='true' and players.player_id NOT IN ( select playergroupdetails.player_id FROM playergroupdetails WHERE playergroupdetails.grp_id="+req.params.grp_id+") OR players.player_id IN (SELECT player_group.group_head FROM player_group WHERE player_group.grp_id="+req.params.grp_id+")";
      connection.query(query,function(err,rows,fields){
      if(err){
      console.log(err.message);
    }
    else{
    res.send(JSON.stringify(rows));  
    }
  })
})



app.get('/recently_addedcard/',function(req,res){
      var query="SELECT * FROM card ORDER BY card_id DESC LIMIT 1";
      connection.query(query,function(err,rows,fields){
      if(err){
      console.log(err.message);
    }
    else{
    res.send(JSON.stringify(rows));  
    }
  })
})




app.get('/secret_question/:playerid/:ques1/:ans1/:ques2/:ans2/:ques3/:ans3/:ques4/:ans4',function(req,res){
      var query="insert into answer(playerid,ques1,ques2,ques3,ques4,ans1,ans2,ans3,ans4) values("+req.params.playerid+","+req.params.ques1+","+req.params.ques2+","+req.params.ques3+","+req.params.ques4+",'"+req.params.ans1+"','"+req.params.ans2+"','"+req.params.ans3+"','"+req.params.ans4+"')";
      connection.query(query,function(err,rows,fields){
      if(err){
      console.log(err.message);
    }
    else{
    res.send("inserted"); 
    }
  })
})



app.get("/add_multiple_feedback/:Groupid/:playerid/:playerscore",function(req,res){
  
  var query="insert into group_history (groupid,playerid,playerscore,date) values ("+req.params.Groupid+","+req.params.playerid+","+req.params.playerscore+",now())";
  console.log(query);
  connection.query(query,function(err,rows,fields){
    if(err){
      console.log(err.message);
    }
    else{
      res.send("Inserted");
    }
  })
})





// system users
app.get("/systemuser/:userid",function(req,res){
 var query="select * from system_user where userid='"+req.params.userid+"'";
 connection.query(query,function(err,rows,fields){
  if(err){
    console.log(err.message);
  }
  else if(rows.length>0){
    res.send(JSON.stringify(rows));
    
  }
  else{
    res.send("Invalid");
  }
 })
})



/*user_role_master*/
app.post("/add_role",urlencodedParser,function(req,res){
  var duplicate_sql="select * from rolemaster where Role='"+req.body.Role+"'";
      connection.query(duplicate_sql,function(err,rows,fields){
     if(err)
     {
      console.log(err.message);
     }
     else if(rows.length>0){
      res.send("Role Already Exist");
     }
     else
     {
        var query="insert into rolemaster(Role,Status)values('"+req.body.Role+"','"+req.body.Status+"')";
  connection.query(query,function(err,rows,fields){
     if(err){
      console.log(err.message);
     }
     else
     { 
      res.send("Inserted");
     }
  })    
     }
  })  
  
})

app.get('/update_role/:Role/',function(req,res){
console.log("hai");
res.send("haii");
})
app.get('/update_role/:Role/:roleid',function(req,res){
var duplicate_sql="select * from rolemaster where Role='"+req.params.Role+"'";
      connection.query(duplicate_sql,function(err,rows,fields){
     if(err)
     {
      console.log(err.message);
     }
     else if(rows.length>0){
      console.log("already");
      res.send("Role Already Exist");
     }
     else
     {
      console.log("updateddd");
      var update_query="update rolemaster set Role='"+req.params.Role+"' where Roleid="+req.params.roleid+"";
      connection.query(update_query,function(err,rows,fields){
      if(err){
      console.log(err.message);
    }
    else{
      res.send("Updated");
    }
  })
     }    
})
})

app.get('/display_users/',function(req,res){
      var update_query="SELECT DISTINCT user_name,userid from system_user where Status='A'";
      connection.query(update_query,function(err,rows,fields){
      if(err){
      console.log(err.message);
    }
    else{
    res.send(JSON.stringify(rows));  
    }
  })
})


app.get("/delete_role/:status/:Roleid",function(req,res){
  var status="";
  if(req.params.status=="A"){
status="I";
  }
  else{
    status="A";
  }
  var delete_query="update rolemaster set Status='"+status+"' where Roleid="+req.params.Roleid+"";
  connection.query(delete_query,function(err,rows,fields){
    if(err){
      console.log(err.message);
    }
    else{
      res.send("Deleted");
    }
  })
})

app.get("/view_rolemaster",function(req,res){
 var query="select * from rolemaster";
 connection.query(query,function(err,rows,fields){
  if(err){
    console.log(err.message);
  }
  else{
    res.send(JSON.stringify(rows));
  }
 })
})
/*End user_role_master*/
/*user_master*/



function call_updateusermaster(){

    var password_query1="SELECT SUBSTRING(MD5(RAND()) FROM 1 FOR 6) AS random_num FROM system_user WHERE 'random_num' NOT IN (SELECT password FROM system_user)LIMIT 1";
connection.query(password_query1,function(err,password_rows,fields){
  if(err){
    console.log(err.message);
  }
  else if(password_rows){
    console.log("rows",password_rows);
var password=password_rows[0].random_num;
console.log(password);
  var update_query="update system_user set user_name='"+req.params.username+"' , user_type='"+req.params.usertype+"' , password='"+password+"' ,email_id='"+req.params.emailid+"',Image_url='"+req.params.Image_url+"' where userid="+req.params.userid+"";
  connection.query(update_query,function(err,rows,fields){
    if(err){
      console.log(err.message);
    }
    else{
      res.send("Updated");
    }
  })
}
})

}

// emailverification


app.get('/user_email/:emailid/',function(req,res){
  console.log("update api");
var duplicate_sql="select * from system_user where email_id='"+req.params.emailid+"'";

connection.query(duplicate_sql,function(err,rows,fields){
  if(err){
      console.log(err.message);
     }
  else if(rows.length>0){
    // if(rows[0].)
      res.send("Already Exist");
     }
})

})


app.get('/update_user/:username/:usertype/:password/:emailid/:userid/:Image_url',function(req,res){
  console.log("update api");
// var duplicate_sql="select * from system_user where email_id='"+req.params.emailid+"'";

// connection.query(duplicate_sql,function(err,rows,fields){
//   if(err){
//       console.log(err.message);
//      }
//   else if(rows.length>0){
//     // if(rows[0].)
//       res.send("EmailId Already Exist");
//      }
//   else{
    // var password_query1="SELECT SUBSTRING(MD5(RAND()) FROM 1 FOR 6) AS random_num FROM system_user WHERE 'random_num' NOT IN (SELECT password FROM system_user)LIMIT 1";
// connection.query(password_query1,function(err,password_rows,fields){
//   if(err){
//     console.log(err.message);
//   }
//   else if(password_rows){
//     console.log("rows",password_rows);
// var password=password_rows[0].random_num;
// console.log(password);

var encrypt_password=encrypt(req.params.password.toString());
  console.log(encrypt_password);
  var update_query="update system_user set user_name='"+req.params.username+"' , user_type='"+req.params.usertype+"' , password='"+encrypt_password+"' ,email_id='"+req.params.emailid+"',Image_url='"+req.params.Image_url+"' where userid="+req.params.userid+"";
  connection.query(update_query,function(err,rows,fields){
    if(err){
      console.log(err.message);
    }
    else{
      res.send("Updated");
    }
  })
// }
// })


// }
// })
})



app.post("/add_user",urlencodedParser,function(req,res){
console.log(req.body);
console.log(req.body.usernorex);
console.log(req.body.user_type);
if(req.body.usernorex == 2)
{
   var duplicate_sql="select * from system_user where user_type="+req.body.user_type+" and email_id = '"+req.body.email_id+"'";
     connection.query(duplicate_sql,function(err,rows,fields){
     if(err)
     {
      console.log(err.message);
     }
     else if(rows.length>0){
      res.send("User Role Already Exist");
     }
     else
     {

  var encrypt_password=encrypt(req.body.password.toString());
//   console.log(encrypt_password);
//   var pass_query="select system_user.password from system_user where system_user.password='"+encrypt_password+"'";
// connection.query(pass_query,function(err,rows1,fields){
//   if(err){
//     console.log(err.message);
//   }
//   else if(rows1.length>0){
// console.log("Password Already Exist");
//   }
//   else{

    var generate_query="insert into system_user(user_name,user_type,password,email_id,Image_url,Status)values('"+req.body.user_name+"',"+req.body.user_type+",'"+encrypt_password+"','"+req.body.email_id+"','"+req.body.Image_url+"','"+req.body.Status+"')";
// console.log("first",query);
  connection.query(generate_query,function(err,rows,fields){
     if(err){
      console.log(err.message);
     }
     else{
      res.send("Inserted");
     }
  })

//   }
// })

      
//end
  
}
})


}

else{
  console.log("outside");

  var duplicate_sql1="select * from system_user where email_id='"+req.body.email_id+"'";
     connection.query(duplicate_sql1,function(err,rows,fields){
     if(err)
     {
      console.log(err.message);
     }
     else if(rows.length>0){
      res.send("EmailId Already Exist");
     }
     else
     {
  var encrypt_password=encrypt(req.body.password.toString());
//   console.log(encrypt_password);
//   var pass_query="select system_user.password from system_user where system_user.password='"+encrypt_password+"'";
// connection.query(pass_query,function(err,rows1,fields){
//   if(err){
//     console.log(err.message);
//   }
//   else if(rows1.length>0){
// console.log("Password Already Exist");
//   }
//   else{

    var generate_query="insert into system_user(user_name,user_type,password,email_id,Image_url,Status)values('"+req.body.user_name+"',"+req.body.user_type+",'"+encrypt_password+"','"+req.body.email_id+"','"+req.body.Image_url+"','"+req.body.Status+"')";
console.log("first",generate_query);
  connection.query(generate_query,function(err,rows,fields){
     if(err){
      console.log(err.message);
     }
     else{
      res.send("Inserted");
     }
  })

//   }
// })






}
})
   }
   })


app.get('/webchange_password/:oldpassword/:newpassword/:userid',function(req,res){

  var encrypt_password=encrypt(req.params.oldpassword.toString());
  console.log(encrypt_password);
  var new_encrypt_password=encrypt(req.params.newpassword.toString());
console.log(new_encrypt_password);
  var query="select * from system_user where system_user.password='"+encrypt_password+"' AND system_user.userid='"+req.params.userid+"'";

  connection.query(query,function(err,rows,fields){
    if(err){
      console.log(err.message);
    }
    else if(rows.length>0){
      // res.send("Exists");
      var query2="UPDATE system_user SET system_user.password ='"+new_encrypt_password+"' WHERE system_user.userid='"+req.params.userid+"'";
       connection.query(query2,function(err,rows,fields){
    if(err){
      console.log(err.message);
    }
    else{

      res.send("Updated");

    }
  })
    }
    else{
      res.send("User Not Exist");
    }

  })

})






/*display user based on id existing  user*/
app.get('/getexisting/:userid', function(req,res){
  var getexist = "SELECT * FROM system_user WHERE userid= '"+req.params.userid+"'";
  connection.query(getexist,function(err,rows,fields){
    if(err){
      console.log(err.message);
    }
    else{
       res.send(JSON.stringify(rows));
    }
  })
})

app.get("/delete_user/:status/:userid",function(req,res){
  var status="";
  if(req.params.status=="A"){
status="I";
  }
  else{
    status="A";
  }
  var delete_query="update system_user set Status='"+status+"' where userid="+req.params.userid+"";
  connection.query(delete_query,function(err,rows,fields){
    if(err){
      console.log(err.message);
    }
    else{
      res.send("Deleted");
    }
  })
})
app.get("/view_usermaster",function(req,res){
 var query="SELECT system_user.userid,system_user.user_name,system_user.Image_url,system_user.user_type,rolemaster.Role,system_user.password,system_user.email_id,system_user.Status FROM system_user LEFT JOIN rolemaster ON rolemaster.Roleid = system_user.user_type";
 connection.query(query,function(err,rows,fields){
  if(err){
    console.log(err.message);
  }
  else{
    res.send(JSON.stringify(rows));
  }
 })
})
/*End user_master*/



/* deck_master */
app.post('/insert_Deck_data',urlencodedParser,function(req,res){
  var duplicate_sql="select * from deck where deck_theme='"+req.body.decktheme+"'";
     connection.query(duplicate_sql,function(err,rows,fields){
     if(err)
     {
      console.log(err.message);
     }
     else if(rows.length>0){
      res.send("Deck Name Already Exist");
     }
     else
     {
  var query = "insert into deck(deck_theme,no_of_cards,deck_desc,deck_img_url,Status,excelpath,backcard,decklock,ProductID) VALUES('"+req.body.decktheme+"','"+req.body.noofcards+"','"+req.body.deckdesc+"','"+req.body.deckimgurl+"','"+req.body.Status+"','"+req.body.excelpath+"','"+req.body.backcard+"',"+req.body.decklock+",'"+req.body.productID+"')";
           connection.query(query ,function(err,rows,fields){
              if (err)
              {
                console.log(err.message);
              }
              else{
                res.send('Inserted');
            }
     })    
     }
  
})
})
/* deck_master */
app.post('/saveTransaction',urlencodedParser,function(req,res){
  console.log(req.body);
  var insertQuery="INSERT INTO `transactionrecord`( `orderId`, `productId`, `packageName`, `purchaseState`, `purchaseTime`, `transactionId`,`purchaseType`, `purchaseTypeID`,`playerid`) VALUES ('"+req.body.receipt.orderId+"','"+req.body.receipt.productId+"','"+req.body.receipt.packageName+"',"+req.body.receipt.purchaseState+",'"+req.body.receipt.purchaseTime+"','"+req.body.transactionID+"','"+req.body.purchaseType+"','"+req.body.purchaseTypeID+"',"+req.body.playerID+")";
  // console.log(insertQuerys);
     connection.query(insertQuery,function(err,rows,fields){
     if(err)
     {
      console.log(err.message);
     }
     else
     {
     res.send({status:req.body.receipt.purchaseState});
      }
  
})
})

app.get('/getPremiumFeedbackStatus/:playerid',function(req,res){
  var query="select * from transactionrecord where productID='com.aryaplayfd.feedback' and playerid="+req.params.playerid+"";
  connection.query(query,function(err,rows,fields){
    if(err){
      console.log(err.message);
    }else if(rows.length>0){
      res.send(JSON.stringify({paid:true}));
    }else{
      var productarray=['com.aryaplayfd.feedback']
      res.send(JSON.stringify({paid:false,productarray:productarray}));
    }
  })
})
app.post("/update_deck_data/",urlencodedParser,function(req,res){
  console.log(req.body);
 
  
  var query="update deck set deck_theme='"+req.body.deck_theme+"',no_of_cards="+parseInt(req.body.no_of_cards)+",deck_desc='"+req.body.deck_desc+"',deck_img_url='"+req.body.deck_img_url+"',backcard='"+req.body.updbackcard+"',decklock="+req.body.decklock+",ProductID='"+req.body.productID+"' where DeckID='"+req.body.DeckID+"'";
  console.log(query);
  connection.query(query,function(err,rows,fields){
    if(err){
      console.log(err.message);
    }
    else{
      console.log(rows);
      res.send("Updated");
    }
  })
})

app.get('/delete_deck_data/:deckid/:status',function(req,res){
var deck_id=req.params.deckid;
console.log(deck_id);
var status=req.params.status;
var new_status="";
 
 if(deck_id)
  { 
    if(status == 'A'){
       new_status = 'I';
    }
    else if(status == 'I'){
       new_status = 'A';
    }
    var new_query = "update deck set Status = '"+new_status+"' where DeckID='"+deck_id+"'";
  connection.query(new_query ,function(err,rows,fields){
    if(err)
      {
     console.log(err.message);
    }
   else
     res.send("Deleted Successfully");
      });
  }
  else
  {
    res.send('No values has been passed');
  }
})

app.get("/deck_detailsd/",function(req,res){
  var qry="select * from deck";
  connection.query(qry,function(err,rows,fields){
    if(err){
      console.log(err.message);
    }
    async.forEachOf(rows,function (data, index ,next) {
      var countqry="select deck.DeckID,card.card_name,card.spiritual,card.self_score,card.social_score,card.family_score,card.professional_score,card.img_url,card.card_id,language.lang_id,language.language,word.word,word.synonym FROM deck LEFT JOIN card ON deck.DeckID=card.deck_id LEFT JOIN word ON card.card_id=word.card_id LEFT JOIN language ON word.lang_id = language.lang_id WHERE deck.DeckID='"+rows[index].DeckID+"' and language.lang_id=1";
  connection.query(countqry,function(err,countrows,fields){
rows[index].count=countrows.length;
next();
  })
      },function(err){

res.send(rows);
      })
  });
})



// i dont know for async is used here so above api is replacement for this query;
app.get("/deck_details",function(req,res){
  // console.log('req.params.player_id',req.params.player_id);
  // console.log('req.params.packageName',req.params.packageName);
  var qry="select * from deck where deck.Status ='A'";
  connection.query(qry,function(err,rows,fields){
    if(err){
      console.log(err.message);
    }
    async.forEachOf(rows,function (data, index ,next) {
      // var querytransaction="SELECT * FROM `transactionrecord` WHERE packageName='"+req.params.packageName+"' and playerid="+req.params.player_id+" and purchaseState=0";
      // connection.query(querytransaction,)
      var countqry="select deck.DeckID,card.card_name,card.spiritual,card.self_score,card.social_score,card.family_score,card.professional_score,card.img_url,card.card_id,language.lang_id,language.language,word.word,word.synonym FROM deck LEFT JOIN card ON deck.DeckID=card.deck_id LEFT JOIN word ON card.card_id=word.card_id LEFT JOIN language ON language.lang_id=word.lang_id WHERE deck.DeckID='"+rows[index].DeckID+"' AND language.lang_id='1' and card.Type='B' and card.Status='A'";
  connection.query(countqry,function(err,countrows,fields){
  if(countrows){
rows[index].count=countrows.length;
next();
}else{
  rows[index].count=0;
  next();
}
  })
      },function(err){
        // rows[0].count=0;
res.send(rows);
      })
  });
})
app.get("/deck_details1/:player_id",function(req,res){
  console.log('req.params.player_id',req.params.player_id);
  console.log('req.params.packageName',req.params.packageName);
  if(req.params.player_id==undefined || req.params.player_id=='undefined'){
    console.log('undefined insidwe');
req.params.player_id=0;
  }
  var qry="select * from deck where deck.Status ='A'";
  connection.query(qry,function(err,rows,fields){
    if(err){
      console.log(err.message);
    }
    async.forEachOf(rows,function (data, index ,next) {
     
      var countqry="select deck.DeckID,card.card_name,card.spiritual,card.self_score,card.social_score,card.family_score,card.professional_score,card.img_url,card.card_id,language.lang_id,language.language,word.word,word.synonym FROM deck LEFT JOIN card ON deck.DeckID=card.deck_id LEFT JOIN word ON card.card_id=word.card_id LEFT JOIN language ON language.lang_id=word.lang_id WHERE deck.DeckID='"+rows[index].DeckID+"' AND language.lang_id='1' and card.Type='B' and card.Status='A'";
  connection.query(countqry,function(err,countrows,fields){
  if(countrows){
rows[index].count=countrows.length;
 // va
// next();
}else{
  rows[index].count=0;
  // next();

}
var querytransaction="SELECT * FROM `transactionrecord` WHERE productId='"+rows[index].ProductID+"' and playerid="+req.params.player_id+" and purchaseState=0";
   connection.query(querytransaction,function(err,transactionrows,fields){
      console.log(querytransaction);
        if(err){
          console.log(err.message);
        }else if(transactionrows.length>0){
          rows[index].decklock=0;
        }else{
          // rows[index].decklock=1;
        }
        var querytransaction1="SELECT * FROM card INNER JOIN transactionrecord ON transactionrecord.productId=card.productID WHERE card.deck_id="+rows[index].DeckID+" and card.Type='P' AND transactionrecord.playerid="+req.params.player_id+" AND transactionrecord.purchaseState=0 GROUP  BY card.card_id";
        // console.log(querytransaction1);
        connection.query(querytransaction1,function(err,cardnewrows,fields){
          if(err){
            console.log("err",err.message);
          }else{
            // console.log('cardnewrows',cardnewrows);
            rows[index].count+=cardnewrows.length;
          }
        next();
        })
      })
  })
      },function(err){
        // rows[0].count=0;
res.send(rows);
      })
  });
})


/* End deck_master */

/* player_details */
app.post("/add_players",urlencodedParser,function(req,res){
  console.log(req.body.email_id);
  var select_query="select * from players where email_id='"+req.body.email_id+"'";
  connection.query(select_query,function(err,rows,fields){
    if(err){
      console.log(err.message);
    }
    else if(rows.length>0){
      res.send("already_exist");
    }
    else{
       var query="insert into players(name,nickname,gender,age,email_id,nationality,password,Status,country,img_url,online_status)values('"+req.body.name+"','"+req.body.nickname+"','"+req.body.gender+"','"+req.body.age+"','"+req.body.email_id+"','"+req.body.nationality+"','"+req.body.password+"','"+req.body.Status+"','"+req.body.country+"','"+req.body.img_url+"','true')";
  connection.query(query,function(err,rows,fields){
     if(err){
      console.log(err.message);
     }
     else{
      console.log(rows);
      res.send(rows);
     }
  })
    }
  })
 
})

app.get('/update_players/:name/:nickname/:gender/:age/:email_id/:nationality/:password/:player_id/:img_url',function(req,res){
  var update_query="update players set name='"+req.params.name+"' , nickname='"+req.params.nickname+"' , gender='"+req.params.gender+"' , age='"+req.params.age+"', email_id='"+req.params.email_id+"', nationality='"+req.params.nationality+"', password='"+req.params.password+"', img_url='"+req.params.img_url+"' where player_id="+req.params.player_id+"";
  connection.query(update_query,function(err,rows,fields){
    if(err){
      console.log(err.message);
    }
    else{
      res.send("Updated");
    }
  })
})

app.get("/delete_players/:status/:player_id",function(req,res){
  var status="";
  if(req.params.status=="A"){
status="I";
  }
  else{
    status="A";
  }
  var delete_query="update players set Status='"+status+"' where player_id="+req.params.player_id+"";
  connection.query(delete_query,function(err,rows,fields){
    if(err){
      console.log(err.message);
    }
    else{
      res.send("Deleted");
    }
  })
})
app.get("/player_details",function(req,res){
  // var query="SELECT *,answer.answer,questions.question FROM players LEFT JOIN answer ON players.player_id=answer.playerid LEFT JOIN questions ON answer.questionid=questions.quesid";
var query="SELECT *,players.player_id,players.name,quest1.question as Question1,answer.ans1,quest2.question as Question2,answer.ans2,quest3.question as Question3,answer.ans3,quest4.question as Question4,answer.ans4 from answer LEFT JOIN questions as quest1 ON quest1.quesid=answer.ques1 LEFT JOIN questions as quest2 ON quest2.quesid=answer.ques2 LEFT JOIN questions as quest3 ON quest3.quesid=answer.ques3 LEFT JOIN questions as quest4 ON quest4.quesid=answer.ques4 LEFT JOIN players ON players.player_id=answer.playerid";
  connection.query(query,function(err,rows,fields){
    if(err){
      console.log(err.message);
    }
    else {
      res.send(JSON.stringify(rows));
    }
  });
})
/* End Player_details */

/* language_details */
/*
var duplicate_sql="select * from rolemaster where Role='"+req.body.Role+"'";
      connection.query(duplicate_sql,function(err,rows,fields){
     if(err)
     {
      console.log(err.message);
     }
     else if(rows.length>0){
      res.send("Role Already Exist");
     }
     else
     {
        var query="insert into rolemaster(Role,Status)values('"+req.body.Role+"','"+req.body.Status+"')";
  connection.query(query,function(err,rows,fields){
     if(err){
      console.log(err.message);
     }
     else
     { 
      res.send("Inserted");
     }
  })    
     }
  })  
*/
app.post("/add_language_details",urlencodedParser,function(req,res){
    //var language=req.body.language.toLowerCase();
    var duplicate_sql="select * from language where language='"+req.body.language+"'";
     connection.query(duplicate_sql,function(err,rows,fields){
     if(err)
     {
      console.log(err.message);
     }
     else if(rows.length>0){
      res.send("Language Already Exist");
     }
     else
     {

    var query="insert into language(language,Status)values('"+req.body.language+"','"+req.body.Status+"')";
  connection.query(query,function(err,rows,fields){
     if(err){
      console.log(err.message);
     }
     else{
      res.send("Inserted");
     }
  })
     }
   

    })

})

app.get('/update_language_details/:language/:languageid',function(req,res){
  var duplicate_sql="select * from language where language='"+req.params.language+"'";
     connection.query(duplicate_sql,function(err,rows,fields){
     if(err)
     {
      console.log(err.message);
     }
     else if(rows.length>0){
      res.send("Language Already Exist");
     console.log("Already");
     }
     else
     {
        var update_query="update language set language='"+req.params.language+"' where lang_id="+req.params.languageid+"";
  connection.query(update_query,function(err,rows,fields){
    if(err){
      console.log(err.message);
    }
    else{
      res.send("Updated");
      console.log("upd");
    }
  })    
     }
   })
  
})

app.get("/delete_language_details/:status/:languageid",function(req,res){
  var status="";
  if(req.params.status=="A"){
status="I";
  }
  else{
    status="A";
  }
  var delete_query="update language set Status='"+status+"' where lang_id="+req.params.languageid+"";
  connection.query(delete_query,function(err,rows,fields){
    if(err){
      console.log(err.message);
    }
    else{
      res.send("Deleted");
console.log("deleted")
    }
  })
})
app.get("/language_details",function(req,res){
  var query="SELECT * FROM `language`";
  connection.query(query,function(err,rows,fields){
    if(err){
      console.log(err.message);
    }
    else {
      res.send(JSON.stringify(rows));
    }
  })
})
app.get("/mobile_language_details",function(req,res){
  var query="SELECT * FROM `language` where Status='A'";
  connection.query(query,function(err,rows,fields){
    if(err){
      console.log(err.message);
    }
    else {
      res.send(JSON.stringify(rows));
    }
  })
})
/* End language_details */

/* Card_details */
/*
app.post("/add_role",urlencodedParser,function(req,res){
  var duplicate_sql="select * from rolemaster where Role='"+req.body.Role+"'";
      connection.query(duplicate_sql,function(err,rows,fields){
     if(err)
     {
      console.log(err.message);
     }
     else if(rows.length>0){
      res.send("Role Already Exist");
     }
     else
     {
        var query="insert into rolemaster(Role,Status)values('"+req.body.Role+"','"+req.body.Status+"')";
  connection.query(query,function(err,rows,fields){
     if(err){
      console.log(err.message);
     }
     else
     { 
      res.send("Inserted");
     }
  })    
     }
  })  
  
})
*/
// +"' and img_url='"+req.body.img_url+"'"

// INSERT INTO `card` (`card_id`, `deck_id`, `img_url`, `card_name`, `Status`, `social_score`, `family_score`, `self_score`, `professional_score`) VALUES (NULL, '', '', '', '', '', '', '', '')

// app.post("/add_card_details",urlencodedParser,function(req,res){
//   console.log(req.body.card_name);
//   var duplicate_sql="select * from card where card_name='"+req.body.card_name+"' OR img_url='"+req.body.img_url+"'";
//       connection.query(duplicate_sql,function(err,rows,fields){
//         console.log(rows);
//      if(err)
//      {      
//       console.log(err.message);
//      }
//      else if(rows.length>0){
//       res.send("Already Exist");
//       }

//       else
//       {
//          var query="insert into card(deck_id,img_url,card_name,Status,social_score,family_score,self_score,professional_score,spiritual)values('"+req.body.deck_id+"','"+req.body.img_url+"','"+req.body.card_name+"','"+req.body.Status+"','"+req.body.social_score+"','"+req.body.family_score+"','"+req.body.self_score+"','"+req.body.professional_score+"','"+req.body.spiritual_score+"')";
//         connection.query(query,function(err,rows,fields){
//            if(err){
//             console.log(err.message);
//            }
//            else{
//             res.send("Inserted");
//            }
//         })
//       }
 
// })
//     })

app.post("/add_card_details",urlencodedParser,function(req,res){
  console.log(req.body.card_name);
  console.log(req.body.img_url);
  var duplicate_sql="select * from card where card_name='"+req.body.card_name+"'";
      connection.query(duplicate_sql,function(err,rows,fields){
        console.log(rows);
     if(err)
     {      
      console.log(err.message);
     }
     else if(rows.length>0){
      res.send("Already Exist");
      }

      else
      {
  var query="insert into card(deck_id,img_url,card_name,Status,Type,productID)values('"+req.body.deck_id+"','"+req.body.img_url+"','"+req.body.card_name+"','A','"+req.body.type+"','"+req.body.productID+"')";
  console.log(query);
        connection.query(query,function(err,rows,fields){
           if(err){
            console.log(err.message);
           }
           else{
            res.send("Inserted");

           }
        })
      }
 
})
    })





// UPDATE `card` SET `card_id` = '32 ', `deck_id` = '2 ', `img_url` = 'images.jpg ', `card_name` = 'mycard ', `Status` = 'A ', `social_score` = '12 ', `family_score` = '11 ', `self_score` = '10 ', `professional_score` = '10' WHERE `card`.`card_id` = 32

// app.get('/update_card_details/:deck_id/:card_name/:img_url/:card_id/:social_score/:family_score/:self_score/:professional_score/:spiritual_score',function(req,res){
//   var update_query="update card set deck_id='"+req.params.deck_id+"' ,card_name='"+req.params.card_name+"',img_url='"+req.params.img_url+"',social_score='"+req.params.social_score+"',family_score='"+req.params.family_score+"' ,self_score='"+req.params.self_score+"',professional_score='"+req.params.professional_score+"',spiritual='"+req.params.spiritual_score+"' where card_id="+req.params.card_id+"";
//   connection.query(update_query,function(err,rows,fields){
//     if(err){
//       console.log(err.message);
//     }
//     else{
//       res.send("Updated");
//     }
//   })
// })


app.post("/update_card_details",urlencodedParser,function(req,res){
  
  console.log("inside");
// var req.body.scoredata=[]
  var query="update card set deck_id="+req.body.deckname+",card_name='"+req.body.cardname+"',img_url='"+req.body.imageurlstore+"',Type='"+req.body.type+"',productID='"+req.body.productID+"' where card_id="+req.body.cardid+"";
  console.log(query);
  connection.query(query,function(err,rows,fields){
     if(err){
      console.log(err.message);
     }
    
else{
  console.log(rows);
  console.log(req.body.arrayscores.length);
  var scorelength=JSON.stringify(req.body.arrayscores);
  if(req.body.arrayscores.length>0){
    // for(i=0;i<req.body.arrayscores.length;i++){
    var check_category="select * from score where card_id="+req.body.cardid+"";
    connection.query(check_category,function(err,rows,fields){
      if(err){
        console.log(err.message);
      }
      else{
        console.log(rows[0]);
        // for(j=0;j<rows[0].length;j++){
          async.forEachOf(req.body.arrayscores,function (data, index ,next) {
         // for(i=0;i<data.length;i++){
          var check_idexist="select * from score where cat_id="+req.body.arrayscores[index]["categoryid"]+" AND card_id="+req.body.cardid+"";
          console.log(check_idexist);
          connection.query(check_idexist,function(err,rows,fields){
            if(err){
              console.log(err.message);
            }
            else{
              console.log(rows.length);
              if(rows.length>0){
                console.log(data);
                 var sqlquery="update score set deck_id="+req.body.deckname+",card_id="+req.body.cardid+",cat_id="+data.categoryid+",score="+data.score+"  where score_id="+rows[0].score_id+"";
                 console.log(sqlquery);
            connection.query(sqlquery,function(err,rows,fields){
              if(err){
                console.log(err.message);
              }
              else{
console.log("updated");
              }
            })
              }
              else{
                var insertquery="insert into score(deck_id,card_id,cat_id,score) values("+req.body.deckname+","+req.body.cardid+","+data.categoryid+","+data.score+")";
                 connection.query(insertquery,function(err,rows,fields){
              if(err){
                console.log(err.message);
              }
              else{
console.log("updated");
              }
            })
              }
            }
            next();
          })

//           if(parseInt(req.body.arrayscores[i].categoryid)==rows[j].cat_id){
//            var sqlquery="update score set deck_id="+req.body.deckname+",card_id="+req.body.cardid+",cat_id="+req.body.arrayscores[i].categoryid+",score="+req.body.arrayscores[i].score+"  where score_id="+rows[j].score_id+"";
//             connection.query(sqlquery,function(err,rows,fields){
//               if(err){
//                 console.log(err.message);
//               }
//               else{
// console.log("updated");
//               }
//             })
//           }

         
        // }
        // }
    },function(err){

res.send("updated");
    })
      }
      
    })
  
  }

}

})
})



app.get("/getcardscoredata/:card_id",function(req,res){
  var status="";
  if(req.params.status=="A"){
status="I";
  }
  else{
    status="A";
  }
  var delete_query="update card set Status='"+status+"' where card_id="+req.params.card_id+"";
  connection.query(delete_query,function(err,rows,fields){
    if(err){
      console.log(err.message);
    }
    else{
      res.send("Deleted");
    }
  })
})








app.get("/card_details",function(req,res){
  var cardarray=[];
  var scoreobj={};
  var query="SELECT deck.deck_theme,card.* FROM card  INNER JOIN deck ON deck.DeckID=card.deck_id";
  connection.query(query,function(err,rows,fields){
    if(err){
      console.log(err.message);
    }
    else {
      for(i=0;i<rows.length;i++){
cardarray.push(rows[i])
      }
      async.forEachOf(cardarray,function (data, index ,next) {
        scoreobj={};
        var scorequery="SELECT cattheme.cattheme_id,deck.deck_theme,card.card_name,cattheme.category,score.score FROM score INNER JOIN deck ON deck.DeckID=score.deck_id INNER JOIN card ON card.card_id=score.card_id INNER JOIN cattheme ON cattheme.cattheme_id =score.cat_id WHERE cattheme.status='A' AND score.card_id="+cardarray[index]["card_id"]+"";
        connection.query(scorequery,function(err,rows,fields){
          if(err){
            console.log(err.message);
          }
          else{
            cardarray[index].scoredata=rows;
            // cardarray[index].scoredata=scoreobj;
          }
          next();
        })
      },function(err){
        res.send(cardarray);
      })
    }
  })
})
/*  End Card_details*/

// SELECT card.*, word.word, word.synonym FROM `card` LEFT JOIN word ON card.card_id = word.card_id where card.Type = 'B'

// card by type


app.get("/card_by_type/:type",function(req,res){
  
  var query='SELECT card.*, word.word,deck.deck_theme,word.synonym FROM `card` LEFT JOIN word ON card.card_id = word.card_id LEFT JOIN deck ON card.deck_id = deck.DeckID where card.Type = "'+req.params.type+'" and word.lang_id=1 AND card.status = "A"';
  connection.query(query,function(err,rows,fields){
    if(err){
      console.log(err.message);
    }
    else{
      res.send(rows);
    }
  })
})
app.get("/card_by_type1/:type/:player_id",function(req,res){
  console.log('req.params.player_id',req.params.player_id);
  var query='SELECT card.*, word.word,deck.deck_theme,word.synonym FROM `card` LEFT JOIN word ON card.card_id = word.card_id LEFT JOIN deck ON card.deck_id = deck.DeckID where card.Type = "'+req.params.type+'" and word.lang_id=1 AND card.status = "A"';
  connection.query(query,function(err,rows,fields){
    if(err){
      console.log(err.message);
    }
    else{
      var cardsPremiumFilterArray=[];
       async.forEachOf(rows,function (data, index ,next) {
        var querytransaction="SELECT * FROM `transactionrecord` WHERE productId='"+rows[index].productID+"' and playerid="+req.params.player_id+" and purchaseState=0";
        connection.query(querytransaction,function(err,trrows,trfields){
          if(err){
            console.log(err.message);
          }else if(trrows.length>0){

          }else{
            cardsPremiumFilterArray.push(rows[index]);
          }
          next();
        })
      // res.send(rows);
    },function(err){
      if(err){
console.log(err.message);
      }
      res.send(cardsPremiumFilterArray);
    })

    }
  })
})



// end here

// get premium deck

app.get("/deck_premium",function(req,res){
  
  var query='SELECT card.*, deck.* FROM card INNER JOIN deck on deck.DeckID=card.deck_id WHERE card.Type = "p" group BY card.deck_id';
  connection.query(query,function(err,rows,fields){
    if(err){
      console.log(err.message);
    }
    else{
      res.send(rows);
    }
  })
})


/* word_details */

app.post("/add_word_details",urlencodedParser,function(req,res){
console.log(req.body);
    var duplicate_sql='select * from word where word="'+req.body.word+'"  and card_id="'+req.body.card_id+'" and synonym="'+req.body.synonym+'" and lang_id='+req.body.lang_id+' and Status="A"';
      connection.query(duplicate_sql,function(err,rows,fields){
        console.log(duplicate_sql);
     if(err)
     {      
      console.log(err.message);
     }
     else if(rows.length>0){
      res.send("Already Exist");
      }
  else{
  var query='insert into word(lang_id,card_id,word,synonym,Status)values("'+req.body.lang_id+'","'+req.body.card_id+'","'+req.body.word+'","'+req.body.synonym+'","'+req.body.Status+'")';
  console.log(query);
  connection.query(query,function(err,rows,fields){
     if(err){
      console.log(err.message);
     }
     else{
      res.send("Inserted");
     }
  })
}
})
})

app.post('/update_word_details/',function(req,res){


  var update_query="update word set lang_id='"+req.body.lang_id+"' ,card_id='"+req.body.card_id+"',word='"+req.body.word+"',synonym='"+req.body.synonym+"' where word_id="+req.body.word_id+"";
  connection.query(update_query,function(err,rows,fields){
    if(err){
      console.log(err.message);
    }
    else{
      res.send("Updated");
    }
  })
})

app.get("/delete_word_details/:status/:word_id",function(req,res){
  var status="";
  if(req.params.status=="A"){
status="I";
  }
  else{
    status="A";
  }
  var delete_query="update word set Status='"+status+"' where word_id="+req.params.word_id+"";
  connection.query(delete_query,function(err,rows,fields){
    if(err){
      console.log(err.message);
    }
    else{
      res.send("Deleted");
    }
  })
})

app.get("/word_details",function(req,res){
  var query="SELECT word.lang_id,deck.DeckID,deck.deck_theme,language.language,word.card_id,card.card_name,word.word,word.word_id,word.synonym,word.Status FROM word LEFT JOIN language ON language.lang_id = word.lang_id LEFT JOIN card ON card.card_id=word.card_id LEFT JOIN deck on deck.DeckID=card.deck_id";
  connection.query(query,function(err,rows,fields){
    if(err){
      console.log(err.message);
    }
    else {
      res.send(JSON.stringify(rows));
    }
  })
})
/* End word_details */

/* player_group_details */

// app.post("/add_player_group",urlencodedParser,function(req,res){
//   var query="insert into player_group(grp_name,no_of_players,group_head,Status)values('"+req.body.grp_name+"','"+req.body.no_of_players+"','"+req.body.group_head+"','"+req.body.Status+"')";
//   connection.query(query,function(err,rows,fields){
//      if(err){
//       console.log(err.message);
//      }
//      else{
//       res.send("Inserted");
//      }
//   })
// })

// app.post('/add_player_group',function(req,res){
//   console.log(req.params.group.length);
// for(var i=0;i<req.body.group.length;i++){
// var query="insert into player_group(grp_name,no_of_players,group_head,Status) values ("+req.body.group[i]["grp_name"]+","+req.body.group[i]["no_of_players"]+","+req.body.group[i]["group_head"]+","+req.body.group[i]["Status"]+")";
// console.log(query);
// connection.query(query,function(err,rows,fields){
//                         if(err){
//       console.log(err.message);
//      }
//      else
//      { 
//       res.send("Inserted");
//      }
// })
// }
// })



app.post('/add_player_group',function(req,res){
var dupcheck="select * from player_group where grp_name='"+req.body.grp_name+"'";
connection.query(dupcheck,function(err,rows,fields){
                        if(err){
      console.log(err.message);
     }
     else if(rows.length>0)
     { 
      res.send("Group Already Exist");
     }
     else
     {
    var query="insert into player_group(grp_name,no_of_players,group_head,Status) values ('"+req.body.grp_name+"',"+req.body.no_of_players+",'"+req.body.group_head+"','"+req.body.Status+"')";
console.log(query);
connection.query(query,function(err,rows,fields){
                        if(err){
      console.log(err.message);
     }
     else
     { 
      res.send(rows);
      console.log(rows);
     }
})      
     }
})
})
app.get('/update_player_group/:grp_name/:no_of_players/:group_head/:grp_id',function(req,res){
  var update_query="update player_group set grp_name='"+req.params.grp_name+"',no_of_players='"+req.params.no_of_players+"',group_head='"+req.params.group_head+"'  where grp_id="+req.params.grp_id+"";
  connection.query(update_query,function(err,rows,fields){
    if(err){
      console.log(err.message);
    }
    else{
      res.send("Updated");
    }
  })
})

app.get('/insert_group_players/:grp_id/:player_id',function(req,res){
  var dupquery="SELECT COUNT(playergroupdetails.player_id) as playercount FROM playergroupdetails WHERE playergroupdetails.grp_id="+req.params.grp_id+"";
  var beforeinsertquery="SELECT * FROM playergroupdetails WHERE playergroupdetails.grp_id="+req.params.grp_id+" and playergroupdetails.player_id="+req.params.player_id+"";
connection.query(dupquery,function(err,rows,fields){
  console.log(rows[0].playercount);
    if(err){
      console.log(err.message);
    }
    else if(rows[0].playercount >=7){
      res.send("max");

    }
    else   {
      connection.query(beforeinsertquery,function(err,rows,fields){
        if(err){
        console.log(err.message);
        }
        else if(rows.length>0){
res.send("exists");
        }
        else{
          var update_query="insert into playergroupdetails(grp_id,player_id,status) values ("+req.params.grp_id+","+req.params.player_id+",'A')";
  connection.query(update_query,function(err,rows,fields){
    if(err){
      console.log(err.message);
    }
    else{
      res.send("Inserted");
    }
    })    
        }

      })
  
    }
  })
})

app.get('/display_group_players/:grp_id',function(req,res){

  var update_query="SELECT players.platform,players.img_url,players.name,players.player_id,players.nickname,players.gender,players.age,players.email_id,players.nationality,players.token,player_group.grp_name,player_group.group_head as admin FROM playergroupdetails LEFT JOIN player_group ON playergroupdetails.grp_id=player_group.grp_id LEFT JOIN players ON playergroupdetails.player_id=players.player_id WHERE playergroupdetails.grp_id="+req.params.grp_id+"";
  connection.query(update_query,function(err,rows,fields){
    if(err){
      console.log(err.message);
    }
    else{

      res.send(JSON.stringify(rows));
    }
  })
})



app.get("/delete_player_group/:status/:grp_id",function(req,res){
  var status="";
  if(req.params.status=="A"){
status="I";
  }
  else{
    status="A";
  }
  var delete_query="update player_group set Status='"+status+"' where grp_id="+req.params.grp_id+"";
  connection.query(delete_query,function(err,rows,fields){
    if(err){
      console.log(err.message);
    }
    else{
      res.send("Deleted");
    }
  })
})

app.get("/player_group_details/:playerid",function(req,res){
  var query="SELECT player_group.grp_id,player_group.grp_name,player_group.no_of_players,player_group.group_head,players.player_id,player_group.Status FROM player_group LEFT JOIN players ON players.player_id=player_group.group_head WHERE players.player_id!="+req.params.playerid+"";
  connection.query(query,function(err,rows,fields){
    if(err){
      console.log(err.message);
    }
    else {
      res.send(JSON.stringify(rows));
    }
  })
})

app.get("/player_grp_details/",function(req,res){
  var query="SELECT player_group.grp_id,player_group.grp_name,player_group.no_of_players,player_group.group_head,players.name,players.player_id,player_group.Status FROM player_group LEFT JOIN players ON players.player_id=player_group.group_head";
  connection.query(query,function(err,rows,fields){
    if(err){
      console.log(err.message);
    }
    else {
      res.send(JSON.stringify(rows));
    }
  })
})
/* End player_group_details */

/* instruction_details */



app.post("/add_notification",urlencodedParser,function(req,res){
  console.log("hai");
  var dup_query="select * from notification where link='"+req.body.link+"'";
connection.query(dup_query,function(err,rows,fields){
     if(err){
      console.log(err.message);
     }
     else if(rows.length>0){
      res.send("Invitation Already Send");
     }
     else
     {
      var query="insert into notification(grp_id,player_id,link,message,requestJoin,reqPlayerID,status)values("+req.body.grp_id+","+req.body.player_id+",'"+req.body.link+"','"+req.body.message+"','"+req.body.requestJoin+"','"+req.body.reqPlayerID+"','A')";
      console.log(query);
  connection.query(query,function(err,rows,fields){
     if(err){
      console.log(err.message);
     }
     else{
      res.send("Inserted");
     }
  })
     }
  })  
  
})

app.get('/delete_notification/:notify_id',function(req,res){
  var update_query="delete from notification where notify_id="+req.params.notify_id+"";
  connection.query(update_query,function(err,rows,fields){
    if(err){
      console.log(err.message);
    }
    else{
      res.send("Deleted");
    }
  })
})

app.get('/check_playeringroup/:group_id/:player_id',function(req,res){
  var update_query="select * from playergroupdetails where grp_id="+req.params.group_id+" and player_id="+req.params.player_id+"";
  connection.query(update_query,function(err,rows,fields){
    if(err){
      console.log(err.message);
    }
    else if(rows.length>0){
      res.send("Already Exist");
    }
    else
    {
      res.send("new player for the group");
    }
  })
})


app.get('/view_notification/:player_id',function(req,res){
  var update_query="select * from notification where player_id="+req.params.player_id+" and status='A'";
  connection.query(update_query,function(err,rows,fields){
    if(err){
      console.log(err.message);
    }
    else{
      res.send(JSON.stringify(rows));
    }
  })
})


// app.get('/change_notifystatus/:player_id/:status',function(req,res){
//  if(req.params.status=='R') {
//    var update_query="update notification set status="+req.params.status+" where player_id="+req.params.player_id+"";
//   connection.query(update_query,function(err,rows,fields){
//     if(err){
//       console.log(err.message);
//     }
//     else{
//       res.send(JSON.stringify(rows));
//     }
//   })
// }
//  else {
//  var update_query="update notification set status="+req.params.status+" where player_id="+req.params.player_id+"";
//   connection.query(update_query,function(err,rows,fields){
//     if(err){
//       console.log(err.message);
//     }
//     else{
//       res.send(JSON.stringify(rows));
//     }
//   }) 

//  }
// })


app.get('/change_notifystatus/:player_id/:status',function(req,res){
  var new_status='';
  if(req.params.status=='R')
  {
    new_status='R';
  }
  else{
    new_status='UR'
  }
 var update_query="update notification set status='"+new_status+"' where player_id="+req.params.player_id+"";
  connection.query(update_query,function(err,rows,fields){
    if(err){
      console.log(err.message);
    }
    else{
      res.send(JSON.stringify(rows));
    }
})
})


app.post("/add_instruction",urlencodedParser,function(req,res){
  console.log(req.body);

var dupcheck="select * from instruction where deckid="+req.body.deckid+" and lang_id="+req.body.lang_id+" and gamemode="+req.body.gamemode+" and gametype="+req.body.gametype+"";
connection.query(dupcheck,function(err,rows,fields){
                        if(err){
      console.log(err.message);
     }
     else if(rows.length>0)
     { 
      res.send("Already Exist");
     }
     else
     {

  var query="insert into instruction(instruction.deckid,instruction.lang_id,instruction.gamemode,instruction.gametype,instruction.instruction,instruction.gif_instruction,instruction.Status,instruction.videolink)values('"+req.body.deckid+"','"+req.body.lang_id+"','"+req.body.gamemode+"','"+req.body.gametype+"','"+req.body.instruction+"','"+req.body.gif_instruction+"','A','"+req.body.videolink+"')";
  connection.query(query,function(err,rows,fields){
     if(err){
      console.log(err.message);
     }
     else{
      res.send("Inserted");
     }
  })
   }
  })
})

app.post('/update_instruction',urlencodedParser,function(req,res){
  var update_query="update instruction set instruction.deckid='"+req.body.upd_deckid+"',instruction.lang_id='"+req.body.upd_lang_id+"',instruction.gamemode='"+req.body.upd_gamemode+"',instruction.gametype='"+req.body.upd_gametype+"',instruction.instruction='"+req.body.upd_instruction+"',instruction.gif_instruction='"+req.body.upd_gif_instruction+"',instruction.Status='A',instruction.videolink='"+req.body.uvideolink+"' where instruction.instruction_id="+req.body.instruction_id+"";
  console.log(update_query);
  connection.query(update_query,function(err,rows,fields){
    if(err){
      console.log(err.message);
    }
    else{
      res.send("Updated");
    }
  })
})

app.get("/delete_instruction/:status/:instruction_id",function(req,res){
  var status="";
  if(req.params.status=="A"){
status="I";
  }
  else{
    status="A";
  }
  var delete_query="update instruction set Status='"+status+"' where instruction_id="+req.params.instruction_id+"";
  console.log(delete_query);
  connection.query(delete_query,function(err,rows,fields){
    if(err){
      console.log(err.message);
    }
    else{
      res.send("Deleted");
        }
  })
})

app.get("/instruction_details",function(req,res){
  var query="SELECT instruction.deckid,instruction.videolink,instruction.instruction_id,instruction_type.instructor_type,instruction.lang_id,language.language,instruction.instructor_typeid,instruction.gamemode,instruction.gametype as gametypeid,game_master.game_name as gametypename,instruction.instruction,instruction.Status FROM instruction LEFT JOIN language ON instruction.lang_id=language.lang_id LEFT JOIN instruction_type ON instruction.instructor_typeid=instruction_type.instructor_typeid LEFT JOIN game_master ON instruction.gametype=game_master.game_id ORDER by instruction.instruction_id DESC";
  connection.query(query,function(err,rows,fields){
    if(err){
      console.log(err.message);
    }
    else {
      res.send(JSON.stringify(rows));
    }
  })
})

app.get("/instruction_type",function(req,res){
  var query="SELECT * FROM `instruction_type` WHERE instruction_type.Status='A'";
  connection.query(query,function(err,rows,fields){
    if(err){
      console.log(err.message);
    }
    else {
      res.send(JSON.stringify(rows));
    }
  })
})



app.get("/game_typelist",function(req,res){
  var query="SELECT * FROM game_master";
  connection.query(query,function(err,rows,fields){
    if(err){
      console.log(err.message);
    }
    else {
      res.send(JSON.stringify(rows));
    }
  })
})

/* end instruction_details */

/*instructor type starts*/



app.post("/add_instructiontype",urlencodedParser,function(req,res){
  var query="INSERT INTO instruction_type(instruction_type.instructor_type,instruction_type.instructor_desc,instruction_type.Status)VALUES('"+req.body.instructor_type+"','"+req.body.instructor_desc+"','A')";
  connection.query(query,function(err,rows,fields){
     if(err){
      console.log(err.message);
     }
     else{
      res.send("Inserted");
     }
  })
})



app.post("/update_instructiontype",urlencodedParser,function(req,res){
  var query="UPDATE instruction_type SET instruction_type.instructor_type='"+req.body.upd_instructor_type+"',instruction_type.instructor_desc='"+req.body.upd_instructor_desc+"' WHERE instruction_type.instructor_typeid='"+req.body.upd_instructortype_id+"'";
  console.log(query);
  connection.query(query,function(err,rows,fields){
     if(err){
      console.log(err.message);
     }
     else{
      res.send("Updated");
     }
  })
})


app.get("/delete_instructiontype/:status/:instruction_typeid",function(req,res){
  var status="";
  if(req.params.status=="A"){
status="I";
  }
  else{
    status="A";
  }
  var delete_query="UPDATE instruction_type set instruction_type.Status='"+status+"' WHERE instruction_type.instructor_typeid='"+req.params.instruction_typeid+"'";
  connection.query(delete_query,function(err,rows,fields){
    if(err){
      console.log(err.message);
    }
    else{
      res.send("Deleted");
        }
  })
})



app.get("/instructiontype_details",function(req,res){
  var query="SELECT instruction_type.instructor_type,instruction_type.instructor_typeid,instruction_type.instructor_desc,instruction_type.Status FROM instruction_type";
  connection.query(query,function(err,rows,fields){
    if(err){
      console.log(err.message);
    }
    else {
      res.send(JSON.stringify(rows));
    }
  })
})




/*instructor type ends*/

app.get("/game_settings_details",function(req,res){
  var query="SELECT settings.Settingid,settings.deck_id,deck.deck_theme,deck.deck_desc,settings.maxnoofplayerpergroup,settings.maxnoofcardspergroup,settings.cardsvisibility,settings.lang_id,language.language,settings.backgroundmusic,settings.changeorder,settings.image_url,settings.status FROM settings LEFT JOIN deck ON deck.DeckID=settings.deck_id LEFT JOIN language ON language.lang_id=settings.lang_id";
  connection.query(query,function(err,rows,fields){
    if(err){
      console.log(err.message);
    }
    else {
      res.send(JSON.stringify(rows));
    }
  })
})


/* group_details */

app.post("/add_game_history_details",urlencodedParser,function(req,res){
  var query="insert into game_history(group_id,player_id,deck_id,lang_id,start_date,time,duration,feedback,score,no_of_turns,Status)values('"+req.body.group_id+"','"+req.body.player_id+"','"+req.body.deck_id+"','"+req.body.lang_id+"','"+req.body.start_date+"','"+req.body.time+"','"+req.body.duration+"','"+req.body.feedback+"','"+req.body.score+"','"+req.body.no_of_turns+"','"+req.body.Status+"')";
  connection.query(query,function(err,rows,fields){
     if(err){
      console.log(err.message);
     }
     else{
      res.send("Inserted");
     }
  })
})

app.get('/update_game_history_details/:group_id/:deck_id/:lang_id/:start_date/:time/:duration/:feedback/:score/:no_of_turns/:game_id',function(req,res){
  var update_query="update game_history set group_id='"+req.params.group_id+"',deck_id='"+req.params.deck_id+"',lang_id='"+req.params.lang_id+"',start_date='"+req.params.start_date+"',time='"+req.params.time+"',duration='"+req.params.duration+"',feedback='"+req.params.feedback+"',score='"+req.params.score+"',no_of_turns='"+req.params.no_of_turns+"' where game_id="+req.params.game_id+"";
  connection.query(update_query,function(err,rows,fields){
    if(err){
      console.log(err.message);
    }
    else{
      res.send("Updated");
    }
  })
})

app.get("/delete_game_history_details/:status/:game_id",function(req,res){
  var status="";
  if(req.params.status=="A"){
status="I";
  }
  else{
    status="A";
  }
  var delete_query="update game_history set Status='"+status+"' where game_id="+req.params.game_id+"";
  connection.query(delete_query,function(err,rows,fields){
    if(err){
      console.log(err.message);
    }
    else{
      res.send("Deleted");
    }
  })
})


app.get("/game_history_details",function(req,res){
  var query="SELECT game_history.game_id,game_history.group_id,player_group.grp_name,game_history.player_id,players.player_id,players.name,game_history.deck_id,deck.deck_theme,deck.deck_desc,game_history.lang_id,language.language,game_history.start_date,game_history.time,game_history.duration ,game_history.feedback,game_history.score,game_history.no_of_turns,game_history.Status FROM game_history LEFT JOIN player_group ON player_group.grp_id =game_history.group_id LEFT JOIN players ON players.player_id=game_history.player_id LEFT JOIN deck ON deck.DeckID = game_history.deck_id LEFT JOIN language ON language.lang_id=game_history.lang_id";
  connection.query(query,function(err,rows,fields){
    if(err){
      console.log(err.message);
    }
    else {
      res.send(JSON.stringify(rows));
    }
  })
})
/* End group_details */

/* Settings_details */

app.post("/add_settings_details",urlencodedParser,function(req,res){



  var query="insert into settings(deck_id,maxnoofplayerpergroup,maxnoofcardspergroup,cardsvisibility,lang_id,backgroundmusic,changeorder,image_url,Status)values('"+req.body.deck_id+"','"+req.body.maxnoofplayerpergroup+"','"+req.body.maxnoofcardspergroup+"','"+req.body.cardsvisibility+"','"+req.body.lang_id+"','"+req.body.backgroundmusic+"','"+req.body.changeorder+"','"+req.body.image_url+"','"+req.body.Status+"')";
  connection.query(query,function(err,rows,fields){
     if(err){
      console.log(err.message);
     }
     else{
      res.send("Inserted");
     }
  })
  
})

app.get('/update_settings_details/:deck_id/:maxnoofplayerpergroup/:maxnoofcardspergroup/:cardsvisibility/:lang_id/:backgroundmusic/:changeorder/:image_url/:Settingid',function(req,res){
  var update_query="update settings set deck_id='"+req.params.deck_id+"',maxnoofplayerpergroup='"+req.params.maxnoofplayerpergroup+"',maxnoofcardspergroup='"+req.params.maxnoofcardspergroup+"',cardsvisibility='"+req.params.cardsvisibility+"',lang_id='"+req.params.lang_id+"',backgroundmusic='"+req.params.backgroundmusic+"',changeorder='"+req.params.changeorder+"',image_url='"+req.params.image_url+"'where Settingid="+req.params.Settingid+"";
  connection.query(update_query,function(err,rows,fields){
    if(err){
      console.log(err.message);
    }
    else{
      res.send("Updated");
    }
  })
})

app.get("/delete_settings_details/:status/:Settingid",function(req,res){
  var status="";
  if(req.params.status=="A"){
status="I";
  }
  else{
    status="A";
  }
  var delete_query="update settings set Status='"+status+"' where Settingid="+req.params.Settingid+"";
  connection.query(delete_query,function(err,rows,fields){
    if(err){
      console.log(err.message);
    }
    else{
      res.send("Deleted");
    }
  })
})

/* End Settings_details */
/*
select system_user.user_name,system_user.password,system_user.Status as userstatus,rolemaster.Role as rolename,rolemaster.Status as rolestatus from system_user LEFT JOIN rolemaster ON system_user.user_type=rolemaster.Roleid WHERE system_user.Status='A' OR rolemaster.Status='A' OR system_user.password='Jefin' OR system_user.user_name='123'
*/
/*login api*/
app.get("/login_details/:password/:username",function(req,res){

  console.log(req.params.password);
  var encrypt_password=encrypt(req.params.password.toString());
  console.log(encrypt_password);
 var query="select system_user.userid,system_user.user_type, system_user.user_name,system_user.password,system_user.Status as userstatus,rolemaster.Status as rolestatus,rolemaster.Role as rolename from system_user LEFT JOIN rolemaster ON system_user.user_type=rolemaster.Roleid WHERE system_user.Status='A' AND system_user.password='"+encrypt_password+"' AND system_user.user_name='"+req.params.username+"'";
 console.log(query);
 connection.query(query,function(err,rows,fields){
  if(err){
    console.log(err.message);
  }
  else{
    res.send(JSON.stringify(rows));
    
  }
 })
})


/*userpermission api*/

app.get('/getpermission/:RoleId',function(req,res){
  var update_query="select * from userpermission where RoleId='"+req.params.RoleId+"'";
  connection.query(update_query,function(err,rows,fields){
    if(err){
      console.log(err.message);
    }
    else{
     res.send(JSON.stringify(rows));
    }
  })
})




/* Player Login*/
app.get("/playerlogin/:username/:password",function(req,res){
  // var encrypt_pass=encrypt(req.params.password.toString());
 var query="select players.*,fb_users.user_id as provider from players left join fb_users on fb_users.user_id=players.player_id  where email_id='"+req.params.username+"' AND password='"+req.params.password+"'";

 // var query="select * from players where email_id='"+req.params.username+"' AND password='"+req.params.password+"'";
 connection.query(query,function(err,rows,fields){
  if(err){
    console.log(err.message);
  }
  else if(rows.length>0){
    console.log("rows",rows);
    // res.send(JSON.stringify(rows));
    // var lastplayed_query="SELECT * FROM `logfile` WHERE logfile.playerid='"+rows[0].player_id+"'";
 for(k=0;k<rows.length;k++){
  rows[k].img_url=encodeURIComponent(encodeURIComponent(rows[k].img_url));
 }
    var lastplayed_query="SELECT logfile.*,game_master.gamemode,game_master.game_name FROM `logfile` LEFT JOIN game_master ON logfile.game_id=game_master.game_id WHERE logfile.playerid='"+rows[0].player_id+"'";

    connection.query(lastplayed_query,function(err,queryresult,fields){
      if(err){
        console.log(err.message);
      }
      else if(queryresult.length>0){

        rows[0]["game_mode"]=queryresult[0].gamemode,
        rows[0]["game_name"]=queryresult[0].game_name,
        rows[0]["lastplayed"]=queryresult;
        res.send(rows);
      }
      else{
        res.send(rows);
      }
    
    })

    
  }
  else{
    res.send("Invalid");
  }
 })
})

app.post("/getAllCards",function(req,res){
  console.log(req.body.languageArray);
  var languageArrayDetails="";
  for(l=0;l<req.body.languageArray.length;l++){

      if(l>=req.body.languageArray.length-1){
        languageArrayDetails+="deck.DeckID="+req.body.deckid+"  and card.Type='B' and card.Status='A' and  word.Status = 'A' and language.lang_id="+req.body.languageArray[l]+"";
      }else{
        languageArrayDetails+="deck.DeckID="+req.body.deckid+"  and card.Type='B' and card.Status='A' and  word.Status = 'A' and language.lang_id="+req.body.languageArray[l]+" or ";
      }

  }
 var cardarray=[];
  var cardobj={};
  var languageCards={};
  var query="select deck.DeckID,card.card_name,card.spiritual,card.self_score,card.social_score,card.family_score,card.professional_score,card.img_url,card.card_id,language.lang_id,language.language,word.word,word.synonym FROM deck LEFT JOIN card ON deck.DeckID=card.deck_id LEFT JOIN word ON card.card_id=word.card_id LEFT JOIN language ON language.lang_id=word.lang_id WHERE "+languageArrayDetails+"";
  console.log(query);
  connection.query(query,function(err,rows,fields){
    if(err){
      console.log(err.message);
    }
    else {
      if(rows.length>0){
        async.forEachOf(rows,function (data, index ,next) {
        rows[index]['img_url']=imgURL+rows[index]['img_url'];
        scoreobj={};
        var query="SELECT score.score_id,score.card_id,score.cat_id,score.score,cattheme.category as title from score inner join cattheme ON score.cat_id=cattheme.cattheme_id and cattheme.status='A' WHERE score.card_id="+rows[index]["card_id"]+"";
        console.log(query);
        connection.query(query,function(err,rows1,fields){
          if(err){
            console.log(err.message);
          }
          else{
            console.log(rows);
            rows[index].category=rows1;
            // rows[index].scoredata=scoreobj;
          }
          next();
        })
      },function(err){
        // res.send(rows);
         async.forEachOf(rows,function (data, index ,next) {
        if(languageCards[rows[index].lang_id] == undefined){
          languageCards[rows[index].lang_id]=[];
          languageCards[rows[index].lang_id].push(rows[index]);
        }else{
          languageCards[rows[index].lang_id].push(rows[index]);
        }
        next();
      },function(err){
        res.send(languageCards);
      })
      })
      //
    }else{
      res.send(rows);
    }
//       for(i=0;i<rows.length;i++){
//         if(rows[i].img_url){
//         // var imgurl=base64_encode("uploads/"+rows[i].img_url);
//         // console.log(imgurl);
//         // rows[i].img_url="data:image/jpeg;base64,"+imgurl;
   
// cardarray.push(rows[i])
//  }
//       }
//       async.forEachOf(cardarray,function (data, index ,next) {
//         cardarray[index]['img_url']=imgURL+cardarray[index]['img_url'];
//         scoreobj={};
//         var query="SELECT score.score_id,score.card_id,score.cat_id,score.score,cattheme.category as title from score inner join cattheme ON score.cat_id=cattheme.cattheme_id and cattheme.status='A' WHERE score.card_id="+cardarray[index]["card_id"]+"";
//         console.log(query);
//         connection.query(query,function(err,rows,fields){
//           if(err){
//             console.log(err.message);
//           }
//           else{
//             cardarray[index].category=rows;
//             // cardarray[index].scoredata=scoreobj;
//           }
//           next();
//         })
//       },function(err){
//         res.send(cardarray);
//       })
    }
  })
})

app.get("/getcard1/:deckid/:langid/:player_id",function(req,res){
  var cardarray=[];
  var cardobj={};
  var query="select deck.DeckID,card.card_name,card.spiritual,card.self_score,card.social_score,card.family_score,card.professional_score,card.img_url,card.card_id,language.lang_id,language.language,word.word,word.synonym FROM deck LEFT JOIN card ON deck.DeckID=card.deck_id LEFT JOIN word ON card.card_id=word.card_id LEFT JOIN language ON language.lang_id=word.lang_id WHERE deck.DeckID='"+req.params.deckid+"' and language.lang_id='"+req.params.langid+"' and card.Type='B' and card.Status='A' and  word.Status = 'A' UNION select deck.DeckID,card.card_name,card.spiritual,card.self_score,card.social_score,card.family_score,card.professional_score,card.img_url,card.card_id,language.lang_id,language.language,word.word,word.synonym FROM deck LEFT JOIN card ON deck.DeckID=card.deck_id INNER JOIN transactionrecord ON transactionrecord.productId=card.productID and transactionrecord.purchaseState=0  LEFT JOIN word ON card.card_id=word.card_id LEFT JOIN language ON language.lang_id=word.lang_id WHERE deck.DeckID='"+req.params.deckid+"' and language.lang_id='"+req.params.langid+"' and card.Type='P' and card.Status='A' and  word.Status = 'A'  and transactionrecord.playerid="+req.params.player_id+"";
  connection.query(query,function(err,rows,fields){
    if(err){
      console.log(err.message);
    }
    else {
      for(i=0;i<rows.length;i++){
        if(rows[i].img_url){
        // var imgurl=base64_encode("uploads/"+rows[i].img_url);
        // console.log(imgurl);
        // rows[i].img_url="data:image/jpeg;base64,"+imgurl;
   
cardarray.push(rows[i])
 }
      }
      async.forEachOf(cardarray,function (data, index ,next) {
        cardarray[index]['img_url']=imgURL+cardarray[index]['img_url'];
        scoreobj={};
        var query="SELECT score.score_id,score.card_id,score.cat_id,score.score,cattheme.category as title from score inner join cattheme ON score.cat_id=cattheme.cattheme_id and cattheme.status='A' WHERE score.card_id="+cardarray[index]["card_id"]+"";
        console.log(query);
        connection.query(query,function(err,rows,fields){
          if(err){
            console.log(err.message);
          }
          else{
            cardarray[index].category=rows;
            // cardarray[index].scoredata=scoreobj;
          }
          next();
        })
      },function(err){
        res.send(cardarray);
      })
    }
  })
})
app.get("/getcard/:deckid/:langid",function(req,res){
  var cardarray=[];
  var cardobj={};
  var query="select deck.DeckID,card.card_name,card.spiritual,card.self_score,card.social_score,card.family_score,card.professional_score,card.img_url,card.card_id,language.lang_id,language.language,word.word,word.synonym FROM deck LEFT JOIN card ON deck.DeckID=card.deck_id LEFT JOIN word ON card.card_id=word.card_id LEFT JOIN language ON language.lang_id=word.lang_id WHERE deck.DeckID='"+req.params.deckid+"' and language.lang_id='"+req.params.langid+"' and card.Type='B' and card.Status='A' and  word.Status = 'A'";
  connection.query(query,function(err,rows,fields){
    if(err){
      console.log(err.message);
    }
    else {
      for(i=0;i<rows.length;i++){
        if(rows[i].img_url){
        // var imgurl=base64_encode("uploads/"+rows[i].img_url);
        // console.log(imgurl);
        // rows[i].img_url="data:image/jpeg;base64,"+imgurl;
   
cardarray.push(rows[i])
 }
      }
      async.forEachOf(cardarray,function (data, index ,next) {
        cardarray[index]['img_url']=imgURL+cardarray[index]['img_url'];
        scoreobj={};
        var query="SELECT score.score_id,score.card_id,score.cat_id,score.score,cattheme.category as title from score inner join cattheme ON score.cat_id=cattheme.cattheme_id and cattheme.status='A' WHERE score.card_id="+cardarray[index]["card_id"]+"";
        console.log(query);
        connection.query(query,function(err,rows,fields){
          if(err){
            console.log(err.message);
          }
          else{
            cardarray[index].category=rows;
            // cardarray[index].scoredata=scoreobj;
          }
          next();
        })
      },function(err){
        res.send(cardarray);
      })
    }
  })
})
app.get("/getadmin/:playerid",function(req,res){
 var query="SELECT playergroupdetails.grp_id,player_group.grp_name,player_group.group_head,players.name,playergroupdetails.player_id from playergroupdetails INNER JOIN player_group  ON playergroupdetails.grp_id=player_group.grp_id INNER JOIN players ON playergroupdetails.player_id=players.player_id WHERE playergroupdetails.player_id="+req.params.playerid+"";
  console.log(query);
 connection.query(query,function(err,rows,fields){
   if(err){
     console.log(err.message);
   }
   else {
     res.send(JSON.stringify(rows));
   }
 })
})



app.get("/back_card",function(req,res){
  var query="select * from backcard";
  connection.query(query,function(err,rows,fields){
    if(err){
      console.log(err.message);
    }
    else{
     res.send(JSON.stringify(rows));
    }
  })
})


/*userpermission api*/

app.get("/getpermission",function(req,res){
  var query="select rolemaster.Role, userpermission.allowdel, userpermission.RoleId, userpermission.allowdel ,userpermission.allowedit,userpermission.allowview, userpermission.allowadd FROM userpermission LEFT JOIN rolemaster ON userpermission.RoleId = rolemaster.Roleid";
  connection.query(query,function(err,rows,fields){
    if(err){
      console.log(err.message);
    }
    else{
     res.send(JSON.stringify(rows));
    }
  })
})



app.post("/insertpermission",urlencodedParser,function(req,res){
  var query1 = "select * from userpermission where Roleid = '"+req.body.role_id+"'";
  connection.query(query1,function(err,rows,fields){
    if(err){
      console.log(err.message)
    }
    else if(rows.length>0){
      res.send("permisson exists")
    }
    else
    {
      var query="insert into userpermission(RoleId, allowdel, allowedit, allowview, allowadd)values('"+req.body.role_id+"','"+req.body.allowdel+"','"+req.body.allowedit+"' ,'"+req.body.allowview+"','"+req.body.alloweadd+"')";
  connection.query(query,function(err,rows,fields){
     if(err){
      console.log(err.message);
     }
     else{
      res.send("Inserted");
     }
  })
    }
  })
  
})

app.get('/update_permission/:RoleId/:allowdel/:allowedit/:allowview/:allowadd',function(req,res){
  var update_query="update userpermission set allowdel='"+req.params.allowdel+"',allowedit='"+req.params.allowedit+"',allowview='"+req.params.allowview+"',allowadd='"+req.params.allowadd+"' where RoleId="+req.params.RoleId+"";
  connection.query(update_query,function(err,rows,fields){
    if(err){
      console.log(err.message);
    }
    else{
      res.send("Updated");
    }
  })
})



/*security question*/

app.post("/insert_question",urlencodedParser,function(req,res){

  var query="insert into answer(ans1,ans2,ans3,ans4,playerid,ques1,ques2,ques3,ques4)values('"+req.body.profession+"','"+req.body.vehicle+"','"+req.body.qualification+"','"+req.body.bedroom+"','"+req.body.playerid+"','1','2','3','4')";
  console.log(query);
  connection.query(query,function(err,rows,fields){
     if(err){
      console.log(err.message);
     }
     else{
      res.send("Inserted");
     }
  })
})



/*single palyer histroy*/

// SELECT * FROM singleplayer_history
  
  app.get("/getsinglefeedback",function(req,res){
  var query="select *,card.card_name , players.name from singleplayer_history LEFT JOIN players on players.player_id=singleplayer_history.playerid LEFT JOIN card ON card.card_id=singleplayer_history.cardid group by playerid";
  connection.query(query,function(err,rows,fields){
    if(err){
      console.log(err.message);
    }
    else{
     res.send(JSON.stringify(rows));
    }
  })
})


app.get("/getprioritycard/:playerid/",function(req,res){
  var query="select card.card_name,card.img_url,singleplayer_history.id,players.name,players.nickname,singleplayer_history.id,singleplayer_history.playerid,singleplayer_history.cardid,singleplayer_history.cardpriority,singleplayer_history.score,singleplayer_history.duration,singleplayer_history.feedback FROM singleplayer_history LEFT JOIN card ON card.card_id=singleplayer_history.cardid LEFT JOIN players ON players.player_id=singleplayer_history.playerid WHERE singleplayer_history.playerid='"+req.params.playerid+"'";
  connection.query(query,function(err,rows,fields){
    if(err){
      console.log(err.message);
    }
    else{
     res.send(JSON.stringify(rows));
    }
  })
})



// UPDATE `singleplayer_history` SET `feedback` = 'Do Well next time' WHERE `singleplayer_history`.`id` = 2


app.get('/update_feedback/:id/:feedback',function(req,res){
  var update_query="update singleplayer_history set feedback='"+req.params.feedback+"' where id="+req.params.id+"";
  connection.query(update_query,function(err,rows,fields){
    if(err){
      console.log(err.message);
    }
    else{
      res.send("Updated");
    }
  })
})



// INSERT INTO `singleplayer_history` (`id`, `playerid`, `cardid`, `cardpriority`, `score`, `duration`, `feedback`) VALUES (NULL, '', '', '', '', '', '')

// INSERT INTO `singleplayerfeedback` (`gameid`, `playerid`, `cardid_priority1`, `cardid_priority2`, `cardid_priority3`, `cardid_priority4`, `cardid_priority5`, `score`, `duration`, `feedback`, `datetime`, `feedback_givenbyid`) VALUES (NULL, '', '', '', '', '', '', '', '', '', '', '')


app.post("/insert_singlefeed",urlencodedParser,function(req,res){
  console.log(req.body.playerid);
  var query="insert into singleplayerfeedback(playerid,cardid_priority1,cardid_priority2,cardid_priority3,cardid_priority4,cardid_priority5,score,duration,datetime)values('"+req.body.playerid+"','"+req.body.cardid_priority1+"','"+req.body.cardid_priority2+"','"+req.body.cardid_priority3+"','"+req.body.cardid_priority4+"','"+req.body.cardid_priority5+"','"+req.body.score+"','"+req.body.duration+"',now())";
  console.log(query);
  connection.query(query,function(err,rows,fields){
     if(err){
      console.log(err.message);
     }
     else{
      res.send("Inserted");
     }
  })
})

/*group feedback histroy*/

  
  app.get("/getgroupfeedback",function(req,res){
  var query="select players.*,group_history.groupid,group_history.playerid,group_history.playerscore,group_history.date,player_group.grp_name FROM group_history  LEFT JOIN player_group ON group_history.groupid=player_group.grp_id LEFT JOIN players ON group_history.playerid=players.player_id";
  connection.query(query,function(err,rows,fields){
    if(err){
      console.log(err.message);
    }
    else{
     res.send(JSON.stringify(rows));
    }
  })
})

// UPDATE `group_history` SET `grpfeedback` = 'played nic' WHERE `group_history`.`groupid` = 3
  app.get('/update_grpfeed/:groupid/:feedback',function(req,res){
  var update_query="update group_history set grpfeedback='"+req.params.feedback+"' where groupid="+req.params.groupid+"";
  connection.query(update_query,function(err,rows,fields){
    if(err){
      console.log(err.message);
    }
    else{
      res.send("Updated");
    }
  })
})


/*category*/


 app.get("/getcategory",function(req,res){
  var query="SELECT  * from category";
  connection.query(query,function(err,rows,fields){
    if(err){
      console.log(err.message);
    }
    else{
     res.send(JSON.stringify(rows));
    }
  })
})


 /*simplefeedback*/


 app.get("/simplefeedback",function(req,res){
  var query="select category.catid,simple_feedback.feedbackid,category.category_name,simple_feedback.min,simple_feedback.max,simple_feedback.simple_feedback,simple_feedback.Status FROM simple_feedback LEFT JOIN category ON simple_feedback.cat_id=category.catid";
  connection.query(query,function(err,rows,fields){
    if(err){
      console.log(err.message);
    }
    else{
     res.send(JSON.stringify(rows));
    }
  })
})

 app.get("/view_category",function(req,res){
  var query="SELECT * FROM category where status='A'";
  connection.query(query,function(err,rows,fields){
    if(err){
      console.log(err.message);
    }
    else{
     res.send(JSON.stringify(rows));
    }
  })
})

 
// new api


 app.get("/view_category/:deckid",function(req,res){
  var query="SELECT * FROM cattheme where deck_id = "+req.params.deckid+" and status='A'";
  connection.query(query,function(err,rows,fields){
    if(err){
      console.log(err.message);
    }
    else{
     res.send(JSON.stringify(rows));
    }
  })
})



app.post("/insertcategory",urlencodedParser,function(req,res){
   var duplicate_sql="select * from category where category_name='"+req.body.Role+"'";
     connection.query(duplicate_sql,function(err,rows,fields){
     if(err)
     {
      console.log(err.message);
     }
     else if(rows.length>0){
      res.send("Role Already Exist");
     }
     else
     {
  var query="insert into category(category_name,status)values('"+req.body.Role+"','"+req.body.Status+"')";
  connection.query(query,function(err,rows,fields){
     if(err){
      console.log(err.message);
     }
     else{
      res.send("Inserted");
     }
  })
}
})
   })


app.get('/update_category/:Role/:catid',function(req,res){
var duplicate_sql="select * from category where category_name='"+req.params.Role+"'";
      connection.query(duplicate_sql,function(err,rows,fields){
     if(err)
     {
      console.log(err.message);
     }
     else if(rows.length>0){
      console.log("already");
      res.send("Role Already Exist");
     }
     else
     {
      console.log("updateddd");
      var update_query="update category set category_name='"+req.params.Role+"' where catid="+req.params.catid+"";
      connection.query(update_query,function(err,rows,fields){
      if(err){
      console.log(err.message);
    }
    else{
      res.send("Updated");
    }
  })
     }    
})
})


app.get("/delete_card_details/:status/:card_id",function(req,res){
  var status="";
  if(req.params.status=="A"){
status="I";
  }
  else{
    status="A";
  }
  var delete_query="update card set Status='"+status+"' where card_id="+req.params.card_id+"";
  connection.query(delete_query,function(err,rows,fields){
    if(err){
      console.log(err.message);
    }
    else{
      res.send("Deleted");
    }
  })
})
app.get("/delete_category/:status/:catid",function(req,res){
  var status="";
  if(req.params.status=="A"){
status="I";
  }
  else{
    status="A";
  }
  var delete_query="update category set status='"+status+"' where catid="+req.params.catid+"";
  connection.query(delete_query,function(err,rows,fields){
    if(err){
      console.log(err.message);
    }
    else{
      res.send("Deleted");
    }
  })
})


 // INSERT INTO `simple_feedback` (`feedbackid`, `min`, `max`, `simple_feedback`, `Status`) VALUES (NULL, ' ', ' ', '', '')

  app.post("/insertsimfeedback",urlencodedParser,function(req,res){
console.log(req.body);
console.log(req.body.min);
var duplicate_sql="select * from simple_feedback where min="+req.body.min+" and max = '"+req.body.max+"' and cat_id="+req.body.category+"";
     connection.query(duplicate_sql,function(err,rows,fields){
     if(err)
     {
      console.log(err.message);
     }
     else if(rows.length>0){
      res.send("Min and Max for this Category Already Exist");
     }
     else
     {



  var query="insert into simple_feedback(cat_id,min,max,simple_feedback,Status)values("+req.body.category+",'"+req.body.min+"','"+req.body.max+"','"+req.body.simplefeedback+"','"+req.body.status+"')";
  connection.query(query,function(err,rows,fields){
     if(err){
      console.log(err.message);
     }
     else{
      res.send("Inserted");
     }
  })

}
})

})


app.get('/update_simplefeed/:category/:min/:max/:simple_feedback/:feedbackid',function(req,res){
  var duplicate_sql="select * from simple_feedback where min="+req.params.min+" and max = '"+req.params.max+"' and cat_id="+req.params.category+"";
     connection.query(duplicate_sql,function(err,rows,fields){
     if(err)
     {
      console.log(err.message);
     }
     else if(rows.length>0){
      res.send("Min and Max for this Category Already Exist");
     }
     else
     {


  var update_query="update simple_feedback set cat_id="+req.params.category+" ,min='"+req.params.min+"', max='"+req.params.max+"', simple_feedback='"+req.params.simple_feedback+"' where feedbackid="+req.params.feedbackid+"";
  connection.query(update_query,function(err,rows,fields){
    if(err){
      console.log(err.message);
    }
    else{
      res.send("Updated");
    }
  })
}
})
   })


app.get("/delete_sfeed/:status/:feedbackid",function(req,res){
  var status="";
  if(req.params.status=="A"){
status="I";
  }
  else{
    status="A";
  }
  var delete_query="update simple_feedback set Status='"+status+"' where feedbackid="+req.params.feedbackid+"";
  connection.query(delete_query,function(err,rows,fields){
    if(err){
      console.log(err.message);
    }
    else{
      res.send("Deleted");
    }
  })
})


/*player online*/

app.get("/online_status",function(req,res){
  var query="SELECT * FROM players WHERE online_status = 'true'";
  connection.query(query,function(err,rows,fields){
    if(err){
      console.log(err.message);
    }
    else{
     res.send(JSON.stringify(rows));
    }
  })
})


// UPDATE `players` SET `password` = '1234 ', `Status` = 'A ', `online_status` = 'true ' WHERE `players`.`email_id` = 'raj@gmail.com'

app.get('/update_palyeronstat/:player_id/:online_status',function(req,res){
  var update_query="update players set online_status='"+req.params.online_status+"' where player_id="+req.params.player_id+"";
  connection.query(update_query,function(err,rows,fields){
    if(err){
      console.log(err.message);
    }
    else{
      res.send("Updated");
    }
  })
})



/*getsystemuser feeddetails*/

// system_user

app.get("/playersdetails/:userid",function(req,res){
  var query="SELECT * FROM system_user WHERE userid = '"+req.params.userid+"'";
  connection.query(query,function(err,rows,fields){
    if(err){
      console.log(err.message);
    }
    else{
     res.send(JSON.stringify(rows));
    }
  })
})



app.get("/displaynewfeed/:fromdate/:todate",function(req,res){
  var query="SELECT *, feedbackgivenby.user_name,feedbackgivenby.user_type,card1.card_name ,card1.img_url,card2.card_name,card2.img_url,card3.card_name,card3.img_url,card4.card_name,card4.img_url,card5.card_name,card5.img_url,myplayer.name,singleplayerfeedback.gameid,singleplayerfeedback.playerid FROM singleplayerfeedback INNER JOIN card as card1 on card1.card_id=singleplayerfeedback.cardid_priority1 INNER JOIN card as card2 on card2.card_id=singleplayerfeedback.cardid_priority2 INNER JOIN players as myplayer on myplayer.player_id = singleplayerfeedback.playerid INNER JOIN card as card3 on card3.card_id=singleplayerfeedback.cardid_priority3 INNER JOIN card as card4 on card4.card_id=singleplayerfeedback.cardid_priority4 INNER JOIN card as card5 on card5.card_id=singleplayerfeedback.cardid_priority5 LEFT JOIN system_user as feedbackgivenby on feedbackgivenby.userid = singleplayerfeedback.feedback_givenbyid WHERE singleplayerfeedback.datetime BETWEEN '"+req.params.fromdate+"' AND '"+req.params.todate+"' ORDER BY gameid DESC ";
  connection.query(query,function(err,rows,fields){
    if(err){
      console.log(err.message);
    }
    else{
      // console.log(rows);
     res.send(JSON.stringify(rows));
    }
  })
})

app.get("/displaynewgame_feed/:gameid",function(req,res){
  var query="SELECT feedbackgivenby.user_name,feedbackgivenby.user_type,card1.card_name as card1 ,card1.img_url as imgurl1,card2.card_name as card2,card2.img_url as imgurl2,card3.card_name as card3,card3.img_url as imgulr3,card4.card_name as card4,card4.img_url as imgurl4,card5.card_name as card5,card5.img_url as imgurl5,myplayer.name,singleplayerfeedback.gameid,singleplayerfeedback.playerid FROM singleplayerfeedback INNER JOIN card as card1 on card1.card_id=singleplayerfeedback.cardid_priority1 INNER JOIN card as card2 on card2.card_id=singleplayerfeedback.cardid_priority2 INNER JOIN players as myplayer on myplayer.player_id = singleplayerfeedback.playerid INNER JOIN card as card3 on card3.card_id=singleplayerfeedback.cardid_priority3 INNER JOIN card as card4 on card4.card_id=singleplayerfeedback.cardid_priority4 INNER JOIN card as card5 on card5.card_id=singleplayerfeedback.cardid_priority5 LEFT JOIN system_user as feedbackgivenby on feedbackgivenby.userid = singleplayerfeedback.feedback_givenbyid WHERE singleplayerfeedback.gameid="+req.params.gameid+"";
  connection.query(query,function(err,rows,fields){
    if(err){
      console.log(err.message);
    }
    else{
      // console.log(rows);
     res.send(JSON.stringify(rows));
    }
  })
})


app.get("/displayinstruction/:deckid/:langid/:module",function(req,res){
  var query="SELECT * from instruction where deck_id="+req.params.deckid+" AND lang_id="+req.params.langid+" AND module='"+req.params.module+"' AND Status='A'";
  connection.query(query,function(err,rows,fields){
    if(err){
      console.log(err.message);
    }
    else{
      // console.log(rows);
     res.send(JSON.stringify(rows));
    }
  })
})



/*gamefeedback engine*/

app.get("/dispfeegivenby/:feedbackgivenby",function(req,res){
  var query="SELECT singleplayerfeedback.feedback,singleplayerfeedback.datetime,singleplayerfeedback.playerid,players.name FROM singleplayerfeedback LEFT JOIN players ON players.player_id =singleplayerfeedback.playerid where singleplayerfeedback.feedback_givenbyid = "+req.params.feedbackgivenby+"";
  connection.query(query,function(err,rows,fields){
    if(err){
      console.log(err.message);
    }
    else{
      // console.log(rows);
     res.send(JSON.stringify(rows));
    }
  })
})

/* select category lists */
app.get("/categorylists",function(req,res){
  var query="SELECT * FROM category WHERE STATUS='A'";
  connection.query(query,function(err,rows,fields){
    if(err){
      console.log(err.message);
    }
    else{
      // console.log(rows);
     res.send(JSON.stringify(rows));
    }
  })
})

/* End */
/*update token*/

// UPDATE `players` SET `password` = '1234 ', `token` = ' ' WHERE `players`.`email_id` = 'Princek@gmail.com' player_id

app.post('/playGroupInitiate',urlencodedParser,function(req,res){
  // SNSLibrary.
  // console.log("playobj",req.body);
  var userdata={additionalData:req.body.playobj,msg:req.body.msg}
  SNSLibrary.sendMessage(req.body.token,userdata,function(err,data){
    if(err){
      // console.log(err);
      res.send('error');
    }else{
      // console.log(data);
      res.send("Sent")
    }
  })
})

/* End */
/*update token*/
app.post('/inviteGroup',urlencodedParser,function(req,res){
    // var content=req.body.additonalData;
    // var msg=req.body.msg;
    // var playerid=req.body.playerid;
    // var requestid=req.body.request_player_id;
    // var requestJoin=req.body.requestJoin;
    console.log(req.body);
    var msgData={msg:req.body.msg,additionalData:req.body};
    // var link='"Urlunique"'+groupid+player_id+requested_player_id+""
      var dup_query="select * from notification where link='"+req.body.link+"'";
connection.query(dup_query,function(err,rows,fields){
     if(err){
      console.log(err.message);
     }
     else if(rows.length>0){
      res.send("Invitation Already Send");
     }
     else
     {
      var query="insert into notification(grp_id,player_id,link,message,requestJoin,reqPlayerID,status)values("+req.body.grp_id+","+req.body.player_id+",'"+req.body.link+"','"+req.body.msg+"','"+req.body.requestJoin+"','"+req.body.reqPlayerID+"','A')";
      console.log(query);
  connection.query(query,function(err,rows,fields){
     if(err){
      // console.log(err.message);
     }
     else{
      // res.send("Inserted");
      SNSLibrary.sendMessage(req.body.token,msgData,function(err,data){
      if(err){
        // console.log(err);
        res.send("Inserted");
      }else{
        // console.log("data");
        res.send("Inserted");
      }
    })
     }
  })
     }
  })  
    
  })
// UPDATE `players` SET `password` = '1234 ', `token` = ' ' WHERE `players`.`email_id` = 'Princek@gmail.com' player_id

app.get("/updatetoken/:player_id/:token",function(req,res){
  // console.log(req.params.token)

  SNSLibrary.getEndpoint(req.params.token,function(err,response){
    var query="";
     if(req.params.token=='null'){
           query="UPDATE players SET  token = '"+req.params.token+"' , online_status='true' WHERE  player_id = "+req.params.player_id+"";
         }

    console.log(response);
    if(err){
     
    }else{
       if(req.params.token!='null'){
           query="UPDATE players SET  token = '"+response.EndpointArn+"' , online_status='true' WHERE  player_id = "+req.params.player_id+"";
         }
  
    }
     connection.query(query,function(err,rows,fields){
       console.log(query);
    if(err){
      console.log(err.message);
    }
    else{
      // console.log(rows);
      // SNSLibrary.getEndpoint()
      console.log(response);
     res.send(response?response.EndpointArn:null);
    }
  })
  })
})
  app.post("/updatetoken1",urlencodedParser,function(req,res){
  // console.log(req.params.token)
console.log(req.body);
  SNSLibrary.getEndpoint(req.body.token,function(err,response){
    var query="";
     if(req.body.token=='null'){
           query="UPDATE players SET  token = '"+req.body.token+"' ,  platform='"+req.body.platform+"' , online_status='true' WHERE  player_id = "+req.body.player_id+"";
         }

    console.log(response);
    if(err){
     
    }else{
       if(req.body.token!='null'){
           query="UPDATE players SET  token = '"+response.EndpointArn+"' , platform='"+req.body.platform+"', online_status='true' WHERE  player_id = "+req.body.player_id+"";
         }
  
    }
     connection.query(query,function(err,rows,fields){
       console.log(query);
    if(err){
      console.log(err.message);
    }
    else{
      // console.log(rows);
      // SNSLibrary.getEndpoint()
     res.send(response.EndpointArn);
    }
  })
  })

  // var query="UPDATE players SET  token = '"+req.params.token+"' , online_status='true' WHERE  player_id = "+req.params.player_id+"";
  // connection.query(query,function(err,rows,fields){
  //   if(err){
  //     console.log(err.message);
  //   }
  //   else{
  //     // console.log(rows);
  //     SNSLibrary.getEndpoint()
  //    // res.send(JSON.stringify(rows));
  //   }
  // })
})

app.post("/add_scores",urlencodedParser,function(req,res){

  var getdetails="select * from card order by card_id desc limit 1";
connection.query(getdetails,function(err,rows,fields){
if(err)
{
console.log(err);
}
else
{
  console.log(rows);
console.log(rows[0].card_id);
console.log(rows[0].deck_id);
console.log(req.body);
var sql = "INSERT INTO score (cat_id,score,deck_id,card_id) VALUES ?";
var values =[];
 for(i=0;i<req.body.length;i++){
    values.push([req.body[i].catid, req.body[i].score,rows[0].deck_id,rows[0].card_id]);
}
console.log(values);
connection.query(sql, [values], function(err) {
    if (err) 
      throw err;
    else
    {
      res.send("insert");
    }
});

}
})

})




/*gametype master api*/
// app.get("/disp_gamemaster",function(req,res){
//   var query="SELECT * FROM game_master";
//   connection.query(query,function(err,rows,fields){
//     if(err){
//       console.log(err.message);
//     }
//     else{
//      res.send(JSON.stringify(rows));
//     }
//   })
// })


// insert

app.post("/insertgametype",urlencodedParser,function(req,res){
  var query1 = "select * from game_master where game_name = '"+req.body.game_name+"'  ";
  connection.query(query1,function(err,rows,fields){
    if(err){
      console.log(err.message)
    }
    else if(rows.length>0){
      res.send("Already Exists")
    }
    else
    {
      if(req.body.setcardonly==undefined){
        req.body.setcardonly=0;
      }
      var query="insert into game_master(gamemode,game_name, min_no_of_card, game_descrip, status,setcategory,setdirectionscore,setquestionbank,setcardonly, priority,  timer,keyword, created_by, created_date)values('"+req.body.gamemode+"','"+req.body.game_name+"','"+req.body.min_no_of_card+"','"+req.body.game_descrip+"','A' ,"+req.body.setcategory+","+req.body.setdirectionscore+","+req.body.setquestionbank+","+req.body.setcardonly+","+req.body.priority+","+req.body.timer+",'"+req.body.gamekey+"','"+req.body.created_by+"',now())";
      console.log(query);
  connection.query(query,function(err,rows,fields){
     if(err){
      console.log(err.message);
     }
     else{
      res.send("Inserted");
     }
  })
    }
  })
  
})


// update

// UPDATE 

app.post('/upd_game_master/',function(req,res){
  console.log(req.body);
//   var query1 = "select * from game_master where gamemode='"+req.body.upd_gamemode+"' and game_name='"+req.body.game_name+"'";
//   connection.query(query1,function(err,rows,fields){
//     if(err){
//       console.log(err.message)
//     }
//     else if(rows.length>0){
//       res.send("Already Exists")
//     }
// else{
 var query="update game_master set gamemode='"+req.body.upd_gamemode+"',game_name='"+req.body.game_name+"',min_no_of_card='"+req.body.min_no_of_card+"',game_descrip='"+req.body.game_descrip+"',setcategory="+req.body.setcategory+",setdirectionscore="+req.body.setdirectionscore+",setquestionbank="+req.body.setquestionbank+",keyword='"+req.body.gamekey+"',setcardonly="+req.body.setcardonly+",timer="+req.body.timer+",priority = "+req.body.priority+",created_by = '"+req.body.created_by+"' where game_id="+req.body.game_id+"";
 console.log('query',query);
  connection.query(query,function(err,rows,fields){
if(err){
  console.log(err.message);
}
else if(rows){
  res.send("Updated");

}
else{
  res.send("no data");
}
  })
// }
// })
  
})

// delete


app.get("/delete_gametype/:status/:game_id",function(req,res){
  var status="";
  if(req.params.status=="A"){
status="I";
  }
  else{
    status="A";
  }
  var delete_query="update game_master set status='"+status+"' where game_id="+req.params.game_id+"";
  connection.query(delete_query,function(err,rows,fields){
    if(err){
      console.log(err.message);
    }
    else{
      res.send("Deleted");
    }
  })
})

/*question bank*/



app.get("/disp_questionbank",function(req,res){
  var query="SELECT question_bank.*,deck.deck_theme,game_master.game_name,language.language FROM question_bank LEFT JOIN deck ON deck.DeckID = question_bank.deck_id LEFT JOIN language ON language.lang_id = question_bank.Language LEFT JOIN game_master ON question_bank.gametype_id=game_master.game_id";
  connection.query(query,function(err,rows,fields){
    if(err){
      console.log(err.message);
    }
    else{
     res.send(JSON.stringify(rows));
    }
  })
})



// insert

app.post("/insertquestionbank",urlencodedParser,function(req,res){
  var query1 = "select * from question_bank where deck_id = "+req.body.deck_id+" and ques_bank = '"+req.body.ques_bank+"' and Language = "+req.body.Language+"  and  gametype_id="+req.body.gametype_id+"";
  console.log(query1);
  connection.query(query1,function(err,rows,fields){
    if(err){
      console.log(err.message)
    }
    else if(rows.length>0){
      res.send("Already Exists")
    }
    else
    {
      var query="insert into question_bank(deck_id,gamemode,gametype_id, Language ,ques_bank, description,status, created_date, created_by,theme_id)values('"+req.body.deck_id+"','"+req.body.gamemode+"','"+req.body.gametype_id+"','"+req.body.Language+"','"+req.body.ques_bank+"','"+req.body.description+"','A' ,now(),'"+req.body.created_by+"','"+req.body.theme_id+"')";
  console.log(query);

  connection.query(query,function(err,rows,fields){
     if(err){
      console.log(err.message);
     }
     else{
      res.send("Inserted");
     }
  })
    }
  })
  
})

// UPDATE 

app.post('/upd_quesbank/',function(req,res){
   console.log(req.body);
//  var query1 = "select * from question_bank where deck_id = "+req.body.deck_id+" and ques_bank = '"+req.body.ques_bank+"' and Language = "+req.body.Language+" ";
//   connection.query(query1,function(err,rows,fields){
//     if(err){
//       console.log(err.message)
//     }
//     else if(rows.length>0){
//       res.send("Already Exists")
//     }
// else{
 var query='update question_bank set deck_id='+req.body.deck_id+',Language= '+req.body.Language+'  ,ques_bank="'+req.body.ques_bank+'",gamemode="'+req.body.gamemode+'",gametype_id="'+req.body.gametype_id+'",description="'+req.body.description+'",created_by = "'+req.body.created_by+'",theme_id="'+req.body.theme_id+'" where quesb_id= '+req.body.quesb_id+'';
 console.log(query);
  connection.query(query,function(err,rows,fields){
if(err){
  console.log(err.message);
}
else if(rows){
  res.send("Updated");

}
else{
  res.send("no data");
}
  })
// }
// })
  
})


// delete


app.get("/delete_quesbank/:status/:quesb_id",function(req,res){
  var status="";
  if(req.params.status=="A"){
status="I";
  }
  else{
    status="A";
  }
  var delete_query="update question_bank set status='"+status+"' where quesb_id="+req.params.quesb_id+"";
  connection.query(delete_query,function(err,rows,fields){
    if(err){
      console.log(err.message);
    }
    else{
      res.send("Deleted");
    }
  })
})


// ques_for_quesbank



// insert

app.post("/insert_ques_for_quesbank",urlencodedParser,function(req,res){
     var sql = "INSERT INTO ques_for_questionbank (ques_bank_id,deck_id,gamemode,game_typeid,lang_id,question,status,createdby) VALUES ?";
var values =[];
 for(i=0;i<req.body.length;i++){
    values.push([req.body[i].ques_bank_id, req.body[i].deck_id,req.body[i].gamemode,req.body[i].game_typeid,req.body[i].lang_id,req.body[i].question,'A',req.body[i].createdby]);
}
console.log(values);
connection.query(sql, [values], function(err) {
    if (err) 
      throw err;
    else
    {
      res.send("Inserted");
    }
})
    
})




// update question


// UPDATE `ques_for_questionbank` SET `ques_bank_id` = '6' WHERE `ques_for_questionbank`.`ques_id` = 1;

app.post('/upd_questions/',function(req,res){
   console.log(req.body);
//  var query1 = "select * from ques_for_questionbank where ques_bank_id = "+req.body.ques_bank_id+" and deck_id = '"+req.body.deck_id+"' and game_typeid = "+req.body.game_typeid+" and lang_id = "+req.body.lang_id+" and question = '"+req.body.question+"' ";
//   connection.query(query1,function(err,rows,fields){
//     if(err){
//       console.log(err.message)
//     }
//     else if(rows.length>0){
//       res.send("Already Exists")
//     }
// else{
 var query="update ques_for_questionbank set ques_bank_id="+req.body.ques_bank_id+" , deck_id= "+req.body.deck_id+"  , gamemode = "+req.body.gamemode+",game_typeid= "+req.body.game_typeid+", lang_id="+req.body.lang_id+", question = '"+req.body.question+"' , createdby = '"+req.body.created_by+"' where ques_id= "+req.body.ques_id+" ";
 console.log(query);
  connection.query(query,function(err,rows,fields){
if(err){
  console.log(err.message);
}
else if(rows){
  res.send("Updated");

}
else{
  res.send("no data");
}
  })
// }
// })
  
})






// app.get("/question_list/:deckid/:langid",function(req,res){
//   var query="SELECT question_bank.quesb_id,question_bank.ques_bank FROM `question_bank` WHERE question_bank.deck_id='"+req.params.deckid+"' AND question_bank.Language='"+req.params.langid+"'";
//   connection.query(query,function(err,rows,fields){
//     if(err){
//       console.log(err.message);
//     }
//     else{
//      res.send(JSON.stringify(rows));
//     }
//   })
// })


app.get("/question_list/:deckid/:langid/:gametype_id",function(req,res){
  var query="SELECT quesb_id,ques_bank FROM question_bank WHERE question_bank.deck_id= "+req.params.deckid+"  AND Language= "+req.params.langid+" AND gametype_id='"+req.params.gametype_id+"'";
  connection.query(query,function(err,rows,fields){
    if(err){
      console.log(err.message);
    }
    else{
     res.send(JSON.stringify(rows));
    }
  })
})


// display question

app.get("/dispquesitons",function(req,res){
var query = "SELECT ques_for_questionbank.* , deck.deck_theme,game_master.game_name,question_bank.ques_bank, language.language from ques_for_questionbank LEFT JOIN question_bank ON question_bank.quesb_id = ques_for_questionbank.ques_bank_id LEFT JOIN game_master ON game_master.game_id = ques_for_questionbank.game_typeid LEFT JOIN deck ON deck.DeckID = ques_for_questionbank.deck_id LEFT JOIN language ON language.lang_id = ques_for_questionbank.lang_id";
connection.query(query,function(err,rows,fields){
  if(err){
    console.log(err.message);
  }else{
    res.send(JSON.stringify(rows));
  }
})
})




// delete

app.get("/delete_ques/:status/:ques_id",function(req,res){
  var status="";
  if(req.params.status=="A"){
status="I";
  }
  else{
    status="A";
  }
  var delete_query="update ques_for_questionbank set status='"+status+"' where ques_id="+req.params.ques_id+"";
  connection.query(delete_query,function(err,rows,fields){
    if(err){
      console.log(err.message);
    }
    else{
      res.send("Deleted");
    }
  })
})



// benchmark


// INSERT INTO `benchmark` (`bench_id`, `bench_mark`, `mark`, `color`, `status`, `created_date`, `createdby`) VALUES (NULL, 'Great Decision', '200', '#070ef8', 'A', '2017-09-13', 'sam');

app.get("/disp_benchmark",function(req,res){
var query = "select * from benchmark";
connection.query(query,function(err,rows,fields){
  if(err){
    console.log(err.message);
  }else{
    res.send(JSON.stringify(rows));
  }
})
})


app.post("/insert_benchmark",urlencodedParser,function(req,res){
  var query1 = "select * from benchmark where bench_id = "+req.body.bench_id+" and bench_mark = '"+req.body.bench_mark+"' and mark = "+req.body.mark+" and color = "+req.body.color+" ";
  connection.query(query1,function(err,rows,fields){
    if(err){
      console.log(err.message)
    }
    else if(rows.length>0){
      res.send("Already Exists")
    }
    else
    {
      var query="insert into benchmark(bench_id, bench_mark ,mark, color, status, created_date, createdby)values('"+req.body.bench_id+"',"+req.body.mark+",'"+req.body.mark+"','"+req.body.color+"','A' ,now(),'"+req.body.createdby+"')";
  connection.query(query,function(err,rows,fields){
     if(err){
      console.log(err.message);
     }
     else{
      res.send("Inserted");
     }
  })
    }
  })
  
})


app.post("/insert_benchmarknew",urlencodedParser,function(req,res){
 // '"+req.body.game_id+"','"+req.body.uniqueid+"','"+req.body.player_id+"','"+req.body.quesbank_id+"','"+req.body.ques_id+"','"+req.body.ans_cardid1+"',now()
      var query="insert into benchmark_master( game_mode, deckid ,game_id, cat_id,bench_mark,color,benchmark_title,status, created_date, createdby)VALUES ?";
  console.log(query);

   var values=[];
 var date = new Date();
var newdate=new Date();
    for(i=0;i<req.body.length;i++)
    {
     
      values.push([req.body[i].game_mode,req.body[i].deckid, req.body[i].game_id,req.body[i].cat_id,req.body[i].bench_mark,req.body[i].color,req.body[i].benchmark_title,'A',date,req.body[i].createdby]);
    
    }
console.log(values);
connection.query(query, [values], function(err) {
    if (err) 
      throw err;
    else
    {
      res.send("Inserted");
    }
});
  
})



const company = [{
  "companies": [
    {
      "companyId": 1234123,
      "name": "'KFC'",
      "domain": "'YKK.com'",
      "status": true,
      "adminSupportNumber": "'123",
      "globalSecurityZone": {
        "Cmt": 1,
        "CmtAdmin": 0,
        "Admin": 0,
        "SingleCrisisMode": 0,
        "ClaimsReporting": 1,
        "CrisisReporting": 1,
        "CrisisActivation": 1,
        "CrisisActivationOptions": 1,
        "MeetingCreate": 1,
        "TaskManagement": 1
      }
    },
    {
      "companyId": 1234123,
      "name": "'KFC'",
      "domain": "'YKK.com'",
      "status": true,
      "adminSupportNumber": "'123",
      "globalSecurityZone": {
        "Cmt": 1,
        "CmtAdmin": 0,
        "Admin": 0,
        "SingleCrisisMode": 0,
        "ClaimsReporting": 1,
        "CrisisReporting": 1,
        "CrisisActivation": 1,
        "CrisisActivationOptions": 1,
        "MeetingCreate": 1,
        "TaskManagement": 1
      }
    }
  ]
}]


app.get("/disp_company",function(req,res){

    res.send(JSON.stringify(company));
  

})

app.get("/disp_gametypelist/:gamemode/:deck_id",function(req,res){

// var query = "SELECT * FROM game_master WHERE game_master.gamemode='"+req.params.gamemode+"' and game_master.Status='A'";
var query="SELECT game_master.*,ans_to_ques.gamestatus as gameStatus,ans_to_ques.gameOrder as GameOrder,ans_to_ques.deck_id FROM game_master LEFT JOIN ans_to_ques ON ans_to_ques.game_id=game_master.game_id AND ans_to_ques.deck_id="+req.params.deck_id+" WHERE game_master.gamemode="+req.params.gamemode+" and game_master.Status='A' GROUP BY game_master.game_id ORDER BY ans_to_ques.gameOrder";
console.log(query);
connection.query(query,function(err,rows,fields){
  if(err){
    console.log(err.message);
  }else{
    for(k=0;k<rows.length;k++){
      if(rows[k].gameStatus=='null' || rows[k].gameStatus==null){
        rows[k].gameStatus='I';
        rows[k].game_name='Coming Soon';
        rows[k].GameOrder=6;
      }
    }
    var OrderList = rows.slice(0);
OrderList.sort(function(a,b) {
    return a.GameOrder - b.GameOrder;
});
rows=OrderList;
    res.send(JSON.stringify(rows));
  }
})
})

app.get("/type_list/:gamemode/:gametype",function(req,res){
var query = "SELECT * FROM game_master WHERE game_master.gamemode='"+req.params.gamemode+"' AND game_master.game_id='"+req.params.gametype+"'";
connection.query(query,function(err,rows,fields){
  if(err){
    console.log(err.message);
  }else{
    res.send(JSON.stringify(rows));
  }
})
})

app.get("/updtype_list/:gamemode/:gametype/",function(req,res){
  
var query = "SELECT * FROM game_master WHERE game_master.gamemode='"+req.params.gamemode+"' AND game_master.game_id='"+req.params.gametype+"'";
connection.query(query,function(err,rows,fields){
  if(err){
    console.log(err.message);
  }else{
    res.send(JSON.stringify(rows));
  }
})
})


app.get("/getupdatedval/:deckid/:gamemode/:gametype/",function(req,res){
  
var query = "SELECT * FROM `question_bank` WHERE question_bank.deck_id='"+req.body.deckid+"' AND question_bank.gamemode='"+req.body.gamemode+"' AND question_bank.gametype_id='"+req.body.gametype+"'";
connection.query(query,function(err,rows,fields){
  if(err){
    console.log(err.message);
  }else{
    res.send(JSON.stringify(rows));
  }
})
})





/*gametype master api*/
app.get("/disp_gametype/:gamemode",function(req,res){
  var query="SELECT * FROM game_master where gamemode = "+req.params.gamemode+" and status='A'";
console.log(query);
  connection.query(query,function(err,rows,fields){
    if(err){
      console.log(err.message);
    }
    else{
      console.log(rows);
     res.send(JSON.stringify(rows));
    }
  })
})



app.get("/disp_quesbank/:deckid/:langid",function(req,res){
  
var query = "SELECT * FROM question_bank WHERE question_bank.deck_id='"+req.params.deckid+"' AND question_bank.Language='"+req.params.langid+"'";
connection.query(query,function(err,rows,fields){
  if(err){
    console.log(err.message);
  }else{
    res.send(JSON.stringify(rows));
  }
})
})







app.get("/questiondropdwn/:quesbankid/:deckid/:gametypeid/:langid",function(req,res){
  
var query = "SELECT * FROM `ques_for_questionbank` WHERE ques_for_questionbank.ques_bank_id='"+req.params.quesbankid+"' AND ques_for_questionbank.deck_id='"+req.params.deckid+"' AND ques_for_questionbank.game_typeid='"+req.params.gametypeid+"' AND ques_for_questionbank.lang_id='"+req.params.langid+"' AND ques_for_questionbank.status='A'";
connection.query(query,function(err,rows,fields){
  if(err){
    console.log(err.message);
  }else{
    res.send(JSON.stringify(rows));
  }
})
})




app.get("/gametypebasedlist/:gametypeid",function(req,res){
  


var query = "SELECT * FROM game_master WHERE game_master.game_id='"+req.params.gametypeid+"'";
connection.query(query,function(err,rows,fields){
  if(err){
    console.log(err.message);
  }else{
    res.send(JSON.stringify(rows));
  }
})
})




app.post("/insert_ques_card",urlencodedParser,function(req,res){
 
  console.log(req.body);
  console.log(req.body.deckid);
  // console.log(req.body[0].deckid);

  var sql="delete from ques_to_card where ques_to_card.deck_id='"+req.body.deckid+"' AND ques_to_card.quesbank_id ='"+req.body.quesbankid+"' AND ques_to_card.quesid ='"+req.body.quesid+"'";
  console.log(sql);

  connection.query(sql,function(err,rows) {
    if (err) 
      throw err;
    else if(rows)
    {

        var sql1="INSERT INTO ques_to_card(ques_to_card.deck_id,ques_to_card.gametype_id,ques_to_card.lang_id,ques_to_card.gamemode,ques_to_card.quesbank_id,ques_to_card.quesid,ques_to_card.status)VALUES ('"+req.body.deckid+"','"+req.body.type+"','"+req.body.langid+"','"+req.body.gamemode+"','"+req.body.quesbankid+"','"+req.body.quesid+"','A')";
connection.query(sql1,function(err) {
    if (err) 
      throw err;
    else
    {
      res.send("Inserted");
    }
})
    
    }
    else{

    }
})
})




/*app.post("/answer_to_card",urlencodedParser,function(req,res){
  console.log("answer");
console.log(req.body);
//   var sql1="delete from ans_to_ques where ans_to_ques.deck_id ='"+req.body[0].deckid+"' AND ans_to_ques.quesb_id ='"+req.body[0].quesbankid+"' AND ans_to_ques.ques_id ='"+req.body[0].quesid+"'";
// console.log(sql1);
//   connection.query(sql1,function(err,rows) {
//     if (err) 
//       throw err;
//     else if(rows)
//     {
  
  // console.log(req.body);
          var sql = "INSERT INTO ans_to_ques (ans_to_ques.card_id,ans_to_ques.deck_id,ans_to_ques.quesb_id,ans_to_ques.ques_id,ans_to_ques.game_id,ans_to_ques.cat_id,ans_to_ques.card_score,ans_to_ques.cardadded,ans_to_ques.status,ans_to_ques.createdby,ans_to_ques.createddate,theme_id)VALUES ?";
var values =[];
var newdate= new Date();
 for(i=0;i<req.body.length;i++){
    values.push([req.body[i].cardid,req.body[i].deckid,req.body[i].quesbankid,req.body[i].quesid,req.body[i].typeid,req.body[i].catid,req.body[i].catscore,'yes','A','admin',newdate,req.body[i].themeid]);
}
console.log(values);
connection.query(sql, [values], function(err) {
    if (err) 
      throw err;
    else
    {
      res.send("Inserted");
    }
});

//     }
//     else{

//     }

// })
  
})*/

app.post("/answer_to_card",urlencodedParser,function(req,res){
  console.log("answer");
console.log("answer",req.body);
console.log(req.body[0].deck_id);
  var sql1="delete from ans_to_ques where ans_to_ques.deck_id ='"+req.body[0].deck_id+"' AND ans_to_ques.quesb_id ='"+req.body[0].quesbank_id+"' AND ans_to_ques.ques_id ='"+req.body[0].ques_id+"' AND ans_to_ques.game_id ='"+req.body[0].game_id+"'";
console.log(sql1);
  connection.query(sql1,function(err,rows) {
    if (err) 
      throw err;
    else if(rows)
    {
  
  // console.log(req.body);
          var sql = "INSERT INTO ans_to_ques (ans_to_ques.card_id,ans_to_ques.deck_id,ans_to_ques.quesb_id,ans_to_ques.ques_id,ans_to_ques.game_id,ans_to_ques.cat_id,ans_to_ques.card_score,ans_to_ques.cardadded,ans_to_ques.status,ans_to_ques.createdby,ans_to_ques.createddate,theme_id)VALUES ?";
var values =[];
var newdate= new Date();
 for(i=0;i<req.body.length;i++){
    values.push([req.body[i].card_id,req.body[i].deck_id,req.body[i].quesbank_id,req.body[i].ques_id,req.body[i].game_id,req.body[i].cat_id,req.body[i].card_score,'yes','A','admin',newdate,req.body[i].themeid]);
}
console.log(values);
connection.query(sql, [values], function(err) {
    if (err) 
      throw err;
    else
    {
      res.send("Inserted");
    }
});

    }
    else{

    }

})
  
})

app.get("/categorylist/",function(req,res){
  


var query = "SELECT * FROM category WHERE status='A'";
connection.query(query,function(err,rows,fields){
  if(err){
    console.log(err.message);
  }else{
    res.send(JSON.stringify(rows));
  }
})
})





app.get("/questions_to_cardlist/",function(req,res){
  


// var query = "SELECT ques_to_card.deck_id,language.language,question_bank.ques_bank,game_master.game_name,deck.deck_theme,ques_to_card.ques_to_cardid,ques_to_card.status,ques_to_card.gametype_id,ques_to_card.gamemode,ques_to_card.lang_id,ques_to_card.quesbank_id,ques_to_card.quesid FROM ques_to_card LEFT JOIN deck ON ques_to_card.deck_id=deck.DeckID LEFT JOIN game_master ON ques_to_card.gametype_id=game_master.game_id LEFT JOIN language ON ques_to_card.lang_id=language.lang_id LEFT JOIN question_bank ON ques_to_card.quesbank_id=question_bank.quesb_id LEFT JOIN questions ON ques_to_card.quesid=questions.quesid order by ques_to_card.ques_to_cardid DESC";
// var query="SELECT ans_to_ques.card_id,card.card_name, ques_to_card.deck_id,language.language,question_bank.ques_bank,game_master.game_name,deck.deck_theme,ques_to_card.ques_to_cardid,ques_to_card.status,ques_to_card.gametype_id,ques_to_card.gamemode,ques_to_card.lang_id,ques_to_card.quesbank_id,ques_to_card.quesid FROM ques_to_card LEFT JOIN deck ON ques_to_card.deck_id=deck.DeckID LEFT JOIN game_master ON ques_to_card.gametype_id=game_master.game_id LEFT JOIN language ON ques_to_card.lang_id=language.lang_id LEFT JOIN question_bank ON ques_to_card.quesbank_id=question_bank.quesb_id LEFT JOIN questions ON ques_to_card.quesid=questions.quesid LEFT JOIN ans_to_ques ON ques_to_card.quesbank_id=ans_to_ques.quesb_id LEFT JOIN card ON ans_to_ques.card_id=card.card_id order by ques_to_card.ques_to_cardid DESC";
var query="SELECT ans_to_ques.*,card.img_url,game_master.gamemode,ans_to_ques.card_id,card.card_name,ques_for_questionbank.question,language.language,question_bank.ques_bank,game_master.game_name,deck.deck_theme FROM ans_to_ques LEFT JOIN deck ON ans_to_ques.deck_id=deck.DeckID LEFT JOIN game_master ON ans_to_ques.game_id=game_master.game_id LEFT JOIN question_bank ON ans_to_ques.quesb_id=question_bank.quesb_id LEFT JOIN ques_for_questionbank ON ans_to_ques.ques_id=ques_for_questionbank.ques_id LEFT JOIN language ON ques_for_questionbank.lang_id=language.lang_id inner JOIN card ON ans_to_ques.card_id=card.card_id GROUP by ans_to_ques.ques_id DESC";
connection.query(query,function(err,rows,fields){
  if(err){
    console.log(err.message);
  }else{
    res.send(JSON.stringify(rows));
  }
})
})



app.get("/deckbasedcardlist/:deckid",function(req,res){
  
// var query = "SELECT * FROM card WHERE card.deck_id='"+req.params.deckid+"'";
var query="SELECT card.*,deck.deck_theme FROM card LEFT JOIN deck ON card.deck_id=deck.DeckID WHERE card.deck_id='"+req.params.deckid+"'";
connection.query(query,function(err,rows,fields){
  if(err){
    console.log(err.message);
  }else{
    res.send(JSON.stringify(rows));
  }
})
})




app.post("/insert_ans_to_ques",urlencodedParser,function(req,res){
  var sql = "INSERT INTO ques_to_card(ques_to_card.gamemode,ques_to_card.cardid,ques_to_card.deck_id,ques_to_card.lang_id,ques_to_card.quesbank_id,ques_to_card.quesid,ques_to_card.gametype_id,ques_to_card.status,ques_to_card.createdby,ques_to_card.created_date,cardadded)VALUES ?";
var values =[];
console.log(req.body.length);
 for(i=0;i<req.body.length;i++){
    values.push([req.body[i].gamemode,req.body[i].cardid,req.body[i].deckid,req.body[i].langid,req.body[i].quesbankid,req.body[i].quesid,req.body[i].type,'A','admin','now()','yes']);
}
console.log(values);
connection.query(sql, [values], function(err) {
    if (err) 
      throw err;
    else
    {
      res.send("Inserted");
    }
});
  
})


app.get("/answertoqueslist/",function(req,res){
  
var query="SELECT ans_to_ques.game_id,ans_to_ques.quesb_id,ans_to_ques.deck_id,ans_to_ques.ques_id,ans_to_ques.card_id,ans_to_ques.cat_id,ans_to_ques.card_score,ans_to_ques.cardadded,ans_to_ques.status FROM ans_to_ques";
connection.query(query,function(err,rows,fields){
  if(err){
    console.log(err.message);
  }else{
    res.send(JSON.stringify(rows));
  }
})
})

app.get("/categorylistvalues/:quesbankid/:quesid/:cardid/:deckid",function(req,res){
  
var query="SELECT * FROM ans_to_ques WHERE ans_to_ques.quesb_id='"+req.params.quesbankid+"' AND ans_to_ques.ques_id='"+req.params.quesid+"' AND ans_to_ques.card_id='"+req.params.cardid+"' AND ans_to_ques.deck_id='"+req.params.deckid+"'";
connection.query(query,function(err,rows,fields){
  if(err){
    console.log(err.message);
  }else{
    res.send(JSON.stringify(rows));
  }
})
})


app.get("/delete_questionstocard/:status/:qbid",function(req,res){
  var status="";
  if(req.params.status=="A"){
status="I";
  }
  else{
    status="A";
  }
  var delete_query="UPDATE ques_to_card SET ques_to_card.status='"+status+"' WHERE ques_to_card.ques_to_cardid='"+req.params.qbid+"'";
  connection.query(delete_query,function(err,rows,fields){
    if(err){
      console.log(err.message);
    }
    else{
      res.send("Deleted");
    }
  })
})





// app.get("/deckbasedcardlist/:deckid/:quesbankid/:quesid",function(req,res){
  
//   var query="SELECT * FROM `ques_to_card` WHERE ques_to_card.deck_id='"+req.params.deckid+"' AND ques_to_card.quesbank_id='"+req.params.quesbankid+"' AND ques_to_card.quesid='"+req.params.quesid+"'";
//   connection.query(query,function(err,rows,fields){
//     if(err){
//       console.log(err.message);
//     }
//     else if(rows.length>0){

//      var query="SELECT * FROM card WHERE card.deck_id='"+req.params.deckid+"'";
//   connection.query(query,function(err,rows,fields){
//     if(err){
//       console.log(err.message);
//     }
//     else{
// var query="SELECT * FROM card WHERE card.deck_id='"+req.params.deckid+"'";
//   connection.query(query,function(err,rows,fields){
 

//   })
//     }
// //       for(i=0;i<rows.length;i++){
// // cardarray.push(rows[i])
// //       }
//       // async.forEachOf(cardarray,function (data, index ,next) {
//       //   scoreobj={};
//       //   var scorequery="SELECT category.catid,deck.deck_theme,card.card_name,category.category_name,score.score FROM score INNER JOIN deck ON deck.DeckID=score.deck_id INNER JOIN card ON card.card_id=score.card_id INNER JOIN category ON category.catid =score.cat_id WHERE category.status='A' AND score.card_id="+cardarray[index]["card_id"]+"";
//       //   connection.query(scorequery,function(err,rows,fields){
//       //     if(err){
//       //       console.log(err.message);
//       //     }
//       //     else{
//       //       cardarray[index].scoredata=rows;
//       //       // cardarray[index].scoredata=scoreobj;
//       //     }
//       //     next();
//       //   })
//       // },function(err){
//       //   res.send(cardarray);
//       // })

//   })
// }
// })
// })

// display direction

app.get("/disp_direction",function(req,res){
var query = "SELECT direction_master. * ,question_bank.ques_bank,questions.question, game_master.game_name, deck.deck_theme FROM `direction_master` LEFT JOIN question_bank ON question_bank.quesb_id = direction_master.ques_bank_id LEFT JOIN game_master ON game_master.game_id = question_bank.gametype_id LEFT JOIN deck ON deck.DeckID = direction_master.deckid LEFT JOIN questions ON questions.quesid = direction_master.ques_id";
// console.log(query);
connection.query(query,function(err,rows,fields){
  if(err){
    console.log(err.message);
  }else{
    res.send(JSON.stringify(rows));
  }
})
})


// insert directionmaster
// INSERT INTO `direction_master` (`direction_id`, `deckid`, `gamemode`, `gameid`, `lang_id`, `ques_bank_id`, `ques_id`, `direction_up`, `direction_down`, `direction_left`, `direction_right`, `status`, `createdby`, `createddate`) VALUES (NULL, '', '', '', '', '', '', '', '', '', '', '', '', '')

app.post("/insert_direction",urlencodedParser,function(req,res){
  var query1 = "select * from direction_master where  deckid = '"+req.body.deckid+"' and gamemode = "+req.body.gamemode+" and gameid = '"+req.body.gameid+"' and lang_id = '"+req.body.lang_id+"' and ques_bank_id = '"+req.body.ques_bank_id+"'  and ques_id = '"+req.body.ques_id+"' ";
  console.log(query1);
  connection.query(query1,function(err,rows,fields){
    if(err){
      console.log(err.message)
    }
    else if(rows.length>0){
      res.send("Already Exists")
    }
    else
    {
      var query="insert into direction_master( deckid ,gamemode, gameid,lang_id,ques_bank_id,ques_id,direction_up,direction_down,direction_left,direction_right, status, createdby,createddate )values('"+req.body.deckid+"','"+req.body.gamemode+"','"+req.body.gameid+"','"+req.body.lang_id+"','"+req.body.ques_bank_id+"','"+req.body.ques_id+"','"+req.body.direction_up+"','"+req.body.direction_down+"','"+req.body.direction_left+"','"+req.body.direction_right+"','A' ,'"+req.body.createdby+"',now())";
  console.log(query);

  connection.query(query,function(err,rows,fields){
     if(err){
      console.log(err.message);
     }
     else{
      res.send("Inserted");
     }
  })
    }
  })
  
})



// update


app.post('/upd_direction/',function(req,res){
  // console.log(req.body);
 var query1 = "select * from direction_master where  deckid = '"+req.body.deckid+"' and gamemode = "+req.body.gamemode+" and gameid = '"+req.body.gameid+"' and lang_id = '"+req.body.lang_id+"' and ques_bank_id = '"+req.body.ques_bank_id+"'  and ques_id = '"+req.body.ques_id+"' ";
  connection.query(query1,function(err,rows,fields){
    if(err){
      console.log(err.message)
    }
    else if(rows.length>0){
      res.send("Already Exists")
    }
else{
 var query="update direction_master set deckid='"+req.body.deckid+"',gamemode='"+req.body.gamemode+"',gameid = '"+req.body.gameid+"',lang_id = '"+req.body.lang_id+"',ques_bank_id = '"+req.body.ques_bank_id+"',ques_id = '"+req.body.ques_id+"',direction_up = '"+req.body.direction_up+"',direction_down = '"+req.body.direction_down+"',direction_left = '"+req.body.direction_left+"',direction_right = '"+req.body.direction_right+"',createdby = '"+req.body.createdby+"' where direction_id="+req.body.direction_id+"";
  connection.query(query,function(err,rows,fields){
if(err){
  console.log(err.message);
}
else if(rows){
  res.send("Updated");

}
else{
  res.send("no data");
}
  })
}
})
  
})

// delete

app.get("/delete_direction/:status/:direction_id",function(req,res){
  var status="";
  if(req.params.status=="A"){
status="I";
  }
  else{
    status="A";
  }
  var delete_query="update direction_master set status='"+status+"' where direction_id="+req.params.direction_id+"";
  connection.query(delete_query,function(err,rows,fields){
    if(err){
      console.log(err.message);
    }
    else{
      res.send("Deleted");
    }
  })
})

// update


app.post('/upd_benchmark/',function(req,res){
  // console.log(req.body);
  var query1 = "select * from benchmark where  bench_mark = '"+req.body.bench_mark+"' and mark = "+req.body.mark+" and color = '"+req.body.color+"'";
  connection.query(query1,function(err,rows,fields){
    if(err){
      console.log(err.message)
    }
    else if(rows.length>0){
      res.send("Already Exists")
    }
else{
 var query="update benchmark set bench_mark='"+req.body.bench_mark+"',mark='"+req.body.mark+"',color = '"+req.body.color+"',createdby = '"+req.body.createdby+"' where bench_id="+req.body.bench_id+"";
  connection.query(query,function(err,rows,fields){
if(err){
  console.log(err.message);
}
else if(rows){
  res.send("Updated");

}
else{
  res.send("no data");
}
  })
}
})
  
})


// insert benchmark

app.post("/insert_benchmark",urlencodedParser,function(req,res){
  var query1 = "select * from benchmark where  bench_mark = '"+req.body.bench_mark+"' and mark = "+req.body.mark+" and color = '"+req.body.color+"' ";
  console.log(query1);
  connection.query(query1,function(err,rows,fields){
    if(err){
      console.log(err.message)
    }
    else if(rows.length>0){
      res.send("Already Exists")
    }
    else
    {
      var query="insert into benchmark( bench_mark ,mark, color, status, created_date, createdby)values('"+req.body.bench_mark+"','"+req.body.mark+"','"+req.body.color+"','A' ,now(),'"+req.body.createdby+"')";
  console.log(query);

  connection.query(query,function(err,rows,fields){
     if(err){
      console.log(err.message);
     }
     else{
      res.send("Inserted");
     }
  })
    }
  })
  
})


// delete


app.get("/delete_benchmark/:status/:bench_id",function(req,res){
  var status="";
  if(req.params.status=="A"){
status="I";
  }
  else{
    status="A";
  }
  var delete_query="update benchmark set status='"+status+"' where bench_id="+req.params.bench_id+"";
  connection.query(delete_query,function(err,rows,fields){
    if(err){
      console.log(err.message);
    }
    else{
      res.send("Deleted");
    }
  })
})



app.get("/dispinstruction_basedondeck/:deckid/:gamemode/:gametype/:langid",function(req,res){
  var query="SELECT * FROM instruction WHERE instruction.deckid='"+req.params.deckid+"' AND instruction.gamemode='"+req.params.gamemode+"' AND instruction.gametype='"+req.params.gametype+"' AND instruction.lang_id="+req.params.langid+"";
  connection.query(query,function(err,rows,fields){
    if(err){
      console.log(err.message);
    }
    else{
      var display=[];
      async.forEachOf(rows,function (data, index ,next) {
        console.log(rows[index].gamemode);
        if(rows[index].gamemode == 0){
          console.log(rows[index]);
          rows[index]["gamename"]="Singlemode";
          display.push(rows[index]);
          console.log(display);
        }
        else if(rows[index].gamemode == 1)
        {
         console.log(rows[index]);
          rows[index]["gamename"]="Multimode";
          display.push(rows[index]);
          console.log(display); 
        }
        else
        {
          console.log("err");
        }
        next();
      },function(err){
        res.send(display);
      })
    }
  })
})
app.get("/disp_ques_basedonquesbank/:deckid/:gamemode/:gametype/:langid",function(req,res){
// var query="SELECT question_bank.* FROM question_bank WHERE question_bank.deck_id='"+req.params.deckid+"' AND question_bank.gamemode='"+req.params.gamemode+"' AND question_bank.gametype_id='"+req.params.gametype+"' AND question_bank.Language='"+req.params.langid+"'";
var query="SELECT question_bank.*,ques_for_questionbank.question FROM question_bank LEFT JOIN ques_for_questionbank ON question_bank.quesb_id=ques_for_questionbank.ques_bank_id WHERE question_bank.deck_id='"+req.params.deckid+"' AND question_bank.gamemode='"+req.params.gamemode+"' AND question_bank.gametype_id='"+req.params.gametype+"' AND question_bank.Language='"+req.params.langid+"' GROUP BY question_bank.quesb_id";
var questionsarraa=[];
var finalarr=[];
connection.query(query,function(err,quesbank,fields){
    if(err){
      console.log(err.message);
    }
    else if(quesbank){
      async.forEachOf(quesbank,function (data, qbindex ,next) {
        var query2="SELECT * FROM `ques_for_questionbank` WHERE deck_id='"+quesbank[qbindex].deck_id+"' AND gamemode='"+quesbank[qbindex].gamemode+"' AND game_typeid='"+quesbank[qbindex].gametype_id+"' AND lang_id='"+quesbank[qbindex].Language+"' AND ques_for_questionbank.ques_bank_id='"+quesbank[qbindex].quesb_id+"' LIMIT 2";
        // console.log(query2);
         connection.query(query2,function(err,questions,fields){
    if(err){
      console.log(err.message);
    }
    else{
var cardslistarr=[];
/*SELECT card.deck_id,card.card_name,card.img_url,card.card_id,language.lang_id,language.language,word.word,word.synonym,score.*,category.category_name FROM card LEFT JOIN score ON card.card_id=score.card_id LEFT JOIN category ON score.cat_id=category.catid LEFT JOIN word ON card.card_id=word.card_id LEFT JOIN language ON word.lang_id=language.lang_id WHERE card.card_id=4*/
//new crct query 
/*
SELECT ans_to_ques.*,card.deck_id,card.card_name,language.lang_id,language.language,card.img_url,category.category_name FROM ans_to_ques LEFT JOIN card ON ans_to_ques.card_id=card.card_id LEFT JOIN category on ans_to_ques.cat_id=category.catid LEFT JOIN ques_for_questionbank ON ans_to_ques.ques_id=ques_for_questionbank.ques_id LEFT JOIN language ON ques_for_questionbank.lang_id=language.lang_id LEFT JOIN word ON ans_to_ques.card_id=word.card_id WHERE ans_to_ques.deck_id ='8' AND ans_to_ques.quesb_id='9' AND ans_to_ques.ques_id='8' GROUP BY ans_to_ques.cat_id
*/

        async.forEachOf(questions,function (data1, questionindex ,questionnext) {
           var query3="SELECT ans_to_ques.*,ques_for_questionbank.question,card.deck_id,card.card_name,language.lang_id,language.language,card.img_url,category.category_name FROM ans_to_ques LEFT JOIN card ON ans_to_ques.card_id=card.card_id LEFT JOIN category on ans_to_ques.cat_id=category.catid LEFT JOIN ques_for_questionbank ON ans_to_ques.ques_id=ques_for_questionbank.ques_id LEFT JOIN language ON ques_for_questionbank.lang_id=language.lang_id LEFT JOIN word ON ans_to_ques.card_id=word.card_id  WHERE ans_to_ques.deck_id ='"+questions[questionindex].deck_id+"' AND ans_to_ques.quesb_id='"+questions[questionindex].ques_bank_id+"' AND ans_to_ques.ques_id='"+questions[questionindex].ques_id+"' GROUP BY ans_to_ques.cat_id";
           console.log(query3);
            connection.query(query3,function(err,cardslist,fields){
              if(err){
      console.log(err.message);
    }
    else if(cardslist){
     
      var json1={
       
        "qustionansw":cardslist
      }
      cardslistarr.push(json1);

questionnext(null);
    }
            })

        },function(err){
          console.log(questions);
          console.log(questions[qbindex]);
          // console.log("cards",cardslistarr);
          var json={
          "quesbankname":quesbank[qbindex].ques_bank,
          "question":quesbank[qbindex].question ,
          "qustionansw":cardslistarr
        }
        questionsarraa.push(json);
        // console.log("questionsaa",questionsarraa);
    next(null);
        })  
        
        // console.log(json);
        // console.log("out",questionsarraa);
    }
  })

      },function(err){

        res.send(questionsarraa);




})
    }
  })
})



// theme starts


app.get("/display_theme/",function(req,res){
  var query="SELECT * FROM theme_master";
  connection.query(query,function(err,rows,fields){
    if(err){
      console.log(err.message);
    }
    else{
      res.send(JSON.stringify(rows));
    }
  })
})



app.post("/insert_theme",urlencodedParser,function(req,res){

var query1 = " select * from theme_master where theme_name = '"+req.body.theme_name+"'  ";
  console.log(query1);
  connection.query(query1,function(err,rows,fields){
    if(err){
      console.log(err.message)
    }
    else if(rows.length>0){
      res.send("Already Exists");
    }
    else
    {


      var query="INSERT INTO theme_master (theme_master.theme_name,theme_master.direction_up,theme_master.direction_down,theme_master.direction_left,theme_master.direction_right,theme_master.status)VALUES('"+req.body.theme_name+"','"+req.body.direction_up+"','"+req.body.direction_down+"','"+req.body.direction_left+"','"+req.body.direction_right+"','A')";
  console.log(query);

  connection.query(query,function(err,rows,fields){
     if(err){
      console.log(err.message);
     }
     else{
      res.send("Inserted");
     }
  
  })
}
})
  
})


app.post("/update_theme",urlencodedParser,function(req,res){

 // var query1 = " select * from theme_master where theme_name = '"+req.body.upd_themename+"'  ";
 //  console.log(query1);
 //  connection.query(query1,function(err,rows,fields){
 //    if(err){
 //      console.log(err.message)
 //    }
 //    else if(rows.length>0){
 //      res.send("Already Exists");
 //    }
 //    else
 //    {
      var query="UPDATE theme_master SET theme_master.theme_name='"+req.body.upd_themename+"',theme_master.direction_up='"+req.body.upd_direction_up+"',theme_master.direction_down='"+req.body.upd_directiondown+"',theme_master.direction_left='"+req.body.upd_directionleft+"',theme_master.direction_right='"+req.body.upd_directionright+"' WHERE theme_master.theme_id='"+req.body.upd_themeid+"'";
  console.log(query);

  connection.query(query,function(err,rows,fields){
     if(err){
      console.log(err.message);
     }
     else{
      res.send("Updated");
     }
  
  })
// }
// })
  
})


app.get("/delete_theme/:status/:theme_id",function(req,res){
  var status="";
  if(req.params.status=="A"){
status="I";
  }
  else{
    status="A";
  }
  var delete_query="UPDATE theme_master SET theme_master.status='"+req.params.status+"' WHERE theme_master.theme_id='"+req.params.theme_id+"'";
  connection.query(delete_query,function(err,rows,fields){
    if(err){
      console.log(err.message);
    }
    else{
      res.send("Deleted");
    }
  })
})


//theme ends


//direction drop down


app.get("/display_directiontheme/:quesbankid",function(req,res){
  var query="SELECT * FROM question_bank inner JOIN theme_master ON question_bank.theme_id=theme_master.theme_id WHERE question_bank.quesb_id='"+req.params.quesbankid+"'";
  connection.query(query,function(err,rows,fields){
    if(err){
      console.log(err.message);
    }
    else{
      res.send(JSON.stringify(rows));
    }
  })
})


// manish output for selfie starts
app.get("/disphist_selfi/:gameid/:uniqueid/:gamemode/:deckid",function(req,res){
  var cardarray=[];
  var scoreobj={};

  var query="select word.*,selfi_history.*,card.*,players.player_id,players.img_url as profile_img,players.nickname,players.name FROM selfi_history left join word on word.card_id=selfi_history.card_id and word.lang_id=1 LEFT JOIN card ON card.card_id=selfi_history.card_id inner join players on players.player_id = selfi_history.player_id where selfi_history.game_id = "+req.params.gameid+" and selfi_history.uniqueid = '"+req.params.uniqueid+"'";
  console.log(query);
  connection.query(query,function(err,rows,fields){
    if(err){
      console.log(err.message);
    }
    else {
       async.forEachOf(rows,function (data, index ,next) {
        rows[index]['profile_img']=imgURL+rows[index]['profile_img'];
        scoreobj={};
        var query="SELECT score.score_id,score.card_id,score.cat_id,score.score,cattheme.category as title from score inner join cattheme ON score.cat_id=cattheme.cattheme_id and cattheme.status='A' and cattheme.deck_id="+req.params.deckid+" WHERE score.card_id="+rows[index].card_id+"";
        console.log(query);
        connection.query(query,function(err,rows1,fields){
          if(err){
            console.log(err.message);
          }
          else{
            rows[index].category=rows1;
            // cardarray[index].scoredata=scoreobj;
          }
          next();
        })
      },function(err){
        // res.send(cardarray);
      })
//       for(i=0;i<rows.length;i++){

//         // var imgurl=base64_encode("uploads/"+rows[i].img_url);
//         // console.log(imgurl);
//         rows[i].img_url=imgURL+rows[i].img_url; 
// cardarray.push(rows[i])
//       }
      async.forEachOf(rows,function (data, index ,next) {
        scoreobj={};
        rows[index].img_url = imgURL + rows[index].img_url; 

        console.log("questionbank id ", rows[index].quesbank_id);

        if(rows[index].quesbank_id == undefined || rows[index].quesbank_id == null || rows[index].quesbank_id == 0){
          var scorequery="SELECT score.score as score, cattheme.category as title FROM score inner join cattheme ON category.cattheme_id = score.cat_id and cattheme.status='A'  where  score.card_id = "+rows[index].card_id+"";
        }else{
          var scorequery="SELECT ans_to_ques.card_score as score, cattheme.category as title FROM ans_to_ques inner join cattheme ON cattheme.cattheme_id = ans_to_ques.cat_id and cattheme.status='A'  where ans_to_ques.quesb_id = "+rows[index].quesbank_id+" and ans_to_ques.ques_id = "+rows[index].question_id+"  and ans_to_ques.game_id = "+rows[index].game_id+" and ans_to_ques.card_id = "+rows[index].card_id+" ";
        }
        
        console.log(scorequery);

        connection.query(scorequery,function(err,rows1,fields){
          if(err){
            console.log(err.message);
          }
          else{
            console.log("rwosasdfasdf",rows1);
            groupByBMTitle(rows1)
            rows[index].scoredata=rows1;
            // cardarray[index].scoredata=scoreobj;
          }
          next();
        })
      },function(err){
           var query = "SELECT benchmark_master.*,cattheme.category FROM benchmark_master inner join cattheme ON cattheme.cattheme_id = benchmark_master.cat_id and cattheme.status='A' WHERE benchmark_master.game_mode="+req.params.gamemode+" AND benchmark_master.game_id="+req.params.gameid+" and deckid = "+req.params.deckid+"";
      connection.query(query,function(err,rows1,fields){
        var obj={
          "data":rows,
          "benchmark":groupByBMTitle(rows1)
        }

        // rows.push({'benchmark':});
        res.send(obj);
      })
      })
    }
  })
})
// manish output for selfie ends




app.post("/insert_direction_score",urlencodedParser,function(req,res){
  console.log(req.body);
      var query="INSERT INTO directionscore(directionscore.deckid,directionscore.quesbankid,directionscore.gamemode,directionscore.gametype,directionscore.direction_leftscore,directionscore.direction_rightscore,directionscore.direction_upscore,directionscore.direction_downscore,directionscore.theme_id,directionscore.cardid,directionscore.quesid) values ?;"
  console.log(query);
  var values =[];
   for(i=0;i<req.body.length;i++){
    console.log(req.body[i].direction_upscore);
    values.push([req.body[i].deckid,req.body[i].quesbankid,req.body[i].gamemode,req.body[i].gametype,req.body[i].direction_leftscore,req.body[i].direction_rightscore,req.body[i].direction_upscore,req.body[i].direction_downscore,req.body[i].theme_id,req.body[i].cardid,req.body[i].quesid]);
}



  connection.query(query,[values],function(err,rows,fields){
     if(err){
      console.log(err.message);
     }
     else{
console.log(values);
console.log('dirction',values);
      res.send("Inserted");
     }
  
  })
  
})




//game history insertion

// insert_hist_scenario
// INSERT INTO `scenario_history` (`his_id`, `game_id`, `player_id`, `quesbank_id`, `ques_id`, `ans_cardid1`, `ans_cardid2`, `ans_cardid3`, `ans_cardid4`, `ans_cardid5`, `date_time`) VALUES (NULL, ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ')

app.post("/insert_hist_scenario",urlencodedParser,function(req,res){
 // '"+req.body.game_id+"','"+req.body.uniqueid+"','"+req.body.player_id+"','"+req.body.quesbank_id+"','"+req.body.ques_id+"','"+req.body.ans_cardid1+"',now()
      var query = "insert into scenario_history( game_id,uniqueid ,attendID,player_id, quesbank_id,ques_id, ans_cardid1,date_time)VALUES ?";
  console.log(query);

   var values=[];
   var scenarioHistory=req.body;
   console.log(req.body.length);
if(scenarioHistory.length != 0){      
    var newdate=new Date();
        for(i=0;i<scenarioHistory.length;i++)
        {
          if(scenarioHistory[i].ans_cardid1 != null || scenarioHistory[i].ans_cardid1 != "" || scenarioHistory[i].ans_cardid1 != undefined){
          values.push([scenarioHistory[i].game_id, scenarioHistory[i].uniqueid,scenarioHistory[i].attendID,scenarioHistory[i].player_id,scenarioHistory[i].quesbank_id,scenarioHistory[i].ques_id,scenarioHistory[i].ans_cardid1,newdate]);
          }

          else{

          }
        }
    console.log(values);
    connection.query(query, [values], function(err) {
        if (err) 
          throw err;
        else
        {
          res.send("Inserted");
        }
    });
}else{  
    res.send("Array is empty");
}
  
})


// INSERT INTO `selfi_history` (`his_id`, `uniqueid`, `game_id`, `player_id`, `quesbank_id`, `question_id`, `card_id`, `direction`, 'directionscore',`date`) VALUES (NULL, ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ')

// game history insertin for selfi


app.get("/testdisp_ques_basedonquesbank/:deckid/:gamemode/:gametype/:langid",function(req,res){


var query="SELECT question_bank.*,theme_master.direction_up,theme_master.direction_down,theme_master.direction_left,theme_master.direction_right,ques_for_questionbank.question FROM question_bank LEFT JOIN ques_for_questionbank ON question_bank.quesb_id=ques_for_questionbank.ques_bank_id LEFT JOIN theme_master ON question_bank.theme_id=theme_master.theme_id WHERE question_bank.deck_id='"+req.params.deckid+"' AND question_bank.gamemode='"+req.params.gamemode+"' AND question_bank.gametype_id='"+req.params.gametype+"' AND question_bank.Language='"+req.params.langid+"' GROUP BY question_bank.quesb_id";
var questionsarraa=[];
var finalarr=[];
connection.query(query,function(err,quesbank,fields){
    if(err){
      console.log(err.message);
    }
    else if(quesbank){
      async.forEachOf(quesbank,function (data, qbindex ,next) {
        var query2="SELECT * FROM `ques_for_questionbank` WHERE deck_id='"+quesbank[qbindex].deck_id+"' AND gamemode='"+quesbank[qbindex].gamemode+"' AND game_typeid='"+quesbank[qbindex].gametype_id+"' AND lang_id='"+quesbank[qbindex].Language+"' AND ques_for_questionbank.ques_bank_id='"+quesbank[qbindex].quesb_id+"' order by rand() limit 6";
        // console.log(query2);
         connection.query(query2,function(err,questions,fields){
    if(err){
      console.log(err.message);
    }
    else{
var cardslistarr=[];

        async.forEachOf(questions,function (data1, questionindex ,questionnext) {
           var query3="SELECT ans_to_ques.*,ques_for_questionbank.question,word.word,word.synonym,card.deck_id,card.card_name,language.lang_id,language.language,card.img_url,category.category_name FROM ans_to_ques inner JOIN card ON ans_to_ques.card_id=card.card_id inner JOIN category on ans_to_ques.cat_id=category.catid inner JOIN ques_for_questionbank ON ans_to_ques.ques_id=ques_for_questionbank.ques_id inner JOIN language ON ques_for_questionbank.lang_id=language.lang_id inner JOIN word ON ans_to_ques.card_id=word.card_id  WHERE ans_to_ques.deck_id ='"+questions[questionindex].deck_id+"' AND ans_to_ques.quesb_id='"+questions[questionindex].ques_bank_id+"' AND ans_to_ques.ques_id='"+questions[questionindex].ques_id+"' group BY ans_to_ques.card_id";
           console.log(query3);
            connection.query(query3,function(err,cardslist,fields){
              if(err){
      console.log(err.message);
    }
    else if(cardslist){
      var score=[];

      async.forEachOf(cardslist,function (data2, cardindex ,cardnext) {
        // var query4="SELECT ans_to_ques.card_id,ans_to_ques.cat_id,ans_to_ques.card_score as score,category.category_name FROM `ans_to_ques`inner JOIN category ON ans_to_ques.cat_id=category.catid  WHERE ans_to_ques.card_id='"+cardslist[cardindex].card_id+"' GROUP BY cat_id";
        var query4="SELECT ans_to_ques.card_id,ans_to_ques.cat_id,ans_to_ques.card_score as cat_score,category.category_name,directionscore.direction_leftscore as leftscore,directionscore.direction_rightscore as rightscore,directionscore.direction_upscore as upscore,directionscore.direction_downscore as downscore,theme_master.direction_up as uparrow,theme_master.direction_down as downarrow,theme_master.direction_left as leftarrow,theme_master.direction_right as rightarrow FROM ans_to_ques INNER JOIN theme_master  ON ans_to_ques.theme_id=theme_master.theme_id LEFT JOIN directionscore on ans_to_ques.theme_id=directionscore.theme_id inner JOIN category ON ans_to_ques.cat_id=category.catid  where ans_to_ques.card_id='"+cardslist[cardindex].card_id+"' GROUP by cat_id";
            connection.query(query4,function(err,cardscore,fields){
               if(err){
      console.log(err.message);
    }
    else if(cardscore){
      console.log("cardscore",cardscore);
      for(i=0;i<cardscore.length;i++){
        score.push(cardscore[i]);

      }

cardslist[cardindex].category=score;
cardnext(null);
    }

            })

      },function(err){
        
        // json={
        //   "cardslist":cardslist
        // }
        if(cardslist.length!=0){
        cardslistarr.push(cardslist);
      }
questionnext(null);


      })
     
    
    }
            })

        },function(err){
          console.log(questions);
          console.log(questions[qbindex]);
          // console.log("cards",cardslistarr);
          var json={
          "quesbankname":quesbank[qbindex].ques_bank,
          "direction_up":quesbank[qbindex].direction_up,
          "direction_down":quesbank[qbindex].direction_down,
          "direction_right":quesbank[qbindex].direction_right,
          "direction_left":quesbank[qbindex].ques_bank,
          "question":quesbank[qbindex].question ,
          "qustionansw":cardslistarr
        }
        questionsarraa.push(json);
        
    next(null);
        })  
        
       
    }
  })

      },function(err){

        res.send(questionsarraa);




})
    }
  })
})


// app.get("/selfieapi/:deckid/:gamemode/:gametype/:langid",function(req,res){

// var query="SELECT question_bank.*,theme_master.theme_id,theme_master.direction_up,theme_master.direction_down,theme_master.direction_left,theme_master.direction_right,ques_for_questionbank.question FROM question_bank LEFT JOIN ques_for_questionbank ON question_bank.quesb_id=ques_for_questionbank.ques_bank_id LEFT JOIN theme_master ON question_bank.theme_id=theme_master.theme_id WHERE question_bank.deck_id='"+req.params.deckid+"' AND question_bank.gamemode='"+req.params.gamemode+"' AND question_bank.gametype_id='"+req.params.gametype+"' AND question_bank.Language='"+req.params.langid+"' GROUP BY question_bank.quesb_id";
// var quesbankarray=[];
// connection.query(query,function(err,quesbank,fields){
//     if(err){
//       console.log(err.message);
//     }
//     else if(quesbank){
//       async.forEachOf(quesbank,function (data, qbindex ,next) {
//         var query2="SELECT * FROM `ques_for_questionbank` WHERE deck_id='"+quesbank[qbindex].deck_id+"' AND gamemode='"+quesbank[qbindex].gamemode+"' AND game_typeid='"+quesbank[qbindex].gametype_id+"' AND lang_id='"+quesbank[qbindex].Language+"' AND ques_for_questionbank.ques_bank_id='"+quesbank[qbindex].quesb_id+"'";
        
//          connection.query(query2,function(err,questions,fields){
//     if(err){
//       console.log(err.message);
//     }
//     else if(questions){
//       var questionsarrjson=[];
//       async.forEachOf(questions,function (data1, questionindex ,questionnext) {
//            var query3="SELECT ans_to_ques.*,directionscore.direction_leftscore as leftscore,directionscore.direction_rightscore as rightscore,directionscore.direction_upscore as upscore,directionscore.direction_downscore as downscore,theme_master.direction_up as uparrow,theme_master.direction_down as downarrow,theme_master.direction_left as leftarrow,theme_master.direction_right as rightarrow ,ques_for_questionbank.question,word.word,word.synonym,card.deck_id,card.card_name,language.lang_id,language.language,card.img_url,category.category_name FROM ans_to_ques left JOIN card ON ans_to_ques.card_id=card.card_id left JOIN category on ans_to_ques.cat_id=category.catid left JOIN ques_for_questionbank ON ans_to_ques.ques_id=ques_for_questionbank.ques_id left JOIN language ON ques_for_questionbank.lang_id=language.lang_id left JOIN word ON ans_to_ques.card_id=word.card_id LEFT JOIN theme_master ON ans_to_ques.theme_id=theme_master.theme_id LEFT JOIN directionscore ON theme_master.theme_id=directionscore.theme_id WHERE ans_to_ques.deck_id ='"+questions[questionindex].deck_id+"' AND ans_to_ques.quesb_id='"+questions[questionindex].ques_bank_id+"' AND ans_to_ques.ques_id='"+questions[questionindex].ques_id+"' group BY ans_to_ques.card_id";
//            connection.query(query3,function(err,cardslist,fields){

//               if(err){
//       console.log(err.message);
//     }
//     else if(cardslist){

      
//       async.forEachOf(cardslist,function (data2, cardindex ,cardnext) {
//         var imgurl=imgURL+cardslist[cardindex].img_url;
//         cardslist[cardindex].img_url=imgurl;
//         var query4="SELECT ans_to_ques.card_id,ans_to_ques.cat_id,ans_to_ques.card_score as cat_score,category.category_name FROM ans_to_ques INNER JOIN theme_master  ON ans_to_ques.theme_id=theme_master.theme_id LEFT JOIN directionscore on ans_to_ques.theme_id=directionscore.theme_id inner JOIN category ON ans_to_ques.cat_id=category.catid  where ans_to_ques.card_id='"+cardslist[cardindex].card_id+"' GROUP by cat_id";
//         connection.query(query4,function(err,categorylist,fields){
//               if(err){
//       console.log(err.message);
//                     }
//               else if(categorylist){
//                 cardslist[cardindex].category=categorylist;
//                 cardnext();
//               }
//           })
//       },function(err){
//         var json={
//           "question":questions[questionindex].question,
//           "quesid":questions[questionindex].ques_id,
//           "cards":cardslist
//         };
//         questionsarrjson.push(json);
        
      
//       questionnext(null);
//       })




//     }

//   })
//          },function(err){

//            var json={
//           "questionbankname":quesbank[qbindex].ques_bank,
//           "questionbankid":quesbank[qbindex].quesb_id,
//           "direction_up":quesbank[qbindex].direction_up,
//           "direction_down":quesbank[qbindex].direction_down,
//           "direction_right":quesbank[qbindex].direction_right,
//           "direction_left":quesbank[qbindex].direction_left,
//           "deck_id":quesbank[qbindex].deck_id,
//           "gamemode":quesbank[qbindex].gamemode,
//           "game_typeid":quesbank[qbindex].gametype_id,
//           "lang_id":quesbank[qbindex].Language,
//           "theme_id":quesbank[qbindex].theme_id,
//           "questions":questionsarrjson
//            };
//       quesbankarray.push(json);
//       next(null);

//          })
           
     
//     }
//   })

//       },function(err){
       
//         res.send(quesbankarray);
// })

//     }
//   })
// })
app.get("/loadAllQuestionBanks/:deckid/:gamemode/:gametype/:langid",function(req,res){
  var query="SELECT question_bank.*,theme_master.theme_id,theme_master.direction_up,theme_master.direction_down,theme_master.direction_left,theme_master.direction_right FROM question_bank inner join ans_to_ques on ans_to_ques.quesb_id=question_bank.quesb_id inner join theme_master on theme_master.theme_id=question_bank.theme_id  WHERE question_bank.status='A' AND question_bank.deck_id="+req.params.deckid+" AND question_bank.Language="+req.params.langid+" AND question_bank.gametype_id="+req.params.gametype+" and question_bank.gamemode="+req.params.gamemode+" group by question_bank.quesb_id";
  connection.query(query,function(err,rows,fields){
if(err){
  console.log(err.message);
}else{
  res.send(rows);
}
  })
})
app.get("/selfieapi/:deckid/:gamemode/:gametype/:langid/:bankid",function(req,res){

var query="SELECT question_bank.*,theme_master.theme_id,theme_master.direction_up,theme_master.direction_down,theme_master.direction_left,theme_master.direction_right FROM question_bank inner join theme_master on theme_master.theme_id=question_bank.theme_id  WHERE question_bank.status='A' AND question_bank.deck_id="+req.params.deckid+" AND question_bank.Language="+req.params.langid+" AND question_bank.gametype_id="+req.params.gametype+" and question_bank.gamemode="+req.params.gamemode+" AND question_bank.quesb_id="+req.params.bankid+"";
var quesbankarray=[];
connection.query(query,function(err,quesbank,fields){
    if(err){
      console.log(err.message);
    }
    else if(quesbank){
      async.forEachOf(quesbank,function (data, qbindex ,next) {
        var query2="SELECT * FROM `ques_for_questionbank` WHERE deck_id='"+quesbank[qbindex].deck_id+"' AND gamemode='"+quesbank[qbindex].gamemode+"' AND game_typeid='"+quesbank[qbindex].gametype_id+"' AND lang_id='"+quesbank[qbindex].Language+"' AND ques_for_questionbank.ques_bank_id='"+quesbank[qbindex].quesb_id+"'";
        
         connection.query(query2,function(err,questions,fields){
    if(err){
      console.log(err.message);
    }
    else if(questions){
      var questionsarrjson=[];
      async.forEachOf(questions,function (data1, questionindex ,questionnext) {
           var query3="SELECT ans_to_ques.*,directionscore.direction_leftscore as leftscore,directionscore.direction_rightscore as rightscore,directionscore.direction_upscore as upscore,directionscore.direction_downscore as downscore,theme_master.direction_up as uparrow,theme_master.direction_down as downarrow,theme_master.direction_left as leftarrow,theme_master.direction_right as rightarrow ,ques_for_questionbank.question,word.word,word.synonym,card.deck_id,card.card_name,language.lang_id,language.language,card.img_url,cattheme.category FROM ans_to_ques left JOIN card ON ans_to_ques.card_id=card.card_id inner join cattheme on ans_to_ques.cat_id=cattheme.cattheme_id and cattheme.status='A' left JOIN ques_for_questionbank ON ans_to_ques.ques_id=ques_for_questionbank.ques_id left JOIN language ON ques_for_questionbank.lang_id=language.lang_id left JOIN word ON ans_to_ques.card_id=word.card_id and word.lang_id="+req.params.langid+" and word.Status='A' LEFT JOIN theme_master ON ans_to_ques.theme_id=theme_master.theme_id LEFT JOIN directionscore ON theme_master.theme_id=directionscore.theme_id WHERE ans_to_ques.deck_id ='"+questions[questionindex].deck_id+"' AND ans_to_ques.quesb_id='"+questions[questionindex].ques_bank_id+"' AND ans_to_ques.ques_id='"+questions[questionindex].ques_id+"' AND ans_to_ques.status='A'  group BY ans_to_ques.card_id";
           console.log(query3);
           connection.query(query3,function(err,cardslist,fields){

              if(err){
      console.log(err.message);
    }
    else if(cardslist){

        // console.log("New cardlist",cardslist);

      async.forEachOf(cardslist,function (data2, cardindex ,cardnext) {
        var imgurl=imgURL+cardslist[cardindex].img_url;
        cardslist[cardindex].img_url=imgurl;
        var query4="SELECT ans_to_ques.card_id,ans_to_ques.cat_id,ans_to_ques.card_score as cat_score,cattheme.category FROM ans_to_ques INNER JOIN theme_master  ON ans_to_ques.theme_id=theme_master.theme_id LEFT JOIN directionscore on ans_to_ques.theme_id=directionscore.theme_id inner JOIN cattheme ON ans_to_ques.cat_id=cattheme.cattheme_id  where ans_to_ques.card_id='"+cardslist[cardindex].card_id+"' GROUP by cat_id";
        connection.query(query4,function(err,categorylist,fields){
              if(err){
      console.log(err.message);
                    }
              else if(categorylist){
                cardslist[cardindex].category=categorylist;
                cardnext();
              }
          })
      },function(err){
        var json={
          "question":questions[questionindex].question,
          "quesid":questions[questionindex].ques_id,
          "cards":cardslist
        };
        if(cardslist.length>0){
        questionsarrjson.push(json);
        }
        
      
      questionnext(null);
      })




    }

  })
         },function(err){

           var json={
          "questionbankname":quesbank[qbindex].ques_bank,
          "questionbankid":quesbank[qbindex].quesb_id,
          "direction_up":quesbank[qbindex].direction_up,
          "direction_down":quesbank[qbindex].direction_down,
          "direction_right":quesbank[qbindex].direction_right,
          "direction_left":quesbank[qbindex].direction_left,
          "deck_id":quesbank[qbindex].deck_id,
          "gamemode":quesbank[qbindex].gamemode,
          "game_typeid":quesbank[qbindex].gametype_id,
          "lang_id":quesbank[qbindex].Language,
          "theme_id":quesbank[qbindex].theme_id,
          "questions":questionsarrjson
           };
           if(questionsarrjson.length>0){
            
      quesbankarray.push(json);
           }
      next(null);

         })
           
     
    }
  })

      },function(err){
       
        res.send(quesbankarray);
})

    }
  })
})
app.get("/perceptionapi/:deckid/:gamemode/:gametype/:langid",function(req,res){

var query="SELECT question_bank.*,theme_master.theme_id,theme_master.direction_up,theme_master.direction_down,theme_master.direction_left,theme_master.direction_right FROM question_bank inner join theme_master on theme_master.theme_id=question_bank.theme_id  WHERE question_bank.status='A' AND question_bank.deck_id="+req.params.deckid+" AND question_bank.Language="+req.params.langid+" AND question_bank.gametype_id="+req.params.gametype+" and question_bank.gamemode="+req.params.gamemode+"";
var quesbankarray=[];
connection.query(query,function(err,quesbank,fields){
    if(err){
      console.log(err.message);
    }
    else if(quesbank){
      async.forEachOf(quesbank,function (data, qbindex ,next) {
        var query2="SELECT * FROM `ques_for_questionbank` WHERE deck_id='"+quesbank[qbindex].deck_id+"' AND gamemode='"+quesbank[qbindex].gamemode+"' AND game_typeid='"+quesbank[qbindex].gametype_id+"' AND lang_id='"+quesbank[qbindex].Language+"' AND ques_for_questionbank.ques_bank_id='"+quesbank[qbindex].quesb_id+"'";
        
         connection.query(query2,function(err,questions,fields){
    if(err){
      console.log(err.message);
    }
    else if(questions){
      var questionsarrjson=[];
      async.forEachOf(questions,function (data1, questionindex ,questionnext) {
           var query3="SELECT ans_to_ques.*,directionscore.direction_leftscore as leftscore,directionscore.direction_rightscore as rightscore,directionscore.direction_upscore as upscore,directionscore.direction_downscore as downscore,theme_master.direction_up as uparrow,theme_master.direction_down as downarrow,theme_master.direction_left as leftarrow,theme_master.direction_right as rightarrow ,ques_for_questionbank.question,word.word,word.synonym,card.deck_id,card.card_name,language.lang_id,language.language,card.img_url,cattheme.category FROM ans_to_ques left JOIN card ON ans_to_ques.card_id=card.card_id inner join cattheme on ans_to_ques.cat_id=cattheme.cattheme_id and cattheme.status='A' left JOIN ques_for_questionbank ON ans_to_ques.ques_id=ques_for_questionbank.ques_id left JOIN language ON ques_for_questionbank.lang_id=language.lang_id left JOIN word ON ans_to_ques.card_id=word.card_id and word.lang_id="+req.params.langid+" LEFT JOIN theme_master ON ans_to_ques.theme_id=theme_master.theme_id LEFT JOIN directionscore ON theme_master.theme_id=directionscore.theme_id WHERE ans_to_ques.deck_id ='"+questions[questionindex].deck_id+"' AND ans_to_ques.quesb_id='"+questions[questionindex].ques_bank_id+"' AND ans_to_ques.ques_id='"+questions[questionindex].ques_id+"' AND ans_to_ques.status='A' group BY ans_to_ques.card_id";
           console.log(query3);
           connection.query(query3,function(err,cardslist,fields){

              if(err){
      console.log(err.message);
    }
    else if(cardslist){

        // console.log("New cardlist",cardslist);

      async.forEachOf(cardslist,function (data2, cardindex ,cardnext) {
        var imgurl=imgURL+cardslist[cardindex].img_url;
        cardslist[cardindex].img_url=imgurl;
        var query4="SELECT ans_to_ques.card_id,ans_to_ques.cat_id,ans_to_ques.card_score as cat_score,cattheme.category FROM ans_to_ques INNER JOIN theme_master  ON ans_to_ques.theme_id=theme_master.theme_id LEFT JOIN directionscore on ans_to_ques.theme_id=directionscore.theme_id inner JOIN cattheme ON ans_to_ques.cat_id=cattheme.cattheme_id  where ans_to_ques.card_id='"+cardslist[cardindex].card_id+"' GROUP by cat_id";
        connection.query(query4,function(err,categorylist,fields){
              if(err){
      console.log(err.message);
                    }
              else if(categorylist){
                cardslist[cardindex].category=categorylist;
                cardnext();
              }
          })
      },function(err){
        var json={
          "question":questions[questionindex].question,
          "quesid":questions[questionindex].ques_id,
          "cards":cardslist
        };
        if(cardslist.length>0){
        questionsarrjson.push(json);
        }
        
      
      questionnext(null);
      })




    }

  })
         },function(err){

           var json={
          "questionbankname":quesbank[qbindex].ques_bank,
          "questionbankid":quesbank[qbindex].quesb_id,
          "direction_up":quesbank[qbindex].direction_up,
          "direction_down":quesbank[qbindex].direction_down,
          "direction_right":quesbank[qbindex].direction_right,
          "direction_left":quesbank[qbindex].direction_left,
          "deck_id":quesbank[qbindex].deck_id,
          "gamemode":quesbank[qbindex].gamemode,
          "game_typeid":quesbank[qbindex].gametype_id,
          "lang_id":quesbank[qbindex].Language,
          "theme_id":quesbank[qbindex].theme_id,
          "questions":questionsarrjson
           };
           if(questionsarrjson.length>0){
            
      quesbankarray.push(json);
           }
      next(null);

         })
           
     
    }
  })

      },function(err){
       
        res.send(quesbankarray);
})

    }
  })
})

function makeid() {
  var text = "";
  var possible = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";

  for (var i = 0; i < 5; i++)
    text += possible.charAt(Math.floor(Math.random() * possible.length));

  return text;
}

app.get("/senduniqueid/",function(req,res){
  var query1="select * from uniqueidgenerate";
  connection.query(query1,function(err,rows1,fields){
 if(err){
  console.log(err.message);
 }
else if(rows1){
  var uniquesid=rows1[0].Uniq_no+1;
  var query2="update uniqueidgenerate set uniqueidgenerate.Uniq_no="+uniquesid+" where uniqueidgenerate.Uniqueid='"+rows1[0].Uniqueid+"'";
  connection.query(query2,function(err,rows3,fields){
    if(err){
      console.log(err.message);
     }
     else{
      var randstr=makeid();
      res.send(randstr+uniquesid);
     }

  })
}


  })
})
function removeDuplicates(originalArray, prop) {
     var newArray = [];
     var lookupObject  = {};

     for(var i in originalArray) {
        lookupObject[originalArray[i][prop]] = originalArray[i];
     }

     for(i in lookupObject) {
         newArray.push(lookupObject[i]);
     }
      return newArray;
 }
app.post("/insert_hist_selfi",urlencodedParser,function(req,res){
  console.log("selfie",req.body);
if(req.body.length>0){
  

  // var query3="select * from selfi_history where uniqueid='"+req.body[0].uniqueid+"' and player_id="+req.body[0].player_id+"";
  // connection.query(query3,function(err,rows,fields){
  //   if(err){
  //     console.log(err.message);
  //   }
  //   else if(rows.length>0){
  //     res.send("not Saved");
  //   }
  //   else{
       var query2="insert into selfi_history(uniqueid ,game_id, player_id,attendID,quesbank_id, question_id,card_id,directionname,directionscore,theme_id,directionval,date)VALUES ?";
   var values=[];
var histroyArray=req.body;
var newdate=new Date();

    for(i=0;i<histroyArray.length;i++)
    {
      values.push([histroyArray[i].uniqueid, histroyArray[i].game_id,histroyArray[i].player_id,histroyArray[i].attendID,histroyArray[i].quesbank_id,histroyArray[i].question_id,histroyArray[i].card_id,histroyArray[i].directionname,histroyArray[i].directionscore,histroyArray[i].theme_id,histroyArray[i].directionval,newdate]);
    }
console.log(values);
connection.query(query2, [values], function(err) {
    if (err) 
      throw err;
    else
    {
      res.send("Inserted");
    }
});
//     }
//   })
}
else{
      res.send("no data");

}
  
})

app.get("/scenarioapi/:deckid/:gamemode/:gametype/:langid",function(req,res){

console.log(req.params)
var query="SELECT question_bank.*,ques_for_questionbank.question FROM question_bank LEFT JOIN ques_for_questionbank ON question_bank.quesb_id=ques_for_questionbank.ques_bank_id LEFT JOIN theme_master ON question_bank.theme_id=theme_master.theme_id WHERE question_bank.status='A' and question_bank.deck_id='"+req.params.deckid+"' AND question_bank.gamemode='"+req.params.gamemode+"' AND question_bank.gametype_id='"+req.params.gametype+"' AND question_bank.Language='"+req.params.langid+"' GROUP BY question_bank.quesb_id ";
console.log(query);
var quesbankarray=[];
connection.query(query,function(err,quesbank,fields){
    if(err){
      console.log(err.message);
    }
    else if(quesbank){
      async.forEachOf(quesbank,function (data, qbindex ,next) {
        var query2="SELECT * FROM `ques_for_questionbank` WHERE deck_id='"+quesbank[qbindex].deck_id+"' AND gamemode='"+quesbank[qbindex].gamemode+"' AND game_typeid='"+quesbank[qbindex].gametype_id+"' AND lang_id='"+quesbank[qbindex].Language+"' AND ques_for_questionbank.ques_bank_id='"+quesbank[qbindex].quesb_id+"'";
        // console.log(query2);
         connection.query(query2,function(err,questions,fields){
    if(err){
      console.log(err.message);
    }
    else if(questions){
      var questionsarrjson=[];
      async.forEachOf(questions,function (data1, questionindex ,questionnext) {
        /*
SELECT ans_to_ques.*,directionscore.direction_leftscore as leftscore,directionscore.direction_rightscore as rightscore,directionscore.direction_upscore as upscore,directionscore.direction_downscore as downscore,theme_master.direction_up as uparrow,theme_master.direction_down as downarrow,theme_master.direction_left as leftarrow,theme_master.direction_right as rightarrow ,ques_for_questionbank.question,word.word,word.synonym,card.deck_id,card.card_name,language.lang_id,language.language,card.img_url,category.category_name FROM ans_to_ques left JOIN card ON ans_to_ques.card_id=card.card_id left JOIN category on ans_to_ques.cat_id=category.catid left JOIN ques_for_questionbank ON ans_to_ques.ques_id=ques_for_questionbank.ques_id left JOIN language ON ques_for_questionbank.lang_id=language.lang_id left JOIN word ON ans_to_ques.card_id=word.card_id LEFT JOIN theme_master ON ans_to_ques.theme_id=theme_master.theme_id LEFT JOIN directionscore ON theme_master.theme_id=directionscore.theme_id WHERE ans_to_ques.deck_id ='8' AND ans_to_ques.quesb_id='26' AND ans_to_ques.ques_id='16' group BY ans_to_ques.card_id
        */
           var query3="SELECT ans_to_ques.*,ques_for_questionbank.question,word.word,word.synonym,card.deck_id,card.card_name,language.lang_id,language.language,card.img_url,cattheme.category FROM ans_to_ques left JOIN card ON ans_to_ques.card_id=card.card_id inner join cattheme on ans_to_ques.cat_id=cattheme.cattheme_id and cattheme.status='A' left JOIN ques_for_questionbank ON ans_to_ques.ques_id=ques_for_questionbank.ques_id left JOIN language ON ques_for_questionbank.lang_id=language.lang_id left JOIN word ON ans_to_ques.card_id=word.card_id LEFT JOIN theme_master ON ans_to_ques.theme_id=theme_master.theme_id  WHERE ans_to_ques.deck_id ='"+questions[questionindex].deck_id+"' AND ans_to_ques.quesb_id='"+questions[questionindex].ques_bank_id+"' AND ans_to_ques.ques_id='"+questions[questionindex].ques_id+"'  AND ans_to_ques.status='A' group BY ans_to_ques.card_id";
           connection.query(query3,function(err,cardslist,fields){
              if(err){
      console.log(err.message);
    }
    else if(cardslist){

      async.forEachOf(cardslist,function (data2, cardindex ,cardnext) {
        // var loc = window.location.pathname;
        // var dir = loc.substring(0, loc.lastIndexOf('/'));
        var imgurl=imgURL+cardslist[cardindex].img_url;
        
        cardslist[cardindex].img_url=imgurl;
        console.log("cardslist",cardslist[cardindex].card_id);
        var query4="SELECT ans_to_ques.card_id,ans_to_ques.cat_id,ans_to_ques.card_score as score,cattheme.category as title FROM ans_to_ques left JOIN theme_master  ON ans_to_ques.theme_id=theme_master.theme_id inner join cattheme ON ans_to_ques.cat_id=cattheme.cattheme_id and cattheme.status='A'  where ans_to_ques.card_id='"+cardslist[cardindex].card_id+"' GROUP by cat_id";
        connection.query(query4,function(err,categorylist,fields){
              if(err){
      console.log(err.message);
                    }
              else if(categorylist){
                cardslist[cardindex].category=categorylist;
                cardnext();
              }
          })

      },function(err){
        var json={
          "question":questions[questionindex].question,
          "quesid":questions[questionindex].ques_id,
          "cards":cardslist
        };
        if(cardslist.length>0){  
        questionsarrjson.push(json);
        }
        
      // questions[questionindex].cards=cardslist;
      questionnext(null);
      })




    }

  })


         },function(err){

           var json={
          "questionbankname":quesbank[qbindex].ques_bank,
          "questionbankid":quesbank[qbindex].quesb_id,
          "deck_id":quesbank[qbindex].deck_id,
          "gamemode":quesbank[qbindex].gamemode,
          "game_typeid":quesbank[qbindex].gametype_id,
          "lang_id":quesbank[qbindex].Language,
          "theme_id":quesbank[qbindex].theme_id,
          "questions":questionsarrjson
      };
      if(questionsarrjson.length > 0){
        quesbankarray.push(json);
      }
      next(null);

         })
            // questionset.push(questions); 
     
    }
  })

      },function(err){
       
        res.send(quesbankarray);
})
    }
  })
})

// function benchmark

var groupByBMTitle = function(rawData){
  var groupByBM = {};
  var groupedScore = {};
  var Outcome = [];
  var Output=[];
  
  for(var i = 0; i < rawData.length; i++ ){ 

    if(groupByBM[rawData[i].benchmark_title] == undefined){
          groupByBM[rawData[i].benchmark_title]  = [];            
          groupByBM[rawData[i].benchmark_title].push({'title':rawData[i].category,'score':rawData[i].bench_mark});          
          groupedScore[rawData[i].benchmark_title] = {'score':parseInt(rawData[i].bench_mark), 'title':rawData[i].benchmark_title };
          Outcome.push({'title':rawData[i].benchmark_title,'data':groupByBM[rawData[i].benchmark_title],'color':rawData[i].color});
          Output.push({'title':rawData[i].benchmark_title,'score':groupedScore[rawData[i].benchmark_title],'color':rawData[i].color})
    }else{
          groupByBM[rawData[i].benchmark_title].push({'title':rawData[i].category,'score':rawData[i].bench_mark});
          groupedScore[rawData[i].benchmark_title].score+=parseInt(rawData[i].bench_mark);
          
          
    }
  }
  
  
var mynewArray = {
    output : Output,
    outcome : Outcome
  }

  return mynewArray;
}

var groupingCategory = function(rawData){
   var groupByCT = {};
  // var groupedScore = {};
  var Outcome = [];
  // var Output=[];
  console.log("CompletedrawData",rawData);
  for(var i = 0; i < rawData.length; i++ ){ 
// console.log("rawData[i].Category",)
    if(groupByCT[rawData[i].Category] == undefined){
          groupByCT[rawData[i].Category]  = [];            
          groupByCT[rawData[i].Category]={'title':rawData[i].Category,'score':parseInt(rawData[i].score)};          
          // groupedScore[rawData[i].Category] = {'score':parseInt(rawData[i].score), 'title':rawData[i].Category };
          Outcome.push(groupByCT[rawData[i].Category]);
          // Output.push({'title':rawData[i].Category,'score':groupedScore[rawData[i].Category],'color':rawData[i].color})
    }else{
      console.log("exists",groupByCT[rawData[i].Category].score);
          // groupByCT[rawData[i].Category].push({'title':rawData[i].Category,'score':rawData[i].score});
          groupByCT[rawData[i].Category].score+=parseInt(rawData[i].score);
          
          
    }
  }
  // var mynewArray = {
  //   outcome : groupByCT
  // }
  return Outcome;
}
// 



// mobile benchmark disp

app.get("/getbenchmark2/:game_mode/:game_id/:deck_id",function(req,res){
  
var query = "SELECT benchmark_master.*,cattheme.category FROM benchmark_master inner join cattheme ON cattheme.cattheme_id = benchmark_master.cat_id and cattheme.status='A'  and cattheme.deck_id="+req.params.deck_id+" WHERE benchmark_master.game_mode="+req.params.game_mode+" AND benchmark_master.game_id="+req.params.game_id+"";
connection.query(query,function(err,rows,fields){
  if(err){
    console.log(err.message);
  }else{

    res.send(JSON.stringify(groupByBMTitle(rows)));
  }
})
})
//display history scenario
app.get("/disphist_scenariohist/:playerid/:gameid/:uniqueid/:gamemode",function(req,res){
var query = "SELECT * FROM scenario_history where scenario_history.player_id = "+req.params.playerid+" and scenario_history.game_id = "+req.params.gameid+" and uniqueid = '"+req.params.uniqueid+"' ";
// console.log(query);
      var category_Array=[];
connection.query(query,function(err,history,fields){
  if(err){
    console.log(err.message);
  }else{
    // var 
      var cardarray={'benchmark_array':[],'userData':{'output':[],'outcome':[]}};
    async.forEachOf(history,function (data,historyindex,historynext) {
      // res.send(history[historyindex]);
      var cards=history[historyindex].ans_cardid1.split(',');
      
      var sum_card_score=0;
      async.forEachOf(cards,function (data,cardsindex,cardnext) {
          var query = "SELECT sum(ans_to_ques.card_score) as score,cattheme.theme as categoryTheme,cattheme.category as Category,ans_to_ques.card_score as catScore from ans_to_ques INNER JOIN cattheme ON cattheme.cattheme_id=ans_to_ques.cat_id where ans_to_ques.quesb_id = "+history[historyindex].quesbank_id+" and ans_to_ques.ques_id = "+history[historyindex].ques_id+"  and ans_to_ques.game_id = "+history[historyindex].game_id+" and ans_to_ques.card_id = "+cards[cardsindex]+" GROUP BY category";
          console.log(query);
          connection.query(query,function(err,rows,fields){
            console.log("rows",rows);
            // console.log(rows[0].score);
            // if(rows[0].score==null){
            // sum_card_score+=0;  
            // }
            // else{
              if(rows.length>0){
              for(i=0;i<rows.length;i++){

            category_Array.push(rows[i]);
              }
            // cardarray.userData.outcome.push(groupingCategory(category_Array));
            // if()
            sum_card_score+=rows[0].score;
          }
            // }  
        // console.log(sum_card_score);
          cardnext(null);
          })
      },function(err){
        console.log("sum",sum_card_score);
        console.log("category_Array",category_Array)
        var GroupedData=groupingCategory(category_Array);

        cardarray.userData.outcome.push(GroupedData);
        cardarray.userData.output.push(sum_card_score);
      historynext(null);
      })
    },function(err){
      var query = "SELECT benchmark_master.*,cattheme.category FROM benchmark_master inner join cattheme ON cattheme.cattheme_id = benchmark_master.cat_id and cattheme.status='A' WHERE benchmark_master.game_mode="+req.params.gamemode+" AND benchmark_master.game_id="+req.params.gameid+" ";
      connection.query(query,function(err,rows,fields){
  if(err){
    console.log(err.message);
  }else{
cardarray.benchmark_array.push(groupByBMTitle(rows));
    res.send(JSON.stringify(cardarray));
  }
})
      // res.send(cardarray);
    })


  }
})
})

app.get('/removeselfie',function(req,res){
  var query="delete from ans_to_ques where ans_to_ques.game_id=2";
  connection.query(query,function(err,rows,fields){
    if(err){
      console.log(err.message);
    }else{
      res.send("removed...");
    }
  })
})
app.get("/disphist_anstoquesforscenario/:quesb_id/:ques_id/:game_id/:card_id",function(req,res){
var query = "SELECT sum(ans_to_ques.card_score) as score from ans_to_ques where ans_to_ques.quesb_id = "+req.params.quesb_id+" and ans_to_ques.ques_id = "+req.params.ques_id+"  and ans_to_ques.game_id = "+req.params.game_id+" and ans_to_ques.card_id = "+req.params.card_id+"";
// console.log(query);
connection.query(query,function(err,rows,fields){6
  if(err){
    console.log(err.message);
  }else{
    res.send(JSON.stringify(rows));
  }
})
})

app.get("/oddballapi/:deckid/:gamemode/:gametype/:langid",function(req,res){
  console.log("inside");

var query="SELECT question_bank.*,theme_master.*,theme_master.direction_up,theme_master.direction_down,theme_master.direction_left,theme_master.direction_right,ques_for_questionbank.question FROM question_bank LEFT JOIN ques_for_questionbank ON question_bank.quesb_id=ques_for_questionbank.ques_bank_id LEFT JOIN theme_master ON question_bank.theme_id=theme_master.theme_id WHERE question_bank.status='A' and question_bank.deck_id='"+req.params.deckid+"' AND question_bank.gamemode='"+req.params.gamemode+"' AND question_bank.gametype_id='"+req.params.gametype+"' AND question_bank.Language='"+req.params.langid+"' GROUP BY question_bank.quesb_id";
var quesbankarray=[];
connection.query(query,function(err,quesbank,fields){
    if(err){
      console.log(err.message);
    }
    else if(quesbank){

      console.log("quesbank",quesbank);
      async.forEachOf(quesbank,function (data, qbindex ,next) {
        console.log('qinside',quesbank);
        var query2="SELECT * FROM `ques_for_questionbank` WHERE deck_id='"+quesbank[qbindex].deck_id+"' AND gamemode='"+quesbank[qbindex].gamemode+"' AND game_typeid='"+quesbank[qbindex].gametype_id+"' AND lang_id='"+quesbank[qbindex].Language+"' AND ques_for_questionbank.ques_bank_id='"+quesbank[qbindex].quesb_id+"'";
        console.log(query2);
        // console.log(query2);
         connection.query(query2,function(err,questions,fields){
    if(err){
      console.log(err.message);
    }
    else if(questions){
      console.log("questions");
      var questionsarrjson=[];
      async.forEachOf(questions,function (data1, questionindex ,questionnext) {
           var query3="SELECT ans_to_ques.*,directionscore.direction_leftscore as leftscore,directionscore.direction_rightscore as rightscore,directionscore.direction_upscore as upscore,directionscore.direction_downscore as downscore,theme_master.direction_up as uparrow,theme_master.direction_down as downarrow,theme_master.direction_left as leftarrow,theme_master.direction_right as rightarrow ,ques_for_questionbank.question,word.word,word.synonym,card.deck_id,card.card_name,language.lang_id,language.language,card.img_url,cattheme.category FROM ans_to_ques left JOIN card ON ans_to_ques.card_id=card.card_id inner join cattheme on ans_to_ques.cat_id=cattheme.cattheme_id and cattheme.status='A' left JOIN ques_for_questionbank ON ans_to_ques.ques_id=ques_for_questionbank.ques_id left JOIN language ON ques_for_questionbank.lang_id=language.lang_id left JOIN word ON ans_to_ques.card_id=word.card_id LEFT JOIN theme_master ON ans_to_ques.theme_id=theme_master.theme_id LEFT JOIN directionscore ON theme_master.theme_id=directionscore.theme_id WHERE  ans_to_ques.status='A' and ans_to_ques.deck_id ='"+questions[questionindex].deck_id+"' AND ans_to_ques.quesb_id='"+questions[questionindex].ques_bank_id+"' AND ans_to_ques.ques_id='"+questions[questionindex].ques_id+"' group BY ans_to_ques.card_id";
           console.log("newquery3",query3);
           connection.query(query3,function(err,cardslist,fields){
              if(err){
      console.log(err.message);
    }
    else if(cardslist){

      async.forEachOf(cardslist,function (data2, cardindex ,cardnext) {
        console.log("cardslist",cardslist[cardindex].card_id);
        var imgurl=imgURL+cardslist[cardindex].img_url;
        cardslist[cardindex].img_url=imgurl;
        cardslist[cardindex].correctanswer='1';
        var query4="SELECT ans_to_ques.card_id,ans_to_ques.cat_id,ans_to_ques.card_score as cat_score,cattheme.category FROM ans_to_ques left JOIN theme_master  ON ans_to_ques.theme_id=theme_master.theme_id LEFT JOIN directionscore on ans_to_ques.theme_id=directionscore.theme_id inner JOIN cattheme ON ans_to_ques.cat_id=cattheme.cattheme_id  where ans_to_ques.card_id='"+cardslist[cardindex].card_id+"' GROUP by cat_id";
        connection.query(query4,function(err,categorylist,fields){
              if(err){
      console.log(err.message);
                    }
              else if(categorylist){

                cardslist[cardindex].category=categorylist;
                cardnext();
              }
          })

      },function(err){
        async.forEachOf(cardslist,function (data2,randomindex ,randomnext) {
          var query5="SELECT * FROM card LEFT JOIN deck ON deck.DeckID=card.deck_id LEFT JOIN word ON word.card_id=card.card_id LEFT JOIN language ON word.lang_id=language.lang_id WHERE card.deck_id='"+cardslist[randomindex].deck_id+"' AND word.lang_id='"+cardslist[randomindex].lang_id+"' AND card.card_id !='"+cardslist[randomindex].card_id+"' ORDER BY rand() LIMIT 2 ";
          console.log(query5);
          connection.query(query5,function(err,randomlist,fields){
             if(err){
      console.log(err.message);
                    }
              else if(randomlist){
                for(i=0;i<randomlist.length;i++){
                  var imgurl=imgURL+randomlist[i].img_url;
                    randomlist[i].img_url=imgurl;
                  // console.log(cardslist[randomindex].length);
                  if(cardslist.length <5){
                    randomlist[i].correctanswer='0';
                cardslist.push(randomlist[i]);
                    
                  }
                  else{

                  }
                  
                }
                // console.log(cardslist);
                randomnext();

              }

          })

        },function(){
          var json={
          "question":questions[questionindex].question,
          "quesid":questions[questionindex].ques_id,
          "cards":cardslist
        };
        if(cardslist.length>0){
        questionsarrjson.push(json);
        }
        
      // questions[questionindex].cards=cardslist;
      questionnext(null);

        })

        
      })




    }

  })


         },function(err){

           var json={
          "questionbankname":quesbank[qbindex].ques_bank,
          "questionbankid":quesbank[qbindex].quesb_id,
          "deck_id":quesbank[qbindex].deck_id,
          "gamemode":quesbank[qbindex].gamemode,
          "game_typeid":quesbank[qbindex].gametype_id,
          "lang_id":quesbank[qbindex].Language,
          "theme_id":quesbank[qbindex].theme_id,
          "questions":questionsarrjson
      };
      if(questionsarrjson.length>0){
        
      quesbankarray.push(json);
      }
      next(null);

         })
            // questionset.push(questions); 
     
    }
  })

      },function(err){
       
        res.send(quesbankarray);
})
    }
  })
})



app.get("/disphist_selfioutcome/:playerid/:gameid/:uniqueid/:direction",function(req,res){
  var cardarray=[];
  var scoreobj={};
  var query="SELECT * FROM selfi_history where selfi_history.player_id = "+req.params.playerid+" and selfi_history.game_id = "+req.params.gameid+" and selfi_history.uniqueid = '"+req.params.uniqueid+"' and direction = "+req.params.direction+"";
  connection.query(query,function(err,rows,fields){
    if(err){
      console.log(err.message);
    }
    else {
      for(i=0;i<rows.length;i++){
cardarray.push(rows[i])
      }
      async.forEachOf(cardarray,function (data, index ,next) {
        scoreobj={};
        var scorequery="SELECT sum(ans_to_ques.card_score) as myscore FROM ans_to_ques LEFT JOIN category ON category.catid = ans_to_ques.cat_id  where ans_to_ques.quesb_id = "+rows[index].quesbank_id+" and ans_to_ques.ques_id = "+rows[index].question_id+"  and ans_to_ques.game_id = "+rows[index].game_id+" and ans_to_ques.card_id = "+rows[index].card_id+"";
        connection.query(scorequery,function(err,rows,fields){
          if(err){
            console.log(err.message);
          }
          else{
            cardarray[index].scoredata=rows;
          }
          next();
        })
      },function(err){
        res.send(cardarray);
      })
    }
  })
})


app.get("/surveyapi/:deckid/:gamemode/:gametype/:langid",function(req,res){

var query="SELECT question_bank.*,ques_for_questionbank.question FROM question_bank LEFT JOIN ques_for_questionbank ON question_bank.quesb_id=ques_for_questionbank.ques_bank_id LEFT JOIN theme_master ON question_bank.theme_id=theme_master.theme_id WHERE question_bank.status='A' and question_bank.deck_id='"+req.params.deckid+"' AND question_bank.gamemode='"+req.params.gamemode+"' AND question_bank.gametype_id='"+req.params.gametype+"' AND question_bank.Language='"+req.params.langid+"' GROUP BY question_bank.quesb_id";
var quesbankarray=[];
connection.query(query,function(err,quesbank,fields){
    if(err){
      console.log(err.message);
    }
    else if(quesbank){
      async.forEachOf(quesbank,function (data, qbindex ,next) {
        var query2="SELECT * FROM `ques_for_questionbank` WHERE deck_id='"+quesbank[qbindex].deck_id+"' AND gamemode='"+quesbank[qbindex].gamemode+"' AND game_typeid='"+quesbank[qbindex].gametype_id+"' AND lang_id='"+quesbank[qbindex].Language+"' AND ques_for_questionbank.ques_bank_id='"+quesbank[qbindex].quesb_id+"'";
        // console.log(query2);
         connection.query(query2,function(err,questions,fields){
    if(err){
      console.log(err.message);
    }
    else if(questions){
      var questionsarrjson=[];
      async.forEachOf(questions,function (data1, questionindex ,questionnext) {
        /*
SELECT ans_to_ques.*,directionscore.direction_leftscore as leftscore,directionscore.direction_rightscore as rightscore,directionscore.direction_upscore as upscore,directionscore.direction_downscore as downscore,theme_master.direction_up as uparrow,theme_master.direction_down as downarrow,theme_master.direction_left as leftarrow,theme_master.direction_right as rightarrow ,ques_for_questionbank.question,word.word,word.synonym,card.deck_id,card.card_name,language.lang_id,language.language,card.img_url,category.category_name FROM ans_to_ques left JOIN card ON ans_to_ques.card_id=card.card_id left JOIN category on ans_to_ques.cat_id=category.catid left JOIN ques_for_questionbank ON ans_to_ques.ques_id=ques_for_questionbank.ques_id left JOIN language ON ques_for_questionbank.lang_id=language.lang_id left JOIN word ON ans_to_ques.card_id=word.card_id LEFT JOIN theme_master ON ans_to_ques.theme_id=theme_master.theme_id LEFT JOIN directionscore ON theme_master.theme_id=directionscore.theme_id WHERE ans_to_ques.deck_id ='8' AND ans_to_ques.quesb_id='26' AND ans_to_ques.ques_id='16' group BY ans_to_ques.card_id
        */
           var query3="SELECT ans_to_ques.*,ques_for_questionbank.question,word.word,word.synonym,card.deck_id,card.card_name,language.lang_id,language.language,card.img_url,category.category_name FROM ans_to_ques left JOIN card ON ans_to_ques.card_id=card.card_id left JOIN category on ans_to_ques.cat_id=category.catid left JOIN ques_for_questionbank ON ans_to_ques.ques_id=ques_for_questionbank.ques_id left JOIN language ON ques_for_questionbank.lang_id=language.lang_id left JOIN word ON ans_to_ques.card_id=word.card_id LEFT JOIN theme_master ON ans_to_ques.theme_id=theme_master.theme_id  WHERE ans_to_ques.deck_id ='"+questions[questionindex].deck_id+"' AND ans_to_ques.quesb_id='"+questions[questionindex].ques_bank_id+"' AND ans_to_ques.ques_id='"+questions[questionindex].ques_id+"'   AND ans_to_ques.status='A' group BY ans_to_ques.card_id";
           connection.query(query3,function(err,cardslist,fields){
              if(err){
      console.log(err.message);
    }
    else if(cardslist){

      async.forEachOf(cardslist,function (data2, cardindex ,cardnext) {
        // console.log("cardslist",cardslist[cardindex].card_id);
        cardslist[cardindex]['img_url']=imgURL+cardslist[cardindex]['img_url'];
        var query4="SELECT ans_to_ques.card_id,ans_to_ques.cat_id,ans_to_ques.card_score as cat_score,category.category_name FROM ans_to_ques left JOIN theme_master  ON ans_to_ques.theme_id=theme_master.theme_id left JOIN category ON ans_to_ques.cat_id=category.catid  where ans_to_ques.card_id='"+cardslist[cardindex].card_id+"' GROUP by cat_id";
        connection.query(query4,function(err,categorylist,fields){
              if(err){
      console.log(err.message);
                    }
              else if(categorylist){
                cardslist[cardindex].category=categorylist;
                cardnext();
              }
          })

      },function(err){
        var json={
          "question":questions[questionindex].question,
          "quesid":questions[questionindex].ques_id,
          "cards":cardslist
        };
        if(cardslist.length>0){
          questionsarrjson.push(json);
        }
        
      // questions[questionindex].cards=cardslist;
      questionnext(null);
      })




    }

  })


         },function(err){

           var json={
          "questionbankname":quesbank[qbindex].ques_bank,
          "questionbankid":quesbank[qbindex].quesb_id,
          "deck_id":quesbank[qbindex].deck_id,
          "gamemode":quesbank[qbindex].gamemode,
          "game_typeid":quesbank[qbindex].gametype_id,
          "lang_id":quesbank[qbindex].Language,
          "theme_id":quesbank[qbindex].theme_id,
          "questions":questionsarrjson
      };
      if(questionsarrjson.length>0){
        quesbankarray.push(json);
      }
      next(null);

         })
            // questionset.push(questions); 
     
    }
  })

      },function(err){
       
        res.send(quesbankarray);
})
    }
  })
})

app.post("/insert_hist_survey",urlencodedParser,function(req,res){
  var surveyArray=req.body;
      var query="insert into survey_history(gamemode,game_id,uniqueid ,playerid, quesbank_id,ques_id, cardid,date_time)values('"+surveyArray.gamemode+"','"+surveyArray.game_id+"','"+surveyArray.uniqueid+"','"+surveyArray.player_id+"','"+surveyArray.quesbank_id+"','"+surveyArray.ques_id+"','"+surveyArray.ans_cardid1+"',now())";
  console.log(query);

  connection.query(query,function(err,rows,fields){
     if(err){
      console.log(err.message);
     }
     else{
      res.send("Inserted");
     }
  }) 
})

app.get("/disp_all_cards/",function(req,res){

  var query="SELECT * FROM ans_to_ques";
  connection.query(query,function(err,rows,fields){
  if(err){
    console.log(err.message);
  }
  async.forEachOf(rows,function (data, index ,next) {
    var query="SELECT category.*,ans_to_ques.* FROM `ans_to_ques` LEFT JOIN category ON category.catid=ans_to_ques.cat_id where ans_id="+rows[index].ans_id;
    connection.query(query,function(err,scores,fields){
      rows[index].scoredata=scores;
      next();
    })
    },function(err){
      res.send(rows);
    })
})
  })



// New API for game Creation in Webadmin and keyword gc as prefix in every api


app.get("/gc_questiondropdwn/:quesbankid/:deckid/:gamemode/:langid/:gametype",function(req,res){
  
var query = "SELECT * FROM `ques_for_questionbank` WHERE ques_for_questionbank.ques_bank_id='"+req.params.quesbankid+"' AND ques_for_questionbank.deck_id='"+req.params.deckid+"' AND ques_for_questionbank.gamemode='"+req.params.gamemode+"' AND ques_for_questionbank.lang_id='"+req.params.langid+"' AND ques_for_questionbank.game_typeid='"+req.params.gametype+"' AND ques_for_questionbank.status='A'";
connection.query(query,function(err,rows,fields){
  if(err){
    console.log(err.message);
  }else{
    res.send(JSON.stringify(rows));
  }
})
})


// NEW API TO GET GAME

app.get("/getgamesetting/:gameid",function(req,res){
  
var query = "SELECT * FROM game_master WHERE game_id = "+req.params.gameid+"";
connection.query(query,function(err,rows,fields){
  if(err){
    console.log(err.message);
  }else{
    res.send(JSON.stringify(rows));
  }
})
})

// new benchmark

// INSERT INTO `benchmark_master` (`benchmarkid`, `game_mode`, `game_id`, `cat_id`, `bench_mark`, `color`, `status`, `created_date`, `createdby`) VALUES (NULL, '0', '23', '2', '300', '#FF23', 'A', '2017-11-20', 'admin')


// insert benchmark

// app.post("/insert_benchmark",urlencodedParser,function(req,res){
//   var query1 = "select * from benchmark where  game_mode = '"+req.body.game_mode+"' and game_id = "+req.body.game_id+" and cat_id = '"+req.body.cat_id+"' ";
//   console.log(query1);
//   connection.query(query1,function(err,rows,fields){
//     if(err){
//       console.log(err.message)
//     }
//     else if(rows.length>0){
//       res.send("Already Exists")
//     }
//     else
//     {
//       var query="insert into benchmark( game_mode ,game_id, cat_id,bench_mark,color, status, created_date, createdby)values('"+req.body.game_mode+"','"+req.body.game_id+"','"+req.body.cat_id+"','"+req.body.bench_mark+"','"+req.body.color+"','A' ,now(),'"+req.body.createdby+"')";
//   console.log(query);

//   connection.query(query,function(err,rows,fields){
//      if(err){
//       console.log(err.message);
//      }
//      else{
//       res.send("Inserted");
//      }
//   })
//     }
//   })
  
// })


app.post("/insert_benchmarknew",urlencodedParser,function(req,res){
      var query="insert into benchmark_master( game_mode ,game_id, cat_id,bench_mark,color,benchmark_title,status, created_date, createdby)VALUES ?";
  console.log(query);

   var values=[];
 var date = new Date();
var newdate=new Date();
    for(i=0;i<req.body.length;i++)
    {
     
      values.push([req.body[i].game_mode, req.body[i].game_id,req.body[i].cat_id,req.body[i].bench_mark,req.body[i].color,req.body[i].benchmark_title,'A',date,req.body[i].createdby]);
    }
console.log(values);
connection.query(query, [values], function(err) {
    if (err) 
      throw err;
    else
    {
      res.send("Inserted");
    }
});
  
})

// update
// app.post("/upd_benchmarkmaster",urlencodedParser,function(req,res){
  
// var queries='';
// // console.log(values);
// console.log('req.body[0].benchmark_title',req.body[0].benchmark_title);
// var statusofupdate="";
// var select_query="select * from benchmark_master where benchmark_title='"+req.body[0].benchmark_title+"'";
// var query="insert into benchmark_master( game_mode ,game_id, cat_id,bench_mark,color,benchmark_title,status, created_date, createdby)VALUES ?";
// connection.query(select_query,function(err,rows,fields){
//   if(err){
//     console.log(err.message);
//   }else if(rows.length>0){
//     var values=req.body;
//     statusofupdate='true';
//     console.log(values);
//     values.forEach(function(item){
//   console.log(item);
//   queries+= mysql.format("UPDATE benchmark_master SET bench_mark="+item.benchscore+",color='"+item.color+"',benchmark_title='"+item.benchmark_title+"' WHERE game_mode="+item.game_mode+" and game_id="+item.game_id+" and cat_id="+item.catid+";");
// //   queries +='UPDATE benchmark_master SET bench_mark='+item.benchscore+',color="'+item.color+'" WHERE game_mode='+item.game_mode+' and game_id='+item.game_id+' and cat_id='+item.catid+';';
// })
// }else{
//     statusofupdate='false';
    
//   }
//    console.log(statusofupdate);
//   if(statusofupdate == 'true'){ 
//     connection.query(queries,function(err,rows1,fields){
//       console.log(queries);
//       if (err) 
//       {
//         console.log(err.message);
//       }
      
//       else if(rows1.length>0)
//       {
//         console.log(rows1);
//         res.send("Updated");
//       }
//       else{
//         console.log(rows1);
//         res.send(JSON.stringify("Update already done"));
//       }
//   });
//   }else{
//   var values=[];
//  var date = new Date();
// var newdate=new Date();
//     for(i=0;i<req.body.length;i++)
//     {
     
//       values.push([req.body[i].game_mode, req.body[i].game_id,req.body[i].catid,req.body[i].benchscore,req.body[i].color,req.body[i].benchmark_title,'A',date,req.body[i].createdby]);
//     }
//     connection.query(query, [values], function(err) {
//     if (err) 
//       throw err;
//     else
//     {
//       res.send("Inserted");
//     }
// });
//   }
// })


//   // res.send(queries);


  
  
// })



// update

app.post("/upd_benchmarkmaster",urlencodedParser,function(req,res){
  var values=req.body;
var queries='';
var newdate=new Date();
console.log(values);
for(var i in values){
  if(!values[i].benchmarkid){
    queries+="insert into benchmark_master( game_mode, deckid ,game_id, cat_id,bench_mark,color,benchmark_title,status, created_date, createdby)values("+values[i].game_mode+","+values[i].deckid+","+values[i].game_id+","+values[i].catid+",'"+values[i].benchscore+"','"+values[i].color+"','"+values[i].benchmark_title+"','A','"+newdate+"','"+values[i].createdby+"');"
  }else{
    queries+="update benchmark_master set bench_mark='"+values[i].benchscore+"',color='"+values[i].color+"',benchmark_title='"+values[i].benchmark_title+"' where benchmarkid="+values[i].benchmarkid+";";
  }
}
//     var deleteequery="delete from benchmark_master where deckid="+req.body[0].deckid+" and game_id="+req.body[0].game_id+" and game_mode="+req.body[0].game_mode+" and benchmark_title='"+req.body[0].benchmark_title+"";
//     console.log(deleteequery);
//     connection.query(deleteequery,function(err,rows,fields){
//       if(err){
//         console.log(err.message)
//       }else{
//  var valuesArrray=[];
// var query="insert into benchmark_master( game_mode, deckid ,game_id, cat_id,bench_mark,color,benchmark_title,status, created_date, createdby)VALUES ?";
// var date = new Date();
// var newdate=new Date();
//     for(i=0;i<req.body.length;i++)
//     {
     
//       valuesArrray.push([req.body[i].game_mode,req.body[i].deckid, req.body[i].game_id,req.body[i].catid,req.body[i].benchscore,req.body[i].color,req.body[i].benchmark_title,'A',date,req.body[i].createdby]);
    
//     }
    connection.query(queries,function(err,rows,response1){
if(err){
  console.log(err.message);
}else{
  res.send("Updated")
}
    })
//       }
//     })
})


// display

// select ans_to_ques.ans_id, ans_to_ques.game_id as ansgameid, ans_to_ques.quesb_id as ansquesb, ans_to_ques.deck_id as ansdeckid, ans_to_ques.ques_id as ansques, ans_to_ques.card_id as anscardid, ans_to_ques.cat_id, ans_to_ques.card_score,ans_to_ques.cardadded,ans_to_ques.theme_id,ans_to_ques.status as ansstatus FROM ans_to_ques


// SELECT ques_to_card.lang_id FROM `ans_to_ques` LEFT JOIN ques_to_card ON ques_to_card.deck_id = ans_to_ques.deck_id AND ques_to_card.gametype_id = ans_to_ques.game_id AND ques_to_card.quesbank_id = ans_to_ques.quesb_id and ques_to_card.quesid = ans_to_ques.ques_id LIMIT 1

app.get("/disp_creategame",function(req,res){
  var qry="select game_master.keyword,ans_to_ques.gamestatus, ans_to_ques.ans_id,ans_to_ques.gameOrder as gameOrder, ans_to_ques.game_id as ansgameid, ans_to_ques.quesb_id as ansquesb, ans_to_ques.deck_id as ansdeckid, ans_to_ques.ques_id as ansques, ans_to_ques.card_id as anscardid, ans_to_ques.cat_id, ans_to_ques.card_score,ans_to_ques.cardadded,ans_to_ques.theme_id,ans_to_ques.status as ansstatus,deck.deck_theme ,game_master.game_name,game_master.gamemode FROM ans_to_ques LEFT JOIN game_master ON game_master.game_id = ans_to_ques.game_id LEFT JOIN deck ON deck.DeckID = ans_to_ques.deck_id GROUP BY ans_to_ques.game_id,deck.DeckID"  ;
  connection.query(qry,function(err,rows,fields){
    if(err){
      console.log(err.message);
    }
    async.forEachOf(rows,function (data, index ,next) {

      var countqry="SELECT benchmark_master.benchmarkid,benchmark_master.game_mode as bengamemode, benchmark_master.game_id as bengameid , benchmark_master.cat_id as bencatid , benchmark_master.bench_mark ,benchmark_master.status as benstatus, benchmark_master.color FROM benchmark_master WHERE benchmark_master.game_id='"+rows[index].ansgameid+"' AND benchmark_master.cat_id='"+rows[index].cat_id+"'"  ;
  connection.query(countqry,function(err,countrows,fields){
    console.log(countqry);
rows[index].benchmark=countrows;
console.log(rows[index].benchmark);
next(null);
  })
      },function(err){
res.send(rows);
      })
  });
})

// SELECT * FROM instruction WHERE deckid = 8 and gamemode = 0 and gametype= 23

app.get("/getinstruction/:deckid/:gamemode/:gametype",function(req,res){
  
var query = "SELECT * FROM instruction WHERE deckid = "+req.params.deckid+" and gamemode = "+req.params.gamemode+" and gametype= "+req.params.gametype+"";
connection.query(query,function(err,rows,fields){
  if(err){
    console.log(err.message);
  }else{
    res.send(JSON.stringify(rows));
  }
})
})

// dispinstruction

app.get("/getinstruction/:deck_id/:gametype_id/:gamemode/:quesbank_id/:quesid",function(req,res){
  
var query = "SELECT * FROM ques_to_card where deck_id = "+req.params.deck_id+" and gametype_id = "+req.params.gametype_id+" and gamemode = "+req.params.gamemode+" and quesbank_id = "+req.params.quesbank_id+" and quesid = "+req.params.quesid+" ";
connection.query(query,function(err,rows,fields){
  if(err){
    console.log(err.message);
  }else{
    res.send(JSON.stringify(rows));
  }
})
})

// dispbench
// benchmark_master.benchmarkid,benchmark_master.game_mode as bengamemode, benchmark_master.game_id as bengameid , benchmark_master.cat_id as bencatid , benchmark_master.bench_mark ,benchmark_master.status as benstatus, benchmark_master.color





// webadmin benchmark disp

app.get("/getbenchmark/:game_mode/:game_id/:deck_id",function(req,res){
  
var query = "SELECT benchmark_master.*,cattheme.category FROM benchmark_master inner join cattheme ON cattheme.cattheme_id = benchmark_master.cat_id and cattheme.status='A' and cattheme.deck_id="+req.params.deck_id+" WHERE benchmark_master.game_mode="+req.params.game_mode+" AND benchmark_master.game_id="+req.params.game_id+" ";
connection.query(query,function(err,rows,fields){
  if(err){
    console.log(err.message);
  }else{

    res.send(JSON.stringify(rows));
  }
})
})


// benchmark by id
// SELECT * FROM benchmark_master WHERE benchmark_master.game_id = 22 and benchmark_master.benchmark_title = "Average"

app.get("/getmultibenchmarkedit/:game_id/:benchmark_title/:deckid",function(req,res){
  
var query = "SELECT * FROM benchmark_master WHERE benchmark_master.game_id= "+req.params.game_id+" and benchmark_master.benchmark_title = '"+ req.params.benchmark_title+"'and benchmark_master.deckid="+req.params.deckid+"";
connection.query(query,function(err,rows,fields){
  if(err){
    console.log(err.message);
  }else{
    res.send(JSON.stringify(rows));
  }
})
})

// Multi benchmark Display
// SELECT * FROM `benchmark_master` where game_id=22 group BY benchmark_master.benchmark_title

app.get("/getmultibenchmark/:game_id/:deckid",function(req,res){
  
var query = "SELECT benchmark_master.*, game_master.game_name,game_master.gamemode FROM `benchmark_master` LEFT JOIN game_master ON benchmark_master.game_id = game_master.game_id where benchmark_master.game_id="+req.params.game_id+" and  benchmark_master.deckid="+req.params.deckid+" group BY benchmark_master.benchmark_title";
connection.query(query,function(err,rows,fields){
  if(err){
    console.log(err.message);
  }else{
    res.send(JSON.stringify(rows));
  }
})
})



app.get("/dispsettings/:deck_id/:lang_id",function(req,res){
  
var query = "SELECT * FROM settings where deck_id = "+req.params.deck_id+" and lang_id= "+req.params.lang_id+"";
connection.query(query,function(err,rows,fields){
  if(err){
    console.log(err.message);
  }else{
    res.send(JSON.stringify(rows));
  }
})
})

// new update api

app.post('/update_settings_detail/',urlencodedParser,function(req,res){

  var update_query="update settings set deck_id='"+req.body.deck_id+"',lang_id='"+req.body.lang_id+"',backgroundmusic='"+req.body.backgroundmusic+"',changeorder='"+req.body.changeorder+"',image_url='"+req.body.image_url+"'where Settingid="+req.body.Settingid+"";
  connection.query(update_query,function(err,rows,fields){
    console.log(update_query);
    if(err){
      console.log(err.message);
    }
    else{
      res.send("Updated");
    }
  })
})



// insturction

app.get("/insetructiondispnew/:deckid/:gamemode/:gametype",function(req,res){

  // SELECT instruction.*, game_master.game_name FROM `instruction` LEFT JOIN game_master ON game_master.game_id = instruction.gametype
  
var query = "SELECT instruction.*, game_master.game_name,deck.deck_theme FROM instruction LEFT JOIN game_master ON game_master.game_id = instruction.gametype  LEFT JOIN deck ON deck.DeckID = instruction.deckid WHERE instruction.deckid = "+req.params.deckid+" and instruction.gamemode= "+req.params.gamemode+" and instruction.gametype = "+req.params.gametype+"";
connection.query(query,function(err,rows,fields){
  console.log(query);
  if(err){
    console.log(err.message);
  }else{
    res.send(JSON.stringify(rows));
  }
})
})

// new instruction update

// app.post('/update_instruction',urlencodedParser,function(req,res){
//   var update_query="update instruction set instruction.deckid='"+req.body.upd_deckid+"',instruction.lang_id='"+req.body.upd_lang_id+"',instruction.gamemode='"+req.body.upd_gamemode+"',instruction.gametype='"+req.body.upd_gametype+"',instruction.instruction='"+req.body.upd_instruction+"',instruction.Status='A',instruction.videolink='"+req.body.uvideolink+"' where instruction.instruction_id="+req.body.instruction_id+"";
//   console.log(update_query);
//   connection.query(update_query,function(err,rows,fields){
//     if(err){
//       console.log(err.message);
//     }
//     else{
//       res.send("Updated");
//     }
//   })
// })

// "+req.params.gametype+"
// select ans_to_ques.ans_id, ans_to_ques.game_id as ansgameid, ans_to_ques.quesb_id as ansquesb, ans_to_ques.deck_id as ansdeckid, ans_to_ques.ques_id as ansques, ans_to_ques.card_id as anscardid, ans_to_ques.cat_id, ans_to_ques.card_score,ans_to_ques.cardadded,ans_to_ques.theme_id,ans_to_ques.status as ansstatus,deck.deck_theme ,game_master.game_name,game_master.gamemode FROM ans_to_ques LEFT JOIN game_master ON game_master.game_id = ans_to_ques.game_id LEFT JOIN deck ON deck.DeckID = ans_to_ques.deck_id where ans_to_ques.game_id = 23 AND quesb_id = 32 AND deck_id = 8 AND ques_id = 33 AND theme_id = 1

app.get("/showanstoques/:game_id/:quesb_id/:deck_id/:ques_id/:theme_id",function(req,res){
  
var query = "select ans_to_ques.ans_id, ans_to_ques.game_id as ansgameid, ans_to_ques.quesb_id as ansquesb, ans_to_ques.deck_id as ansdeckid, ans_to_ques.ques_id as ansques, ans_to_ques.card_id as anscardid, ans_to_ques.cat_id, ans_to_ques.card_score,ans_to_ques.cardadded,ans_to_ques.theme_id,ans_to_ques.status as ansstatus,deck.deck_theme ,game_master.game_name,game_master.gamemode FROM ans_to_ques LEFT JOIN game_master ON game_master.game_id = ans_to_ques.game_id LEFT JOIN deck ON deck.DeckID = ans_to_ques.deck_id where ans_to_ques.game_id = "+req.params.game_id+" AND quesb_id = "+req.params.quesb_id+" AND deck_id = "+req.params.deck_id+" AND ques_id = "+req.params.ques_id+" AND theme_id = "+req.params.theme_id+"";
connection.query(query,function(err,rows,fields){
  console.log(query);
  if(err){
    console.log(err.message);
  }else{
    res.send(JSON.stringify(rows));
  }
})
})

// SELECT * FROM directionscore WHERE directionscore.quesbankid = 32 AND directionscore.quesid=33 AND directionscore.gamemode=0 AND directionscore.gametype=22 AND directionscore.deckid=8 AND cardid = 4


app.get("/showdirection/:quesbankid/:quesid/:gamemode/:gametype/:deckid/:cardid",function(req,res){
  
var query = "SELECT * FROM directionscore WHERE directionscore.quesbankid = "+req.params.quesbankid+" AND directionscore.quesid="+req.params.quesid+" AND directionscore.gamemode="+req.params.gamemode+" AND directionscore.gametype="+req.params.gametype+" AND directionscore.deckid="+req.params.deckid+" AND cardid = "+req.params.cardid+"";
connection.query(query,function(err,rows,fields){
  console.log(query);
  if(err){
    console.log(err.message);
  }else{
    res.send(JSON.stringify(rows));
  }
})
})


app.post('/update_directionscore',urlencodedParser,function(req,res){
  if(req.body.newrecord=='false'){
  var update_query="update directionscore set deckid="+req.body.deckid+",cardid="+req.body.cardid+",quesbankid="+req.body.quesbankid+",quesid="+req.body.quesid+",gamemode="+req.body.gamemode+",gametype="+req.body.gametype+",direction_leftscore="+req.body.direction_leftscore+",direction_rightscore="+req.body.direction_rightscore+",direction_upscore="+req.body.direction_upscore+",direction_downscore="+req.body.direction_downscore+" where direction_id="+req.body.direction_id+"";
}else{
  var update_query="INSERT INTO directionscore(directionscore.deckid,directionscore.quesbankid,directionscore.gamemode,directionscore.gametype,directionscore.direction_leftscore,directionscore.direction_rightscore,directionscore.direction_upscore,directionscore.direction_downscore,directionscore.theme_id,directionscore.cardid,directionscore.quesid) values("+req.body.deckid+","+req.body.quesbankid+","+req.body.gamemode+","+req.body.gametype+","+req.body.direction_leftscore+","+req.body.direction_rightscore+","+req.body.direction_upscore+","+req.body.direction_downscore+","+req.body.themeid+","+req.body.cardid+","+req.body.quesid+")"
}
  console.log("quersies",update_query);
  connection.query(update_query,function(err,rows,fields){
    if(err){
      console.log(err.message);
    }
    else{
      res.send("Updated");
    }
  })
})
// update anstoques

app.post('/check_duplicate_ans_to_ques/',urlencodedParser,function(req,res){
  // var values=req.body;
  var duplicate_sql="select * from ans_to_ques where ans_to_ques.game_id='"+req.body.game_id+"' AND ans_to_ques.quesb_id='"+req.body.quesbank_id+"' AND ans_to_ques.ques_id='"+req.body.ques_id+"' AND ans_to_ques.deck_id='"+req.body.deck_id+"' AND ans_to_ques.card_id='"+req.body.card_id+"' AND ans_to_ques.cat_id='"+req.body.cat_id+"' ";

connection.query(duplicate_sql,function(err,rows,fields){
console.log(duplicate_sql);
  if(err){
    console.log(err.message);
  }
  else if(rows.length>0){

res.send("exists");
  }
  else{
    res.send("notexists");
  }

})
})


// dispalycategory

// select * from ans_to_ques where ans_to_ques.game_id=31 AND ans_to_ques.quesb_id=32 AND ans_to_ques.ques_id=40 AND ans_to_ques.deck_id=8 AND ans_to_ques.card_id=7


app.post('/diplaycatregoryforcard/',urlencodedParser,function(req,res){
  // var values=req.body;
  var duplicate_sql="select * from ans_to_ques where ans_to_ques.game_id='"+req.body.game_id+"' AND ans_to_ques.quesb_id='"+req.body.quesbank_id+"' AND ans_to_ques.ques_id='"+req.body.ques_id+"' AND ans_to_ques.deck_id='"+req.body.deck_id+"' AND ans_to_ques.card_id='"+req.body.card_id+"'  ";

connection.query(duplicate_sql,function(err,rows,fields){
console.log(duplicate_sql);
  if(err){
    console.log(err.message);
  }
  else if(rows.length>0){

res.send(JSON.stringify(rows));
  }
  else{
    res.send("notexists");
  }

})
})


app.get("/available_order/:gamemode/:gameid/:deck_id",function(req,res){

   var query="select * from ans_to_ques where ans_to_ques.GameMode="+req.params.gamemode+" and ans_to_ques.deck_id="+req.params.deck_id+" group by ans_to_ques.gameOrder";
   var arrayOrders=[1,2,3,4,5,6];
   console.log(query);
   connection.query(query,function(err,rows,fields){
    if(err){
      console.log(err.message);
    }
    else{
      // arrayOrders=arrayOrders;
      for(j=rows.length-1;j>=0;j--){

        for(k=0;k<arrayOrders.length;k++){
        if(rows[j].gameOrder==arrayOrders[k]){
          arrayOrders.splice(k,1);
        }
        }
        if(req.params.gameid!=0){
          // console.log(rows[j].game_id +"=="+req.params.gameid)
            if(rows[j].game_id==req.params.gameid){
              arrayOrders.push(rows[j].gameOrder);
            }
        }
    
      }
      res.send(JSON.stringify(arrayOrders));
    }

   })
})
app.post("/update_createGameStatus",urlencodedParser,function(req,res){
  var query="update ans_to_ques SET ans_to_ques.gameOrder='"+req.body.gameOrder+"',ans_to_ques.GameMode="+req.body.editgamemode+",ans_to_ques.gamestatus='"+req.body.gameStatus+"' where ans_to_ques.deck_id="+req.body.editdeck+" and ans_to_ques.game_id="+req.body.editgametype+"";
  console.log(query);
  connection.query(query,function(err,rows,fields){
    if(err){
      console.log(err.message);
    }
    else{
      res.send("updated");
    }
  })

})
app.post("/upd_ans_to_ques",urlencodedParser,function(req,res){
    var values=req.body;
var queries = '';
console.log("upd_to_ques",values);
values.forEach(function(item){
  // queries += mysql.format("UPDATE tabletest SET users = ? WHERE id = ?; ", item);
 queries +="UPDATE ans_to_ques SET ans_to_ques.cat_id='"+item.cat_id+"',ans_to_ques.card_score='"+item.card_score+"' WHERE ans_to_ques.ans_id="+item.answerID+";";

});
  console.log(queries);

connection.query(queries,function(err,rows){
    if (err)
      throw err;
    else if(rows.length>0)
    {
      console.log(rows);
      res.send("Inserted");
    }


})
})
 







// update Direction


// DELETE FROM `ans_to_ques` WHERE `ans_to_ques`.`ans_id` = 1"?
// delete card

app.get("/delete_role/:card_id/:game_id/:deck_id/:quesb_id/:ques_id",function(req,res){
  
  
  var delete_query="DELETE FROM ans_to_ques  where card_id="+req.params.card_id+" AND game_id="+req.params.game_id+" AND deck_id="+req.params.deck_id+" AND quesb_id="+req.params.quesb_id+" AND ques_id="+req.params.ques_id+" ";
  connection.query(delete_query,function(err,rows,fields){
    if(err){
      console.log(err.message);
    }
    else{
      res.send("Deleted");
    }
  })
})


// prioriry insertion





// insert benchmark

app.post("/insert_priopritygame",urlencodedParser,function(req,res){
  var query1 = "select * from ans_to_ques where  deck_id = '"+req.body.deckid+"' and game_id = "+req.body.typeid+" and quesb_id = '"+req.body.quesbankid+"'  and ques_id = '"+req.body.quesid+"' and card_id = '"+req.body.cardid+"' and gameOrder='"+req.body.gameOrder+"' and GameMode="+req.body.gamemode+"";
  console.log(query1);
  connection.query(query1,function(err,rows,fields){
    if(err){
      console.log(err.message)
    }
    else if(rows.length>0){
      res.send("Already Exists")
    }
    else
    {
      var query="INSERT INTO ans_to_ques (ans_to_ques.card_id,ans_to_ques.deck_id,ans_to_ques.quesb_id,ans_to_ques.ques_id,ans_to_ques.game_id,ans_to_ques.cat_id,ans_to_ques.card_score,ans_to_ques.cardadded,ans_to_ques.status,ans_to_ques.createdby,ans_to_ques.createddate,theme_id,gameOrder, ans_to_ques.gamestatus)values('"+req.body.cardid+"','"+req.body.deckid+"','"+req.body.quesbankid+"','"+req.body.quesid+"','"+req.body.typeid+"','"+req.body.catid+"','"+req.body.catscore+"','yes','"+req.body.status+"','admin','now()','"+req.body.themeid+"','"+req.body.gameOrder+"','"+req.body.gamestatus+"')";
  console.log(query);

  connection.query(query,function(err,rows,fields){
     if(err){
      console.log(err.message);
     }
     else{
      res.send("Inserted");
     }
  })
    }
  })
  
})

// new api for group memeber display


app.get("/group_member/:grp_id",function(req,res){
  // var query="SELECT *,answer.answer,questions.question FROM players LEFT JOIN answer ON players.player_id=answer.playerid LEFT JOIN questions ON answer.questionid=questions.quesid";
var query="SELECT playergroupdetails.*, player_group.grp_name, players.name FROM `playergroupdetails` LEFT JOIN player_group ON player_group.grp_id = playergroupdetails.grp_id LEFT JOIN players ON players.player_id = playergroupdetails.player_id where playergroupdetails.grp_id = '"+req.params.grp_id+"' ";
  connection.query(query,function(err,rows,fields){
    if(err){
      console.log(err.message);
    }
    else {
      res.send(JSON.stringify(rows));
    }
  });
})

// new api for single player history 


app.get("/sinplayerhistoryid/:game_id/:fromdate/:todate",function(req,res){
  // var query="SELECT *,answer.answer,questions.question FROM players LEFT JOIN answer ON players.player_id=answer.playerid LEFT JOIN questions ON answer.questionid=questions.quesid";
var query="SELECT scenario_history.*, game_master.gamemode,game_master.game_name,players.name,ques_for_questionbank.question ,question_bank.ques_bank,player_group.grp_name FROM scenario_history LEFT JOIN game_master ON scenario_history.game_id = game_master.game_id LEFT JOIN players ON scenario_history.player_id = players.player_id LEFT JOIN ques_for_questionbank ON scenario_history.ques_id = ques_for_questionbank.ques_id LEFT JOIN question_bank ON scenario_history.quesbank_id = question_bank.quesb_id LEFT JOIN player_group ON scenario_history.grp_id=player_group.grp_id WHERE scenario_history.game_id = '"+req.params.game_id+"' and scenario_history.date_time BETWEEN '"+req.params.fromdate+"' and '"+req.params.todate+"'ORDER BY his_id DESC  ";
  connection.query(query,function(err,rows,fields){
    if(err){
      console.log(err.message);
    }
    else {
      res.send(JSON.stringify(rows));
    }
  });
})

// single player history for selfi and timeline

// SELECT selfi_history.*, card.card_name,card.img_url, game_master.game_name,game_master.gamemode ,players.name,question_bank.ques_bank ,ques_for_questionbank.question ,player_group.grp_name FROM selfi_history LEFT JOIN game_master on selfi_history.game_id = game_master.game_id LEFT JOIN card ON selfi_history.card_id = card.card_id LEFT JOIN players ON selfi_history.player_id = players.player_id LEFT JOIN question_bank on selfi_history.quesbank_id = question_bank.quesb_id LEFT JOIN ques_for_questionbank ON selfi_history.question_id = ques_for_questionbank.ques_id LEFT JOIN player_group on selfi_history.grp_id =player_group.grp_id  WHERE selfi_history.game_id ='"+req.params.game_id+"' ORDER BY his_id DESC limit 100 

// SELECT selfi_history.*, card.card_name,card.img_url, game_master.game_name,game_master.gamemode ,players.name,question_bank.ques_bank ,ques_for_questionbank.question ,player_group.grp_name FROM selfi_history LEFT JOIN game_master on selfi_history.game_id = game_master.game_id LEFT JOIN card ON selfi_history.card_id = card.card_id LEFT JOIN players ON selfi_history.player_id = players.player_id LEFT JOIN question_bank on selfi_history.quesbank_id = question_bank.quesb_id LEFT JOIN ques_for_questionbank ON selfi_history.question_id = ques_for_questionbank.ques_id LEFT JOIN player_group on selfi_history.grp_id =player_group.grp_id  WHERE selfi_history.game_id =23 and selfi_history.date BETWEEN '2018-02-28 13:33:38' AND '2018-02-28 13:34:48' ORDER BY his_id DESC

app.get("/historyselfitimeline/:game_id/:fromdate/:todate",function(req,res){

var query="  SELECT selfi_history.*, card.card_name,card.img_url, game_master.game_name,game_master.gamemode ,players.name,question_bank.ques_bank ,ques_for_questionbank.question ,player_group.grp_name FROM selfi_history LEFT JOIN game_master on selfi_history.game_id = game_master.game_id LEFT JOIN card ON selfi_history.card_id = card.card_id LEFT JOIN players ON selfi_history.player_id = players.player_id LEFT JOIN question_bank on selfi_history.quesbank_id = question_bank.quesb_id LEFT JOIN ques_for_questionbank ON selfi_history.question_id = ques_for_questionbank.ques_id LEFT JOIN player_group on selfi_history.grp_id =player_group.grp_id  WHERE selfi_history.game_id ='"+req.params.game_id+"' and selfi_history.date BETWEEN '"+req.params.fromdate+"' AND '"+req.params.todate+"' ORDER BY his_id DESC ";
  connection.query(query,function(err,rows,fields){
    if(err){
      console.log(err.message);
    }
    else {
      res.send(JSON.stringify(rows));
    }
  });
})


app.get("/multiplayerhistoryP/:game_id",function(req,res){
  var query="SELECT selfi_history.*,curretnplayerid.player_id as player_id,curretnplayerid.name as currentPlayer,attendedID.name as attendedName, card.card_name,card.img_url, game_master.game_name,game_master.gamemode ,question_bank.ques_bank ,ques_for_questionbank.question ,player_group.grp_name FROM selfi_history LEFT JOIN game_master on selfi_history.game_id = game_master.game_id LEFT JOIN card ON selfi_history.card_id = card.card_id LEFT JOIN players as curretnplayerid ON selfi_history.player_id = curretnplayerid.player_id LEFT JOIN players as attendedID ON selfi_history.attendID = attendedID.player_id LEFT JOIN question_bank on selfi_history.quesbank_id = question_bank.quesb_id LEFT JOIN ques_for_questionbank ON selfi_history.question_id = ques_for_questionbank.ques_id LEFT JOIN player_group on selfi_history.grp_id =player_group.grp_id WHERE selfi_history.game_id ="+req.params.game_id+"   ORDER BY his_id DESC";
  connection.query(query,function(err,rows,fields){
    if(err){
      console.log(err.message);
    }else if(rows.length>0){
      var groupByIDs={};
      var groupByques={};
 var groupByplayer = {};
  var groupedScore = {};
  var Outcome = [];
  var perceptionArray=[];
   async.forEachOf(rows,function (data, index ,next) {
 if(groupByIDs[rows[index].uniqueid] == undefined && rows[index].game_id==req.params.game_id){
          groupByIDs[rows[index].uniqueid]  = []; 
          var obj={id:rows[index].uniqueid,groupname:rows[index].grp_name,gamename:rows[index].game_name,dateOfPlayd:rows[index].date,players:[]};
            groupByplayer={};
            var playerobj={};
          async.forEachOf(rows,function (data, pindex ,nexplayer) {
            // groupByques={};
            if(obj.id==rows[pindex].uniqueid){
              if(groupByplayer[rows[pindex].player_id] == undefined ){
              // playerobj
                groupByplayer[rows[pindex].player_id]  = []; 
                 playerobj={histid:rows[pindex].his_id,uniqueid:rows[pindex].uniqueid,questionID:rows[pindex].question_id,CurrentPlayer:rows[pindex].currentPlayer,AttendedName:rows[pindex].attendedName,playerid:rows[pindex].player_id,questions:[]};
               async.forEachOf(rows,function (data, qindex ,nextques) {
                if(playerobj.uniqueid==rows[qindex].uniqueid && playerobj.playerid==rows[qindex].player_id){
                      rows[qindex].attendies=[];
                  if(groupByques[rows[qindex].question_id] == undefined ){
                    // if(playerobj.questions.length==0){
                      groupByques[rows[qindex].question_id]=[];
                rows[qindex].attendies.push(JSON.parse(JSON.stringify(rows[qindex])));
                  playerobj.questions.push(rows[qindex]);
                    }else{
                        if(playerobj.questions.length>0){
                  for(l=0;l<playerobj.questions.length;l++){
                          if(playerobj.questions[l].question_id==rows[qindex].question_id){
                            playerobj.questions[l].attendies.push(rows[qindex]);
                          }
                        }
                    }
                  }
                }else{
                  // if(playerobj.questions.length>0){
                  // for(l=0;l<playerobj.questions.length;l++){
                  //         if(playerobj.questions[l].question_id==rows[qindex].question_id){
                  //           playerobj.questions[l].attendies.push(rows[qindex]);
                  //         }
                  //       }
                      }
                
                

                nextques();
               },function(err){
                groupByques={};
                 obj.players.push(playerobj);

               })
              }
              
            }
nexplayer();

            
        },function(err){
          // nextques();
              // obj.players.push(playerobj);
          perceptionArray.push(obj);
        })
        }
        next();

   },function(err){
 console.log('perceptionArray',perceptionArray)
res.send(perceptionArray);
   })
//   for(var i = 0; i < rows.length; i++ ){ 

//     if(groupByIDs[rows[i].uniqueid] == undefined && rows[i].game_id==33){
//           groupByIDs[rows[i].uniqueid]  = []; 
// // perceptionArray.push({id:rows[i].uniqueid,groupname:rows[i].grp_name,gamename:rows[i].game_name,question:[]});
// var obj={id:rows[i].uniqueid,groupname:rows[i].grp_name,gamename:rows[i].game_name,question:[]};
//           // groupByIDs[rows[i].uniqueid].push(rows[i].uniqueid); 
//            for(var k = 0; k < rows.length; k++ ){   
//            if(rows[k].uniqueid==obj.id){ 
//           if(groupByques[rows[k].question_id] == undefined ){
//           groupByques[rows[k].question_id]  = []; 
//           obj.question.push({question_id:rows[k].card_id});
//           // groupByIDs[rows[i].uniqueid].push(rows[i].uniqueid);          
//       }else{

//          // obj.question.push({question_id:rows[i].question_id});
//       }    
//            }   
//      }
// perceptionArray.push(obj);
//     } 
//   }
// //   for(var k=0;k<rows.length;k++){
// if(groupByques[rows[i].question_id] == undefined && rows[i].game_id==33){
//           groupByques[rows[i].question_id]  = []; 
// perceptionArray.push({question_id:});
//           // groupByIDs[rows[i].uniqueid].push(rows[i].uniqueid);          
//     }
//   }

      // res.send(perceptionArray);
  
    }else{
      res.send(rows);
    }
  })

})


app.get('/MultiplayerCT-CP/:gameid',function(req,res){
  var query="SELECT scenario_history.*,curretnplayerid.name as currentname ,attendedID.name as attendedname, game_master.gamemode,game_master.game_name,players.name,ques_for_questionbank.question ,question_bank.ques_bank,player_group.grp_name FROM scenario_history LEFT JOIN game_master ON scenario_history.game_id = game_master.game_id LEFT JOIN players as curretnplayerid ON scenario_history.player_id = curretnplayerid.player_id LEFT JOIN players as attendedID ON scenario_history.attendID = attendedID.player_id LEFT JOIN players ON scenario_history.player_id = players.player_id LEFT JOIN ques_for_questionbank ON scenario_history.ques_id = ques_for_questionbank.ques_id LEFT JOIN question_bank ON scenario_history.quesbank_id = question_bank.quesb_id LEFT JOIN player_group ON scenario_history.grp_id=player_group.grp_id WHERE scenario_history.game_id ="+req.params.gameid+""
  connection.query(query,function(err,rows,fields){
    if(err){
      console.log(err.message);
    }else if(rows.length>0){
      // res.send(rows);
      async.forEachOf(rows,function (carddata, cardindex ,cardnext) {
        var cardquery="select * from card where card_id IN("+rows[cardindex].ans_cardid1+")";
        connection.query(cardquery,function(err,cardrows,fields){
          if(err){
            console.log(err.message);
          }else{

            rows[cardindex].cards=cardrows;
          }
          cardnext();
          // }else
        })
         },function(err){

      var groupByIDs={};
      var groupByques={};
 var groupByplayer = {};
  var groupedScore = {};
  var Outcome = [];
  var cparray=[];
   async.forEachOf(rows,function (data, index ,next) {
    if(groupByIDs[rows[index].uniqueid] == undefined && rows[index].game_id==req.params.gameid){
          groupByIDs[rows[index].uniqueid]  = []; 
          // var obj={id:rows[index].uniqueid,groupname:rows[index].grp_name,gamename:rows[index].game_name,dateOfPlayd:rows[index].date,players:[]};
          // cparray.push(obj);
             var obj={id:rows[index].uniqueid,groupname:rows[index].grp_name,gamename:rows[index].game_name,dateOfPlayd:rows[index].date,players:[],dateOfPlayd:rows[index].date_time};
            groupByplayer={};
            var playerobj={};
             async.forEachOf(rows,function (data, pindex ,nextplayer) {
            // groupByques={};
            if(obj.id==rows[pindex].uniqueid){
              if(groupByplayer[rows[pindex].player_id] == undefined ){
              // playerobj

                // groupByplayer[rows[pindex].player_id]  = []; 
                //  playerobj={histid:rows[pindex].his_id,uniqueid:rows[pindex].uniqueid,questionID:rows[pindex].question_id,CurrentPlayer:rows[pindex].currentPlayer,AttendedName:rows[pindex].attendedName,playerid:rows[pindex].player_id,questions:[]};
                //  obj.players.push(playerobj);
                groupByplayer[rows[pindex].player_id]  = []; 
                 playerobj={histid:rows[pindex].his_id,uniqueid:rows[pindex].uniqueid,questionID:rows[pindex].ques_id,CurrentPlayer:rows[pindex].currentPlayer,AttendedName:rows[pindex].attendedName,playerid:rows[pindex].player_id,questions:[]};
               async.forEachOf(rows,function (data, qindex ,nextques) {
                if(playerobj.uniqueid==rows[qindex].uniqueid && playerobj.playerid==rows[qindex].player_id){
                      rows[qindex].attendies=[];
                  if(groupByques[rows[qindex].ques_id] == undefined ){
                    // if(playerobj.questions.length==0){
                      groupByques[rows[qindex].ques_id]=[];
                rows[qindex].attendies.push(JSON.parse(JSON.stringify(rows[qindex])));
                  playerobj.questions.push(rows[qindex]);
                    }else{
                        if(playerobj.questions.length>0){
                  for(l=0;l<playerobj.questions.length;l++){
                          if(playerobj.questions[l].ques_id==rows[qindex].ques_id){
                            playerobj.questions[l].attendies.push(rows[qindex]);
                          }
                        }
                    }
                  }
                }else{
                  // if(playerobj.questions.length>0){
                  // for(l=0;l<playerobj.questions.length;l++){
                  //         if(playerobj.questions[l].question_id==rows[qindex].question_id){
                  //           playerobj.questions[l].attendies.push(rows[qindex]);
                  //         }
                  //       }
                      }
                
                

                nextques();
               },function(err){
                groupByques={};
                 obj.players.push(playerobj);

               })
                 }
                 }
                 nextplayer();
                 },function(err){
                  // groupByques={};
            cparray.push(obj);
                 })  
   }
   next();
 },function(err){
res.send(cparray);

})
 })
    }else{
res.send(rows);
    }
  })
})


app.get("/SharedPriorityHistory",function(req,res){
  var query="SELECT player_group.grp_name,players.name,players.img_url,sharedpriorityghistory.* FROM `sharedpriorityghistory` INNER JOIN players ON players.player_id=sharedpriorityghistory.playerid INNER JOIN player_group ON player_group.grp_id=sharedpriorityghistory.grp_id";
  var groupByIDs={};
 var groupByplayer = {};
 var sharedpriorityArray=[]
  connection.query(query,function(err,rows,fields){
    if(err){
      console.log(err.message);
    }else if(rows.length>0){
      // var sharedpriorityArray=[];
       async.forEachOf(rows,function (data, index ,next) {
      var querycard="select * from card where card_id IN ("+rows[index].cardid_priority1+","+rows[index].cardid_priority2+","+rows[index].cardid_priority3+","+rows[index].cardid_priority4+","+rows[index].cardid_priority5+")"
      connection.query(querycard,function(err,cardrows,fields){
        if(err){
          console.log(err.message);
        }else{
          rows[index].cards=cardrows;
        }
        next();
      })
       },function(err){
        // res.send(rows);
        async.forEachOf(rows,function (data, sindex ,snext) {

 if(groupByIDs[rows[sindex].game_session_id]==undefined){
  groupByIDs[rows[sindex].game_session_id]=[];
       var obj={id:rows[sindex].game_session_id,grpid:rows[sindex].grp_id,gameName:'Shared Priority',groupname:rows[sindex].grp_name,players:[],dateTime:rows[sindex].datetime}
// sharedpriorityArray.push(obj);
         // obj.players.push(rows[index]);
         async.forEachOf(rows,function (data, pindex ,pnext) {
         //  players
         if(obj.id==rows[pindex].game_session_id && obj.grpid==rows[pindex].grp_id){
         if(groupByplayer[rows[pindex].playerid]==undefined ){
          groupByplayer[rows[pindex].playerid]=[];
          obj.players.push(rows[pindex]);
         }
       }
         pnext();
         },function(err){
          groupByplayer={};
          sharedpriorityArray.push(obj);
         })

      }
      snext();

        },function(err){
          res.send(sharedpriorityArray);
        })
      //   groupByIDs={};
      //   sharedpriorityArray.push(obj);

      // res.send(sharedpriorityArray);
       })
    }
  })
})




// SELECT selfi_history.*, card.card_name,card.img_url, game_master.gamemode,game_master.game_name,players.name FROM selfi_history LEFT JOIN game_master ON game_master.game_id = selfi_history.game_id LEFT JOIN players ON players.player_id = selfi_history.player_id LEFT JOIN card ON card.card_id = selfi_history.card_id where selfi_history.game_id= 35

// bidding disphistory


app.get("/disp_biding/:game_id",function(req,res){
  var qry="SELECT selfi_history.*,player_group.grp_name, card.card_name,card.img_url, game_master.gamemode,game_master.game_name,players.name FROM selfi_history LEFT JOIN game_master ON game_master.game_id = selfi_history.game_id LEFT JOIN players ON players.player_id = selfi_history.player_id LEFT JOIN card ON card.card_id = selfi_history.card_id LEFT JOIN player_group on selfi_history.grp_id =player_group.grp_id where selfi_history.game_id='"+req.params.game_id+"' "  ;
  var groupbyid={};
  var groupbyCards={};
  var groupbyplayers={};
  var bidhistory=[];
  connection.query(qry,function(err,rows,fields){
    if(err){
      console.log(err.message);
    }
    async.forEachOf(rows,function (data, index ,next) {
if(groupbyid[rows[index].uniqueid]==undefined){
  groupbyid[rows[index].uniqueid]=[];
  var obj={id:rows[index].uniqueid,GameName:rows[index].game_name,groupName:rows[index].grp_name,cards:[],dateTime:rows[index].date}

async.forEachOf(rows,function (data, cardindex ,cardnext) {
  if(obj.id==rows[cardindex].uniqueid){
if(groupbyCards[rows[cardindex].card_id]==undefined){
  groupbyCards[rows[cardindex].card_id]=[];
  var card={card_id:rows[cardindex].card_id,img_url:rows[cardindex].img_url,card_name:rows[cardindex].card_name,players:[],id:rows[cardindex].uniqueid}
  // obj.cards.push(card);
  async.forEachOf(rows,function (data, pindex ,pnext) {
  if(card.id==rows[pindex].uniqueid && card.card_id==rows[pindex].card_id){
if(groupbyplayers[rows[pindex].player_id]==undefined){
groupbyplayers[rows[pindex].player_id]=[];
card.players.push(rows[pindex]);
  }
}
pnext();
  },function(err){
    groupbyplayers={};
obj.cards.push(card);
  })
}

  }

cardnext();
  },function(err){
    groupbyCards={};
bidhistory.push(obj);

  })
}
next();
      },function(err){
res.send(bidhistory);
      })
  });
})




// display answercard

app.get('/disp_answercard/:card_id',function(req,res){
      var query="SELECT * FROM `card` where card_id = '"+req.params.card_id+"'";
      connection.query(query,function(err,rows,fields){
      if(err){
      console.log(err.message);
    }
    else{
    res.send(JSON.stringify(rows));  
    }
  })
})

// new api player details 


app.get("/playerbyid/:playerid",function(req,res){
  // var query="SELECT *,answer.answer,questions.question FROM players LEFT JOIN answer ON players.player_id=answer.playerid LEFT JOIN questions ON answer.questionid=questions.quesid";
var query="select * FROM players WHERE player_id = '"+req.params.playerid+"'";
  connection.query(query,function(err,rows,fields){
    if(err){
      console.log(err.message);
    }
    else {
      res.send(JSON.stringify(rows));
    }
  });
})






app.get("/disp_attached_ans/:game_id/:deck_id/",function(req,res){
var query="SELECT ans_to_ques.*,game_master.keyword, card.img_url ,card.card_name, question_bank.theme_id,question_bank.gamemode,question_bank.ques_bank,ques_for_questionbank.question FROM ans_to_ques LEFT JOIN card ON card.card_id = ans_to_ques.card_id  LEFT JOIN question_bank ON question_bank.quesb_id = ans_to_ques.quesb_id INNER JOIN game_master ON game_master.game_id=ans_to_ques.game_id LEFT JOIN ques_for_questionbank ON ques_for_questionbank.ques_id = ans_to_ques.ques_id  WHERE ans_to_ques.game_id = '"+req.params.game_id+"'  AND ans_to_ques.deck_id ='"+req.params.deck_id+"' GROUP BY card_id, quesb_id , ques_id";
  connection.query(query,function(err,rows,fields){
    if(err){
      console.log(err.message);
    }
    else {
      res.send(JSON.stringify(rows));
    }
  });
})

// new update api for game creation
// select * from ans_to_ques where ans_to_ques.game_id=23 AND ans_to_ques.quesb_id=32 AND ans_to_ques.ques_id= 40 AND ans_to_ques.deck_id= 8 AND ans_to_ques.card_id= 7

app.get("/disp_catforcard/:game_id/:quesb_id/:deck_id/:ques_id/:card_id",function(req,res){
var query="select * from ans_to_ques where ans_to_ques.game_id = '"+req.params.game_id+"' AND ans_to_ques.quesb_id = '"+req.params.quesb_id+"' AND ans_to_ques.ques_id = '"+req.params.ques_id+"' AND ans_to_ques.deck_id = '"+req.params.deck_id+"' AND ans_to_ques.card_id = '"+req.params.card_id+"'";
  connection.query(query,function(err,rows,fields){
    if(err){
      console.log(err.message);
    }
    else {
      res.send(JSON.stringify(rows));
    }
  });
})

// __OJ__CODES__

// Bidding API for providing Cards
app.get("/multiplayer/bidding/cards/:deck_id/:lang_id/:game_id", function(req, res){
  var query="SELECT * FROM `ans_to_ques` WHERE ans_to_ques.game_id="+req.params.game_id+" and ans_to_ques.deck_id="+req.params.deck_id+" group BY card_id";
  connection.query(query,function(err,rows,fields){
    if(err){
      console.log(err.message);
    }else if(rows.length>0){
      var rowsofcards=[];
       async.forEachOf(rows,function (data, index ,next) {
      var getcard="SELECT card.*, word.word, word.synonym FROM card LEFT JOIN word ON card.card_id = word.card_id WHERE  word.lang_id = "+req.params.lang_id+" and card.card_id="+rows[index].card_id+"";
      connection.query(getcard,function(err,cardrows,fields){
        cardrows[0].img_url=imgURL+cardrows[0].img_url;
        rowsofcards.push(cardrows[0]);
        next();
      })
    },function(err){
// res.send(rowsofcards);
 async.forEachOf(rowsofcards,function (data, cardindex ,cardnext) {
  var querycategory="select ans_to_ques.card_id,ans_to_ques.cat_id,ans_to_ques.card_score as score,cattheme.category as title FROM ans_to_ques INNER JOIN cattheme ON cattheme.cattheme_id=ans_to_ques.cat_id WHERE ans_to_ques.game_id="+req.params.game_id+" AND ans_to_ques.card_id="+rowsofcards[cardindex].card_id+"";
  connection.query(querycategory,function(err,categoryrows,fields){
    rowsofcards[cardindex].category=categoryrows;
cardnext();
  })
  },function(err){
res.send(rowsofcards);
  })
    })
    }else{
      var emptyarray=[];
      res.send(emptyarray);
    }
  })
  // var query = "SELECT card.*, word.word, word.synonym FROM card LEFT JOIN word ON card.card_id = word.card_id WHERE card.deck_id = "+req.params.deck_id+ " AND word.lang_id = "+req.params.lang_id ;
  // connection.query(query, function(err, cardarray, fields){
  //   if(err){
  //     console.log(err.message);
  //   }else{
  //     async.forEachOf(cardarray,function (data, index ,next) {
  //       cardarray[index]['img_url']=imgURL+cardarray[index]['img_url'];
  //       scoreobj={};
  //       var query="SELECT score.score_id,score.card_id,score.cat_id,score.score,cattheme.category as title from score inner join cattheme ON score.cat_id=cattheme.cattheme_id and cattheme.status='A' WHERE score.card_id="+cardarray[index]["card_id"]+"";
  //       console.log(query);
  //       connection.query(query,function(err,rows,fields){
  //         if(err){
  //           console.log(err.message);
  //         }
  //         else{
  //           cardarray[index].category=rows;
  //           // cardarray[index].scoredata=scoreobj;
  //         }
  //         next();
  //       })
  //     },function(err){
  //       res.send(JSON.stringify(cardarray));
  //     })
  //        // async.forEachOf(cardarray,function (data, index ,next) {
  //        //    cardarray[index]['img_url'] = imgURL+cardarray[index]['img_url'];     
  //        //    next();
  //        //    })        
  //       // res.send(JSON.stringify(cardarray));
  //   }
  // })

})

// Bidding API for storing History
app.post("/multiplayer/bidding/history/store", function(req, res){
  
  var historyArray = req.body;
    async.forEachOf(historyArray, function (data, index, next) {
      var query = "INSERT INTO `selfi_history`(`uniqueid`, `game_id`, `player_id`, `card_id`, `bid`, `date`) VALUES ('"+historyArray[index].uniqueid+"',"+historyArray[index].game_id+","+historyArray[index].player_id+","+historyArray[index].card_id+","+historyArray[index].bid+", NOW())" ;
      console.log(query)
      connection.query(query, function(err, rows, fields){
        if(err){
          console.log(err.message);
        }else{
                          
        }
      })
      next();
    }) 
    res.send("Inserted");
})

app.get("/multiplayer/bidding/history/display", function(req, res){
    var query = "Select * from selfi_history";
      connection.query(query, function(err, rows, fields){
        if(err){
          console.log(err.message);
          res.send(err);
        }else{
          res.send(rows);
        }
      })
})




// __OJ__CODES__END


// theme category api


// INSERT INTO `cattheme` (`cattheme_id`, `deck_id`, `theme`, `category`, `status`, `created_date`) VALUES (NULL, ' ', ' ', ' ', ' ', ' ')

app.post("/insert_cattheme",urlencodedParser,function(req,res){

  var todaydate = new Date();
     var sql = "INSERT INTO cattheme (deck_id,theme,category,status,created_date) VALUES ?";
var values =[];
 for(i=0;i<req.body.length;i++){
    values.push([req.body[i].deck_id,req.body[i].theme,req.body[i].category,'A',todaydate]);
}
console.log(values);
connection.query(sql, [values], function(err) {
    if (err) 
      throw err;
    else
    {
      res.send("Inserted");
    }
})
    
})


app.post('/update_cattheme',urlencodedParser,function(req,res){
  var update_query="update cattheme set deck_id='"+req.body.deck_id+"',theme='"+req.body.theme+"',category='"+req.body.category+"' where cattheme_id="+req.body.cattheme_id+"";
  console.log(update_query);
  connection.query(update_query,function(err,rows,fields){
    if(err){
      console.log(err.message);
    }
    else{
      res.send("Updated");
    }
  })
})

// SELECT cattheme.*, deck.deck_theme FROM `cattheme` LEFT JOIN deck ON deck.DeckID = cattheme.deck_id


app.get("/disp_cattheme/",function(req,res){
var query="SELECT cattheme.*, deck.deck_theme FROM cattheme LEFT JOIN deck ON deck.DeckID = cattheme.deck_id";
  connection.query(query,function(err,rows,fields){
    if(err){
      console.log(err.message);
    }
    else {
      res.send(JSON.stringify(rows));
    }
  });
})


// delete

app.get("/delete_cattheme/:status/:cattheme_id",function(req,res){
  var status="";
  if(req.params.status=="A"){
status="I";
  }
  else{
    status="A";
  }
  var delete_query="update cattheme set status='"+status+"' where cattheme_id="+req.params.cattheme_id+"";
  connection.query(delete_query,function(err,rows,fields){
    if(err){
      console.log(err.message);
    }
    else{
      res.send("Deleted");
    }
  })
})


// SELECT * FROM `cattheme` WHERE deck_id = 8

app.get("/dispcattheme/:deck_id",function(req,res){
var query="SELECT * FROM `cattheme` WHERE deck_id = "+req.params.deck_id+" and status='A'";
  connection.query(query,function(err,rows,fields){
    if(err){
      console.log(err.message);
    }
    else {
      res.send(JSON.stringify(rows));
    }
  });
})

// zuhari window theme api

// SELECT zuhari_window.*,game_master.game_name FROM `zuhari_window` LEFT JOIN game_master on game_master.game_id = zuhari_window.game_id
// display api

app.get("/dispczuharitheme/",function(req,res){
var query="SELECT zuhari_window.*,game_master.game_name,deck.deck_theme FROM zuhari_window LEFT JOIN game_master on game_master.game_id = zuhari_window.game_id left join deck ON deck.DeckID=zuhari_window.gameDeck";
  connection.query(query,function(err,rows,fields){
    if(err){
      console.log(err.message);
    }
    else {
      res.send(JSON.stringify(rows));
    }
  });
})

// insert Zuhari



// INSERT INTO `zuhari_window` (`theme_id`, `game_mode`, `game_id`, `left_box`, `right_box`, `up_box`, `down_box`, `createdby`, `createddate`) VALUES (NULL, '0', '31', 'Good', 'Average', 'Poor', 'Considerable', 'vinay', '2017-12-21');

app.post('/insert_zuhari',urlencodedParser,function(req,res){
  var duplicate_sql="select * from zuhari_window where game_id='"+req.body.game_id+"' and gameDeck='"+req.body.gameDeck+"'";
     connection.query(duplicate_sql,function(err,rows,fields){
     if(err)
     {
      console.log(err.message);
     }
     else if(rows.length>0){
      res.send("Already Exist");
     }
     else
     {
 var query = "insert into zuhari_window(gameDeck,game_mode,game_id,left_box,right_box,up_box,down_box,leftbox_internal_txt,rightbox_internal_txt,upbox_internal_txt,down_internal_txt,status,createdby,createddate) VALUES('"+req.body.gameDeck+"','"+req.body.game_mode+"','"+req.body.game_id+"','"+req.body.left_box+"','"+req.body.right_box+"','"+req.body.up_box+"','"+req.body.down_box+"','"+req.body.leftbox_internal_txt+"','"+req.body.rightbox_internal_txt+"','"+req.body.upbox_internal_txt+"','"+req.body.down_internal_txt+"','A','"+req.body.createdby+"', now())";
           connection.query(query ,function(err,rows,fields){
              if (err)
              {
                console.log(err.message);
              }
              else{
                res.send('Inserted');
            }
     })    
     }
  
})
})


// UPDATE `zuhari_window` SET `game_mode` = '0 ', `game_id` = '31 ', `left_box` = 'Good ', `right_box` = 'Average ', `up_box` = 'Poor ', `down_box` = 'Considerable ', `status` = 'A ', `createdby` = 'vinay ' WHERE `zuhari_window`.`theme_id` = 1


app.post('/update_zuhari',urlencodedParser,function(req,res){
  var update_query="update zuhari_window set game_mode='"+req.body.game_mode+"',game_id='"+req.body.game_id+"',left_box='"+req.body.left_box+"',right_box='"+req.body.right_box+"',up_box='"+req.body.up_box+"',down_box='"+req.body.down_box+"',leftbox_internal_txt ='"+req.body.leftbox_internal_txt+"', rightbox_internal_txt= '"+req.body.rightbox_internal_txt+"', upbox_internal_txt='"+req.body.upbox_internal_txt+"' ,gameDeck='"+req.body.gameDeck+"',down_internal_txt = '"+req.body.down_internal_txt+"' where theme_id="+req.body.theme_id+"";
  console.log(update_query);
  connection.query(update_query,function(err,rows,fields){
    if(err){
      console.log(err.message);
    }
    else{
      res.send("Updated");
    }
  })
})
// deleted


app.get("/delete_zuhari/:status/:theme_id",function(req,res){
  var status="";
  if(req.params.status=="A"){
status="I";
  }
  else{
    status="A";
  }
  var delete_query="update zuhari_window set Status='"+status+"' where theme_id="+req.params.theme_id+"";
  connection.query(delete_query,function(err,rows,fields){
    if(err){
      console.log(err.message);
    }
    else{
      res.send("Deleted");
    }
  })
})

// mobile api for zuhari theme

app.get("/dispczuharitheme/:game_id",function(req,res){
var query="SELECT zuhari_window.*,game_master.game_name FROM zuhari_window LEFT JOIN game_master on game_master.game_id = zuhari_window.game_id where zuhari_window.game_id = "+req.params.game_id+"";
  connection.query(query,function(err,rows,fields){
    if(err){
      console.log(err.message);
    }
    else {
      res.send(JSON.stringify(rows));
    }
  });
})

//Bidding_Report
// SELECT category.category_name,mycategory.*,selfi_history.* FROM `selfi_history` LEFT JOIN score as mycategory ON mycategory.card_id=selfi_history.card_id LEFT JOIN category ON category.catid=mycategory.cat_id WHERE selfi_history.game_id=35 and selfi_history.uniqueid='qKoh32596'
// app.get("/getReportBidding/:gameid/:uniqueid",function(req,res){
//   var query="select * from selfie_history where selfi_history.uniqueid='"+req.params.uniqueid+"'";

//   connection.query(query,function(err,rows,fields))
// }) 





app.post('/insert_logfile', urlencodedParser, function (req, res) {

  var query ="SELECT * FROM logfile WHERE logfile.playerid='"+req.body.player_id+"'";
  connection.query(query, function (err, rows, fields) {

    if (err) {
      console.log(err.message);
    }
    else if(rows.length>0) {
        var insert_query = "UPDATE logfile SET logfile.game_id='"+req.body.game_id+"',logfile.output_image='"+req.body.output_image+"',logfile.outcome_image='"+req.body.outcome_image+"',logfile.date_time=now() WHERE logfile.playerid='"+req.body.player_id+"'";
  console.log(insert_query);
  connection.query(insert_query, function (err, rows, fields) {
    if (err) {
      console.log(err.message);
    }
    else {
      res.send("Updated");
    }
})

    }
    else{
    var insert_query = "INSERT INTO logfile(logfile.Uniqueid,logfile.playerid, logfile.summary_image, logfile.output_image, logfile.outcome_image, logfile.date_time,game_id)VALUES('"+req.body.unique_id+"','"+req.body.player_id+"','"+req.body.summary_image+"','"+req.body.output_image+"','"+req.body.outcome_image+"',now(),'"+req.body.game_id+"')";
  console.log(insert_query);
  connection.query(insert_query, function (err, rows, fields) {
    if (err) {
      console.log(err.message);
    }
    else {
      res.send("Inserted");
    }
})    
    }
//   })


  })
})


// ======================================================================================================================

// couch api

// mobapi

app.get("/dispcouchmobile/",function(req,res){
var query="SELECT * from couch where status='A'";
  connection.query(query,function(err,rows,fields){
    if(err){
      console.log(err.message);
    }
    else {
      res.send(JSON.stringify(rows));
    }
  });
})
app.get("/dispcouchmobile1/:playerid",function(req,res){
  console.log(req.params.playerid)
  if(req.params.playerid==undefined || req.params.playerid=='undefined'){
    req.params.playerid=0;
  }
var query="SELECT couch.*,false as paid FROM couch WHERE couch.productID NOT IN (SELECT transactionrecord.productId FROM transactionrecord where playerid="+req.params.playerid+") UNION SELECT couch.*,true as paid FROM couch INNER JOIN transactionrecord ON transactionrecord.productId=couch.productID AND transactionrecord.playerid="+req.params.playerid+" AND transactionrecord.purchaseState=0";
  connection.query(query,function(err,rows,fields){
    if(err){
      console.log(err.message);
    }
    else {
      res.send(JSON.stringify(rows));
    }
  });
})


// webapi

app.get("/dispcouch/",function(req,res){
var query="SELECT * from couch";
  connection.query(query,function(err,rows,fields){
    if(err){
      console.log(err.message);
    }
    else {
      res.send(JSON.stringify(rows));
    }
  });
})



// insert

app.post('/insert_couch',urlencodedParser,function(req,res){
  var duplicate_sql="select * from couch where email='"+req.body.email+"'";
     connection.query(duplicate_sql,function(err,rows,fields){
     if(err)
     {
      console.log(err.message);
     }
     else if(rows.length>0){
      res.send("Already Exist");
     }
     else
     {
  var query = "insert into couch (couch,image,description,cost,email,dob,status,createdby,createdate) VALUES('"+req.body.couch+"','"+req.body.image+"','"+req.body.description+"','"+req.body.cost+"','"+req.body.email+"','"+req.body.dob+"','A','"+req.body.createdby+"', now(),'"+req.body.productID+"')";
  console.log(query);
           connection.query(query ,function(err,rows,fields){
              if (err)
              {
                console.log(err.message);
              }
              else{
                res.send('Inserted');
            }
     })    
     }
  
})
})

app.post('/update_couch',urlencodedParser,function(req,res){
  var update_query="update couch set couch='"+req.body.couch+"',image='"+req.body.image+"',description='"+req.body.description+"',cost='"+req.body.cost+"',email='"+req.body.email+"',dob='"+req.body.dob+"',productID='"+req.body.productID+"' where couchid="+req.body.couchid+"";
  console.log(update_query);
  connection.query(update_query,function(err,rows,fields){
    if(err){
      console.log(err.message);
    }
    else{
      res.send("Updated");
    }
  })
})


// deleted


app.get("/delete_couch/:status/:couchid",function(req,res){
  var status="";
  if(req.params.status=="A"){
status="I";
  }
  else{
    status="A";
  }
  var delete_query="update couch set Status='"+status+"' where couchid="+req.params.couchid+"";
  connection.query(delete_query,function(err,rows,fields){
    if(err){
      console.log(err.message);
    }
    else{
      res.send("Deleted");
    }
  })
})

// suggested_card api



app.get("/dispsuggested_card/",function(req,res){
var query="SELECT suggested_card.*, players.name , deck.deck_theme FROM `suggested_card` LEFT JOIN players ON players.player_id = suggested_card.playerid LEFT JOIN deck ON deck.DeckID = suggested_card.deck_id";
  connection.query(query,function(err,rows,fields){
    if(err){
      console.log(err.message);
    }
    else {
      res.send(JSON.stringify(rows));
    }
  });
})



app.post("/insert_suggestedCard",urlencodedParser,function(req,res){
  console.log(req.body.playerid);
  var query='INSERT INTO suggested_card ( playerid, card_word, card_synonyms, deck_id, cardimg, description, status, createdate, createdby) VALUES ("'+req.body.playerid+'","'+req.body.card_word+'","'+req.body.card_synonyms+'","'+req.body.deck_id+'","'+req.body.cardimg+'","'+req.body.description+'","A","now()","'+req.body.playerid+'")';
  console.log(query);
  connection.query(query,function(err,rows,fields){
     if(err){
      console.log(err.message);
     }
     else{
      res.send("Inserted");
     }
  })
})


// recently added suggested  card 

app.get("/dispsuggested_recentcard/",function(req,res){
var query="SELECT * FROM suggested_card ORDER BY suggested_card.sugges_id DESC LIMIT 1";
  connection.query(query,function(err,rows,fields){
    if(err){
      console.log(err.message);
    }
    else {
      console.log("nerowros",rows);
      for(i in rows){
        rows[i].cardimg=encodeURIComponent(rows[i].cardimg);
      }
      res.send(JSON.stringify(rows));
    }
  });
})

// delete recent suggested card


app.get("/delete_sugestcard/:status/:sugges_id",function(req,res){
  var status="";
  if(req.params.status=="A"){
status="I";
  }
  else{
    status="A";
  }
  var delete_query="update suggested_card set status='"+status+"' where sugges_id="+req.params.sugges_id+"";
  connection.query(delete_query,function(err,rows,fields){
    if(err){
      console.log(err.message);
    }
    else{
      res.send("Deleted");
    }
  })
})
// insert sugested card


// INSERT INTO `suggested_card` (`sugges_id`, `playerid`, `card_word`, `card_synonyms`, `deck_id`, `cardimg`, `description`, `status`, `createdate`, `createdby`) VALUES (NULL, ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ')

app.post("/insert_suggestedCard",urlencodedParser,function(req,res){
  console.log(req.body.playerid);
  var query='INSERT INTO suggested_card ( playerid, card_word, card_synonyms, deck_id, cardimg, description, status, createdate, createdby) VALUES ("'+req.body.playerid+'","'+req.body.card_word+'","'+req.body.card_synonyms+'","'+req.body.deck_id+'","'+req.body.cardimg+'","'+req.body.description+'","A","now()","'+req.body.playerid+'")';
  console.log(query);
  connection.query(query,function(err,rows,fields){
     if(err){
      console.log(err.message);
     }
     else{
      res.send("Inserted");
     }
  })
})


// end suggested

app.get("/get_password/:passwords",function(req,res){
  // console.log("inside");
  res.send("came");
  var encrypt_password=encrypt(req.params.password.toString());
  res.send(encrypt_password);

  })

// app.get("/updateversion/:version",function(req,res){
// 	var query="update version set version.versionNumber='"+req.params.version+"'";
// 	connection.query(query,function(err,rows,fields){
// if(err){
// console.log(err.message);
// }else{
// 	res.send("updated");
// }
// 	})
// })

app.get('/getmaxVersion/',function(req,res){
  var query="SELECT MAX(version.versionNumber) as max FROM version";
  connection.query(query,function(err,rows,fields){
    if(err){
      console.log(err.message);
    }else{
      res.send(JSON.stringify(rows));
   }
  })
})
app.post("/del_ans_to_ques",urlencodedParser,function(req,res){
    var values=req.body;
var queries = '';
console.log("upd_to_ques",values);
// values.forEach(function(item){
  // queries += mysql.format("UPDATE tabletest SET users = ? WHERE id = ?; ", item);
  if(values.status =='A')
  {
  queries ="UPDATE ans_to_ques SET ans_to_ques.status='I' WHERE ans_to_ques.game_id='"+values.game_id+"' AND ans_to_ques.quesb_id='"+values.quesb_id+"' AND ans_to_ques.ques_id='"+values.ques_id+"' AND ans_to_ques.deck_id='"+values.deck_id+"' AND ans_to_ques.card_id='"+values.card_id+"' ;";
}
else{
  queries ="UPDATE ans_to_ques SET ans_to_ques.status='A' WHERE ans_to_ques.game_id='"+values.game_id+"' AND ans_to_ques.quesb_id='"+values.quesb_id+"' AND ans_to_ques.ques_id='"+values.ques_id+"' AND ans_to_ques.deck_id='"+values.deck_id+"' AND ans_to_ques.card_id='"+values.card_id+"' ;";
}
// });
  console.log(queries);

connection.query(queries,function(err,rows){
    if (err)
      throw err;
    else 
    {
      console.log(rows);
      res.send("Deleted");
    }


})
})



//  log priority api

// INSERT INTO `log_priority` (`logid`, `gameid`, `player_id`, `move`, `card_in_hand1`, `card_in_hand2`, `card_in_hand3`, `card_in_hand4`, `card_in_hand5`, `choice_card1`, `choice_card2`, `choice_card3`, `action`, `date_time`, `select_card`, `drop_card`) VALUES (NULL, ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ')


// app.post('/insert_log_priority',urlencodedParser,function(req,res){
//   var query=" INSERT INTO log_priority ( gameid, player_id, move, card_in_hand1, card_in_hand2, card_in_hand3, card_in_hand4, card_in_hand5, choice_card1, choice_card2, choice_card3, action, date_time, select_card, drop_card) VALUES ( '"+req.body.gameid+"', '"+req.body.player_id+"', '"+req.body.move+"', '"+req.body.card_in_hand1+"', '"+req.body.card_in_hand2+"', '"+req.body.card_in_hand3+"', '"+req.body.card_in_hand4+"', '"+req.body.card_in_hand5+"', '"+req.body.choice_card1+"', '"+req.body.choice_card2+"', '"+req.body.choice_card3+"', '"+action+"', '"+date_time+"', '"+select_card+"', '"+drop_card+"')";
//   console.log(query);
//   connection.query(query,function(err,rows,fields){
//     if(err){
//       console.log(err.message);
//     }
//     else{
//       res.send("Inserted");
//     }
//   })
// })

app.post("/insert_log_priority",urlencodedParser,function(req,res){

  var todaydate = new Date();
     var sql = "INSERT INTO log_priority ( gameid,uniqueid, player_id, move, card_in_hand1, card_in_hand2, card_in_hand3, card_in_hand4, card_in_hand5, choice_card1, choice_card2, choice_card3, action, date_time, select_card, drop_card) VALUES  ?";
var values =[];
 for(i=0;i<req.body.length;i++){
    values.push([req.body[i].gameid,req.body[i].uniqueid,req.body[i].player_id,req.body[i].move,req.body[i].card_in_hand1,req.body[i].card_in_hand2,req.body[i].card_in_hand3,req.body[i].card_in_hand4,req.body[i].card_in_hand5,req.body[i].choice_card1,req.body[i].choice_card2,req.body[i].choice_card3,req.body[i].action,req.body[i].date_time,req.body[i].select_card,req.body[i].drop_card]);
}
console.log(values);
connection.query(sql, [values], function(err) {
    if (err) 
      throw err;
    else
    {
      res.send("Inserted");
    }
})
    
})

// new api for setting backgoround images and music

// background music

app.post('/insert_music',urlencodedParser,function(req,res){
  var duplicate_sql="select * from background_music_seeting where music_name='"+req.body.music_name+"' ";
     connection.query(duplicate_sql,function(err,rows,fields){
     if(err)
     {
      console.log(err.message);
     }
     else if(rows.length>0){
      res.send("Already Exist");
     }
     else
     {
  var query = "insert into background_music_seeting (music_name,file_name,createdby,createddate) VALUES('"+req.body.music_name+"','"+req.body.file_name+"','"+req.body.createdby+"', now())";
  console.log(query);
           connection.query(query ,function(err,rows,fields){
              if (err)
              {
                console.log(err.message);
              }
              else{
                res.send('Inserted');
            }
     })    
     }
  
})
})
// SELECT * FROM `background_music_seeting`

app.get("/disp_music/",function(req,res){
var query="SELECT * FROM background_music_seeting ";
  connection.query(query,function(err,rows,fields){
    if(err){
      console.log(err.message);
    }
    else {
      res.send(JSON.stringify(rows));
    }
  });
})


// UPDATE `background_music_seeting` SET `music_name` = 'musicsecond ', `file_name` = 'Neethanae - SenSongsMp3.Co.mp3 ', `createdby` = '2 ' WHERE `background_music_seeting`.`music_id` = 5

// SELECT * FROM `scenario_history` WHERE date_time BETWEEN '2018-02-26' AND '2018-02-27'
// SELECT * FROM selfi_history WHERE selfi_history.date BETWEEN '2018-02-28 13:33:38' AND '2018-02-28 13:34:48'




app.post('/update_music',urlencodedParser,function(req,res){
  var duplicate_sql="select * from background_music_seeting where file_name='"+req.body.file_name+"' OR music_name='"+req.body.music_name+"'";
     connection.query(duplicate_sql,function(err,rows,fields){
     if(err)
     {
      console.log(err.message);
     }
     else if(rows.length>0){
      res.send("Already Exist");
     }
     else
     {
  var query = "UPDATE background_music_seeting SET music_name = '"+req.body.music_name+"', file_name = '"+req.body.file_name+"', createdby = '"+req.body.createdby+"' WHERE music_id = '"+req.body.music_id+"'";
  console.log(query);
           connection.query(query ,function(err,rows,fields){
              if (err)
              {
                console.log(err.message);
              }
              else{
                res.send('Updated');
            }
     })    
     } 
})
})



app.get("/deleteBackmusic/:musicid",function(req,res){
 var query = "DELETE FROM background_music_seeting WHERE music_id = '"+req.params.musicid+"'";
  connection.query(query,function(err,rows,fields){
    if(err){
      console.log(err.message)
    }
    else {
res.send("Deleted");
    }
  })
})



// background image insertion

app.post('/insert_image',urlencodedParser,function(req,res){
  var duplicate_sql="select * from background_img_seeting where backimg_name='"+req.body.backimg_name+"' ";
     connection.query(duplicate_sql,function(err,rows,fields){
     if(err)
     {
      console.log(err.message);
     }
     else if(rows.length>0){
      res.send("Already Exist");
     }
     else
     {
  var query = "insert into background_img_seeting (backimg_name,file_name,createdby,createddate) VALUES('"+req.body.backimg_name+"','"+req.body.file_name+"','"+req.body.createdby+"', now())";
  console.log(query);
           connection.query(query ,function(err,rows,fields){
              if (err)
              {
                console.log(err.message);
              }
              else{
                res.send('Inserted');
            }
     })    
     }
  
})
})

// display image

app.get("/disp_image/",function(req,res){
var query="SELECT * FROM background_img_seeting ";
  connection.query(query,function(err,rows,fields){
    if(err){
      console.log(err.message);
    }
    else {
      res.send(JSON.stringify(rows));
    }
  });
})


app.post('/update_image',urlencodedParser,function(req,res){
  var duplicate_sql="select * from background_img_seeting where file_name='"+req.body.file_name+"' OR backimg_name='"+req.body.backimg_name+"'";
     connection.query(duplicate_sql,function(err,rows,fields){
     if(err)
     {
      console.log(err.message);
     }
     else if(rows.length>0){
      res.send("Already Exist");
     }
     else
     {
  var query = "UPDATE background_img_seeting SET backimg_name = '"+req.body.backimg_name+"', file_name = '"+req.body.file_name+"', createdby = '"+req.body.createdby+"' WHERE img_id = '"+req.body.img_id+"'";
  console.log(query);
           connection.query(query ,function(err,rows,fields){
              if (err)
              {
                console.log(err.message);
              }
              else{
                res.send('Updated');
            }
     })    
     } 
})
})



app.get("/deleteBackimage/:img_id",function(req,res){
 var query = "DELETE FROM background_img_seeting WHERE img_id = '"+req.params.img_id+"'";
  connection.query(query,function(err,rows,fields){
    if(err){
      console.log(err.message)
    }
    else {
res.send("Deleted");
    }
  })
})





// share proioriy history

app.post("/insert_sharedprioityhistroy",urlencodedParser,function(req,res){

  var todaydate = new Date();
     var sql = "INSERT INTO sharedpriorityghistory (grp_id,playerid,cardid_priority1,cardid_priority2,cardid_priority3,cardid_priority4,cardid_priority5,score,start_date,end_date,datetime,game_session_id) VALUES ?";
var values =[];
 for(i=0;i<req.body.length;i++){
    values.push([req.body[i].grp_id,req.body[i].playerid,req.body[i].cardid_priority1,req.body[i].cardid_priority2,req.body[i].cardid_priority3,req.body[i].cardid_priority4,req.body[i].cardid_priority5,req.body[i].score,req.body[i].start_date,req.body[i].end_date,todaydate,req.body[i].game_session_id]);
}
console.log(values);
connection.query(sql, [values], function(err) {
    if (err) 
      throw err;
    else
    {
      res.send("Inserted");
    }
})
    
})
//loginfacebook
app.post('/loginfacebook',urlencodedParser,function(req,res){
  console.log(req.body);
    var email_id=req.body.email_id;
    console.log(email_id);
    if(email_id==undefined){
      req.body.email_id='null';
    }
  // if(req.body.email_id==undefined){
  //   req.body.email_id=req.body.email_id;
  // }else{
  // }
  var duplicate_sql="SELECT * FROM `fb_users` WHERE oauth_uid ='"+req.body.oauth_uid+"'";
  console.log(duplicate_sql);
      connection.query(duplicate_sql,function(err,rows,fields){
     if(err)
     {
      console.log(err.message);
     }
     else if(rows.length>0){
      var select_query="select players.* from fb_users inner join players on players.player_id=fb_users.user_id  where fb_users.oauth_uid="+req.body.oauth_uid+"";
      connection.query(select_query,function(err,playerrows,fields){
        if(err){
          console.log(err.message);
        }else{
          // res.send(JSON.stringify(playerrows));
          var lastplayed_query="SELECT logfile.*,game_master.gamemode,game_master.game_name FROM `logfile` LEFT JOIN game_master ON logfile.game_id=game_master.game_id WHERE logfile.playerid='"+playerrows[0].player_id+"'";

    connection.query(lastplayed_query,function(err,queryresult,fields){
      if(err){
        console.log(err.message);
      }
      else if(queryresult.length>0){

        playerrows[0]["game_mode"]=queryresult[0].gamemode,
        playerrows[0]["game_name"]=queryresult[0].game_name,
        playerrows[0]["lastplayed"]=queryresult;
        res.send(playerrows);
      }
      else{
        res.send(playerrows);
      }
    
    })
        }
      })
     }
     else
     {
      if(req.body.email_id=='null'){
      req.body.email_id='noemail';  
      }
        var query="INSERT INTO `players`( `name`, `nickname`,`gender`, `email_id`,`img_url`,`country`)  VALUES ('"+req.body.first_name+"','"+req.body.last_name+"','"+req.body.gender+"','"+req.body.email_id+"','"+req.body.img_url+"','"+req.body.country+"')";
        console.log(query);
        connection.query(query,function(err,playerrows,fields){
     if(err){
      console.log(err.message);
     }
     else
     { 
      console.log(playerrows);
      // res.send(rows);
      var insertid=playerrows.insertId;
      var query="INSERT INTO `fb_users` (`user_id`, `oauth_provider`, `oauth_uid`, `first_name`, `last_name`, `email`, `gender`, `locale`, `picture`, `link`, `created`, `modified`) VALUES ("+insertid+", 'facebook', '"+req.body.oauth_uid+"','"+req.body.first_name+"','"+req.body.last_name+"','"+req.body.email_id+"','"+req.body.gender+"','"+req.body.country+"','"+req.body.img_url+"','"+req.body.link+"','"+req.body.created+"','"+req.body.modified+"')";
      connection.query(query,function(err,facebookresp,fields){
        if(err){
          console.log(err.message);
        }else{
          // res.send(JSON.stringify(playerrows))
           var select_query="select players.* from fb_users inner join players on players.player_id=fb_users.user_id  where fb_users.oauth_uid="+req.body.oauth_uid+"";
      connection.query(select_query,function(err,playerrows,fields){
        if(err){
          console.log(err.message);
        }else{
          // res.send(JSON.stringify(playerrows));
            var lastplayed_query="SELECT logfile.*,game_master.gamemode,game_master.game_name FROM `logfile` LEFT JOIN game_master ON logfile.game_id=game_master.game_id WHERE logfile.playerid='"+playerrows[0].player_id+"'";

    connection.query(lastplayed_query,function(err,queryresult,fields){
      if(err){
        console.log(err.message);
      }
      else if(queryresult.length>0){

        playerrows[0]["game_mode"]=queryresult[0].gamemode,
        playerrows[0]["game_name"]=queryresult[0].game_name,
        playerrows[0]["lastplayed"]=queryresult;
        res.send(playerrows);
      }
      else{
        res.send(playerrows);
      }
    
    })
        }
          })
        }
      })
     }
  })    
     }
  })  
  

})

// new card udpate anstoques

app.post('/upd_card',urlencodedParser,function(req,res){
  
  var query = "UPDATE ans_to_ques SET ans_to_ques.card_id='"+req.body.card_id+"' WHERE ans_to_ques.game_id='"+req.body.game_id+"' AND ans_to_ques.quesb_id='"+req.body.quesb_id+"' AND ans_to_ques.ques_id='"+req.body.ques_id+"' AND ans_to_ques.deck_id='"+req.body.deck_id+"' AND ans_to_ques.card_id='"+req.body.selectcard_id+"' ";
  console.log(query);
           connection.query(query ,function(err,rows,fields){
              if (err)
              {
                console.log(err.message);
              }
              else{
                res.send('Updated');
            }
     })    
      
})
app.get("/removeToken/:tokenid/:player_id",function(req,res){
   var query="UPDATE players SET  token = 'null' , online_status='false' WHERE  token = "+req.params.tokenid+" and player_id!="+req.params.player_id+"";
   if(req.params.tokenid=='null' || req.params.tokenid==''){
res.send("not updated");
   }else{

   connection.query(query,function(err,rows,fields){
    if(err){
      console.log(err.message);
    }else{
      res.send("Token updated")
    }
   })
   }
 })

app.get('/ApplicationViews',function(req,res){
  var query="select * from app_views";
  connection.query(query,function(err,rows){
    if(err){
      console.log(err.message);
    }else{
      res.send(JSON.stringify(rows));
    }
  })
})
/*app view*/

app.post('/viewAddPlayers',urlencodedParser,function(req,res){
  // var selectquery="select * from app_view where player_id="++"";
  var selectquery
  var query="insert into app_views(deviceId,view_date) values('"+req.body.deviceId+"','"+req.body.viewdate+"')";
  console.log(query);
  connection.query(query,function(err,rows,fields){
    if(err){
      // console.log(err);
      if(err.errno==1062){
        var updatequery="update app_views set view_date='"+req.body.viewdate+"' where deviceId='"+req.body.deviceId+"'";
        connection.query(updatequery,function(err,rows1,fields){
          if(err){
            console.log(err.message);
          }else{
            console.log("updated");
            res.send("updated");
          }
        })
      }
    }else{
      res.send("inserted");
    }
  })
})

app.post('/pay',urlencodedParser,function(req,res){
  console.log(req.body);
  const create_payment_json = {
    "intent": "sale",
    "payer": {
        "payment_method": "paypal"
    },
    "redirect_urls": {
        "return_url": "http://10.0.0.109:3000/success",
        "cancel_url": "http://10.0.0.109:3000/cancel"
    },
    "transactions": [{
        "item_list": {
            "items": [{
                "name": req.body.detailName,
                "sku": "001",
                "price":  req.body.price,
                "currency": "INR",
                "quantity": 1
            }]
        },
        "amount": {
            "currency": "INR",
            "total": req.body.price
        },
        "description": "Hat for the best team ever"
    }]
}

paypal.payment.create(create_payment_json, function (error, payment) {
  if (error) {
      console.log(JSON.stringify(error));
  } else {
      for(let i = 0;i < payment.links.length;i++){
        if(payment.links[i].rel === 'approval_url'){
          // res.redirect(payment.links[i].href);
          res.send(JSON.stringify(payment));
        }
      }
  }
});

});

app.get('/success', (req, res) => {
  console.log(req);
  console.log(res);
  const payerId = req.query.PayerID;
  const paymentId = req.query.paymentId;

  const execute_payment_json = {
    "payer_id": payerId,
    "transactions": [{
        "amount": {
            "currency": "INR",
            "total": "1"
        }
    }]
  };

  paypal.payment.execute(paymentId, execute_payment_json, function (error, payment) {
    if (error) {
        console.log(error.response);
        throw error;
    } else {
        // console.log(""JSON.stringify(payment));
        res.send(JSON.stringify(payment));
    }
});
})


app.get('/cancel', function(req,res){
  // console.log(req);
  // console.log("res",res);
  res.send(JSON.strinfigy(res));
})

// server.timeout = 20000;
// server.timeout = 20000;
app.set('port', process.env.PORT || 8153);
app.set('host', process.env.HOST || '0.0.0.0');

server.listen(app.get('port'), function(){
  console.log('Express server listening on port ' + app.get('host') + ':' + app.get('port'));
});
// server.timeout = 20000;
