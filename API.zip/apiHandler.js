const sample = require("./routes/WEB/sample");



let apiHandler = {
    init: function(app,router,db,nodemailer,Mustache,fs,ses,async,stripe,dateFormat){

       let version = "/api/v1/";
       
        app.use(version,sample(router,db));


    }
};

module.exports = apiHandler;